import { createSlice } from "@reduxjs/toolkit";

// XAVFSIZLIK/MA'LUMOT TOZALIGI TUZATISHI: OLDIN savat bitta, UMUMIY
// `'cart'` kalitida saqlanardi — sotuvchidan qat'i nazar. Bu degani,
// agar mijoz 2-3 xil sotuvchining do'konidan foydalansa, BIR
// do'kondagi savat, boshqa do'konni ochganda ham KO'RINIB QOLARDI —
// hatto o'sha mahsulotlar bu (joriy) sotuvchiga umuman tegishli
// bo'lmasa ham! Endi har bir sotuvchi uchun ALOHIDA kalit
// (`cart:{sellerId}`) ishlatiladi, va savat FAQAT sellerId ma'lum
// bo'lgach ("hydrateCart" orqali) yuklanadi — modul yuklanish
// vaqtida emas (chunki o'sha payt sellerId hali noma'lum).
const buildKey = (sellerId) => `cart:${sellerId}`;

const readCartFor = (sellerId) => {
  if (!sellerId) return [];
  try {
    const raw = localStorage.getItem(buildKey(sellerId));
    return raw ? JSON.parse(raw) : [];
  } catch (error) {
    console.log('LocalStorage da xatolik bor ' + error);
    return [];
  }
};

const cartSlice = createSlice({
  name: 'carts',
  initialState: {
    items: [],
    // Hozir yuklangan savat AYNAN qaysi sotuvchiga tegishli ekanini
    // kuzatib boradi — shu orqali sotuvchi o'zgarganda (masalan
    // boshqa do'kon havolasi orqali kirilganda), eski savat
    // NOTO'G'RI ko'rinib qolmaydi.
    scopedSellerId: null,
  },
  reducers: {
    // Sellerld ma'lum bo'lgach (SessionContext orqali) chaqiriladi —
    // o'sha SOTUVCHIGA tegishli savatni localStorage'dan yuklaydi.
    hydrateCart: (state, action) => {
      const sellerId = action.payload;
      state.scopedSellerId = sellerId;
      state.items = readCartFor(sellerId);
    },
    toggleCartActions: (state, action) => {
      const product = action.payload;
      // TUZATILDI: Mahsulot savatda allaqachon bormi, tekshiramiz (Takrorlanishni oldini oladi)
      const existingItem = state.items.find(item => item.id === product.id);

      // OLDIN: savat har doim `product.price`ni (to'liq narx) saqlardi,
      // hatto mahsulotda haqiqiy chegirma (`discountPrice`) bo'lsa ham —
      // natijada xaridor mahsulot sahifasida chegirmali narxni ko'rib,
      // lekin savat/checkout'da TO'LIQ narxni to'lashga majbur bo'lardi.
      // Endi savatga qo'shishda HAQIQIY (chegirma bo'lsa — chegirmali)
      // narx saqlanadi.
      const hasDiscount = product.discountPrice &&
        Number(product.discountPrice) > 0 &&
        Number(product.discountPrice) < Number(product.price);
      const effectivePrice = hasDiscount ? Number(product.discountPrice) : Number(product.price) || 0;

      if (existingItem) {
        existingItem.quantity += 1;
      } else {
        state.items.push({...product, price: effectivePrice, quantity: 1});
      }
      if (state.scopedSellerId) {
        localStorage.setItem(buildKey(state.scopedSellerId), JSON.stringify(state.items));
      }
    },
    removeCart: (state, action) => {
      const product = action.payload;
      state.items = state.items.filter(item => item.id !== product.id);
      if (state.scopedSellerId) {
        localStorage.setItem(buildKey(state.scopedSellerId), JSON.stringify(state.items));
      }
    },
    quantityDec: (state, action) => {
      const productId = action.payload;
      const item = state.items.find(item => item.id === productId);
      if (item) {
        if (item.quantity > 1) {
          item.quantity -= 1;
        } else {
          // TUZATILDI: Soni 1 dan kamaysa, savatdan avtomat o'chadi
          state.items = state.items.filter(i => i.id !== productId);
        }
      }
      if (state.scopedSellerId) {
        localStorage.setItem(buildKey(state.scopedSellerId), JSON.stringify(state.items));
      }
    },
    quantityInc: (state, action) => {
      const productId = action.payload;
      const item = state.items.find(item => item.id === productId);
      // TUZATILDI: if (item.quantity) xatosi olib tashlandi, oddiygina item bormiligi tekshiriladi
      if (item) {
        item.quantity += 1;
      }
      if (state.scopedSellerId) {
        localStorage.setItem(buildKey(state.scopedSellerId), JSON.stringify(state.items));
      }
    },
    clearCart: (state) => {
      state.items = [];
      if (state.scopedSellerId) {
        localStorage.removeItem(buildKey(state.scopedSellerId));
      }
    },
    // "BIR TUGMA BILAN QAYTA BUYURTMA" - oldingi buyurtma tarkibini
    // savatga TO'LIQ almashtirib qo'yadi (mavjud savat bilan
    // qo'shilmaydi - "aynan shu buyurtmani takrorlash" degan aniq,
    // bashorat qilinadigan xatti-harakat uchun).
    //
    // XAVFSIZLIK ESLATMASI: bu yerda saqlangan narx faqat EKRANDA
    // ko'rsatish uchun - haqiqiy to'lov summasi baribir
    // `createOrder`ning server tranzaksiyasida QAYTA hisoblanadi
    // (mavjud, tekshirilgan arxitektura) - shuning uchun narx
    // o'zgargan bo'lsa ham, xaridor NOTO'G'RI summa to'lamaydi.
    reorderFromPastOrder: (state, action) => {
      const items = Array.isArray(action.payload) ? action.payload : [];
      state.items = items.map((item) => ({
        id: item.id,
        name: item.name,
        image: item.image || null,
        price: Number(item.price) || 0,
        quantity: Number(item.quantity) || 1,
      }));
      if (state.scopedSellerId) {
        localStorage.setItem(buildKey(state.scopedSellerId), JSON.stringify(state.items));
      }
    }
  }
});

export const { hydrateCart, toggleCartActions, removeCart, quantityDec, quantityInc, clearCart, reorderFromPastOrder } = cartSlice.actions;
export default cartSlice.reducer;
