import { createContext, useContext, useState, useMemo } from "react";
import { useSelector } from "react-redux";
import { useSearchParams } from "react-router-dom";
import { useSession } from "@/context/SessionContext";
import { useLiveShopProducts } from "@/hooks/useLiveShopProducts";
import { applyAdvancedFilters, countActiveAdvancedFilters, DEFAULT_ADVANCED_FILTERS } from "@/utils/catalogFilters";

/**
 * Katalog sahifasiga TEGISHLI qidiruv/filtr holati.
 *
 * OLDIN: qidiruv matni va filtr qiymatlari (`queryKey`, `activeCategory`,
 * `activeType`) Redux'da — ya'ni butun ilova uchun UMUMIY joyda
 * saqlanardi. Bu esa Bosh sahifa (Home) va Katalog sahifasining bir-
 * biriga bog'lanib qolishiga olib kelgan edi: Katalogda muvaffaqiyatsiz
 * qidiruv qilib, Bosh sahifaga o'tilsa, Bosh sahifadagi "Barcha
 * mahsulotlar" ro'yxati ham bo'sh ko'rinardi — chunki ikkalasi ham
 * aynan shu bitta Redux qiymatidan foydalanardi.
 *
 * ENDI: bu holat faqat shu Context orqali, Katalog sahifasining o'z
 * daraxti ICHIDA yashaydi. Bosh sahifa bu haqda umuman bilmaydi va
 * hech qachon undan ta'sirlanmaydi. Katalogdan chiqib ketilganda,
 * Provider o'zi bilan birga demontaj qilinadi — qidiruv holati
 * TABIIY ravishda yo'qoladi, buni qo'lda "tozalash" shart emas.
 */
const CatalogFilterContext = createContext(null);

const applyQuickFilter = (data, key) => {
  if (!data || data.length === 0) return [];
  switch (key) {
    case "new":
      return data.filter((p) => p.isNew === true);
    case "top":
      // MUHIM TUZATISH: bu yerda oldin `p.rating` ishlatilgan edi -
      // lekin mahsulot hujjatida bunday maydon UMUMAN YO'Q (haqiqiy
      // maydon nomi `averageRating`, `reviews.js` trigger orqali
      // hisoblanadi). Natijada "Top" tezkor-filtri HAR DOIM bo'sh
      // natija qaytarardi - hech qanday mahsulot `undefined > 4.8`
      // shartiga mos kelmasdi.
      return data.filter((p) => (Number(p.averageRating) || 0) > 4.8);
    case "aksiya":
      // MUHIM TUZATISH: bu yerda OLDIN `p.stock < 10` (kam qolgan
      // mahsulot) tekshirilardi - bu "Aksiya" (chegirma) bilan HECH
      // QANDAY aloqasi yo'q, chalkashtiruvchi xato edi! Mijoz "Aksiya"
      // tugmasini bossa, kam qolgan (lekin CHEGIRMASIZ) mahsulotlarni
      // ko'rardi. Endi - HAQIQIY chegirma bor mahsulotlar
      // (`useFilterPriduct.jsx`dagi `onSaleProducts` bilan BIR XIL
      // tekshiruv, izchillik uchun).
      return data.filter((p) => p.discountPrice && Number(p.discountPrice) > 0 && Number(p.discountPrice) < Number(p.price));
    case "arzon": {
      const sortedPrices = [...data].map((p) => Number(p.price) || 0).sort((a, b) => a - b);
      const cutoffIndex = Math.max(0, Math.floor(sortedPrices.length * 0.3) - 1);
      const cutoffPrice = sortedPrices[cutoffIndex];
      return data.filter((p) => (Number(p.price) || 0) <= cutoffPrice);
    }
    default:
      return data;
  }
};

export const CatalogFilterProvider = ({ children }) => {
  const { sellerId } = useSession();
  useLiveShopProducts(sellerId);

  const { products = [], loading, error } = useSelector((state) => state.products);

  // MUHIM QO'SHIMCHA: agar URL'da `?quick=aksiya` kabi parametr
  // bo'lsa (masalan CRM xabari yoki banner orqali chuqur havola
  // bilan kirilgan bo'lsa), boshlang'ich tezkor-filtr sifatida
  // ISHLATILADI - shu orqali "faqat aksiyadagi mahsulotlar"ga
  // TO'G'RIDAN-TO'G'RI havola yasash mumkin bo'ladi.
  const [searchParams] = useSearchParams();
  const initialQuickFilter = searchParams.get("quick") || "all";

  const [queryKey, setQueryKey] = useState("");
  const [activeCategory, setActiveCategory] = useState(initialQuickFilter);
  const [activeType, setActiveType] = useState("all");
  // Kengaytirilgan filtr paneli (narx oralig'i, reyting, ombor,
  // narx bo'yicha saralash) - tezkor-filtrlardan MUSTAQIL holat,
  // bularning barchasi bitta obyektda (`utils/catalogFilters.js`ning
  // kutgan shakliga mos).
  const [advancedFilters, setAdvancedFilters] = useState(DEFAULT_ADVANCED_FILTERS);

  const filteredProducts = useMemo(() => {
    let result = [...products];

    if (queryKey) {
      const searchKey = queryKey.toLowerCase();
      result = result.filter((p) => p.name?.toLowerCase().includes(searchKey));
    }

    // Haqiqiy mahsulot kategoriyasi bo'yicha (Skincare/Parfum/Makeup/Soch)
    if (activeType && activeType !== "all") {
      result = result.filter((p) => p.category === activeType);
    }

    result = applyQuickFilter(result, activeCategory);

    return applyAdvancedFilters(result, advancedFilters);
  }, [products, queryKey, activeCategory, activeType, advancedFilters]);

  const activeAdvancedFilterCount = useMemo(() => countActiveAdvancedFilters(advancedFilters), [advancedFilters]);

  const value = useMemo(
    () => ({
      queryKey,
      setQueryKey,
      activeCategory,
      setActiveCategory,
      activeType,
      setActiveType,
      advancedFilters,
      setAdvancedFilters,
      activeAdvancedFilterCount,
      products,
      filteredProducts,
      loading,
      error,
    }),
    [queryKey, activeCategory, activeType, advancedFilters, activeAdvancedFilterCount, products, filteredProducts, loading, error]
  );

  return <CatalogFilterContext.Provider value={value}>{children}</CatalogFilterContext.Provider>;
};

export const useCatalogFilter = () => {
  const ctx = useContext(CatalogFilterContext);
  if (!ctx) {
    throw new Error("useCatalogFilter faqat <CatalogFilterProvider> ichida ishlatilishi kerak");
  }
  return ctx;
};
