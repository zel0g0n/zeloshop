import { useMemo } from "react";
import { useSelector } from "react-redux";
import { useSession } from "@/context/SessionContext";
import { useLiveShopProducts } from "@/hooks/useLiveShopProducts";

// OLDIN: bu hook har bir mahsulot sahifasi ochilganda getProducts() orqali
// "products" kolleksiyasini TO'LIQ (barcha sotuvchilarning) qayta o'qirdi.
// ENDI: allaqachon Redux'da (state.products.products) mavjud bo'lgan,
// JORIY sotuvchiga tegishli, JONLI yangilanadigan ro'yxatdan foydalanamiz.
export const useRelatedProducts = (product) => {
  const { sellerId } = useSession();
  useLiveShopProducts(sellerId);

  const { products } = useSelector((state) => state.products);

  const relatedProducts = useMemo(() => {
    try {
      if (!product || !product.tags || !Array.isArray(product.tags)) return [];

      return products
        .filter((item) => String(item.id) !== String(product.id))
        .filter((item) => Array.isArray(item.tags) && item.tags.some((tag) => product.tags.includes(tag)));
    } catch (error) {
      console.error("Xatolik yuz berdi:", error);
      return [];
    }
  }, [product, products]);

  return relatedProducts;
};
