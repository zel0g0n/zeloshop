import { useEffect } from "react";
import { useDispatch } from "react-redux";
import getProducts from "@/services/products/getProducts";
import { productsLoading, productsLiveUpdated, productsLoadError } from "@/store/slices/product/getProductSlice";

/**
 * Mijoz tomonidagi (do'kon) mahsulot ro'yxatini JONLI (real-vaqtli)
 * ushlab turadi, va Redux keshiga (`state.products`) yozadi — bir
 * necha komponent (Bosh sahifa, Katalog, Bog'liq mahsulotlar) shu
 * bitta keshdan o'qiydi.
 *
 * MUHIM: bu hook HAR BIR mount uchun O'Z obunasini o'rnatadi va
 * unmount'da uni bekor qiladi — "allaqachon yuklangan" tekshiruvi
 * ATAYLAB ishlatilmaydi. Sabab: agar bir sahifadagi komponent
 * unmount bo'lsa (masalan Bosh sahifadan chiqilsa), uning obunasi
 * bekor qilinadi — agar boshqa sahifadagi komponent bu daqiqada
 * "ma'lumot allaqachon yuklangan" deb hisoblab, o'z obunasini
 * o'rnatmasa, hech qanday faol obuna qolmay, ma'lumot ABADIY
 * eskirib qolishi mumkin edi.
 */
export function useLiveShopProducts(sellerId) {
  const dispatch = useDispatch();

  useEffect(() => {
    if (!sellerId) return;

    dispatch(productsLoading());
    const unsubscribe = getProducts(
      sellerId,
      (products) => dispatch(productsLiveUpdated({ products, sellerId })),
      (error) => dispatch(productsLoadError(error.message || "Mahsulotlarni yuklashda xatolik yuz berdi"))
    );

    return () => unsubscribe();
  }, [dispatch, sellerId]);
}
