import { useEffect, useState } from "react";
import { collection, onSnapshot } from "firebase/firestore";
import { db } from "@/firebase/config";

/**
 * CRM uchun mijozlar ro'yxati — ENDI server tomonida OLDINDAN
 * yig'ilgan `sellers/{id}/customers/{clientId}` yozuvlaridan
 * (batafsil izoh: `functions/orderRollups.js`) o'qiladi, XOM
 * buyurtmalar ro'yxatidan EMAS.
 *
 * MUHIM, ARXITEKTURA O'ZGARISHI (real production darajasiga
 * chiqarish, "kengayishni hisobga olgan holda"): OLDIN bu hook
 * sellerning so'nggi 365 KUNLIK buyurtmalarini TO'LIQ yuklab, LTV/
 * segmentatsiyani BRAUZERDA hisoblardi - bu, (a) 365 kundan eski
 * xaridlarni LTV'dan BUTUNLAY chetlab o'tardi (haqiqiy umr bo'yi
 * qiymat emas edi), va (b) buyurtmalar soni o'sgan sari sekinlashardi.
 * Endi bu hook FAQAT MIJOZLAR soniga teng (odatda buyurtmalar
 * sonidan ANCHA kam) kichik yozuvlarni o'qiydi - har biri allaqachon
 * BUTUN tarix bo'yicha to'g'ri LTV/buyurtmalar sonini o'z ichiga
 * oladi, 365 kunlik chegara ENDI YO'Q.
 *
 * Fayl nomi (`useCrmOrders.jsx`) tarixiy sababga ko'ra saqlanib
 * qolgan (`useCustomerSegments.jsx` shu yerdan import qiladi) -
 * ICHKI mazmuni endi butunlay boshqacha.
 */
const useCrmOrders = (sellerId) => {
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!sellerId) {
      setLoading(false);
      return;
    }
    setLoading(true);
    const unsubscribe = onSnapshot(
      collection(db, "sellers", sellerId, "customers"),
      (snapshot) => {
        setCustomers(
          snapshot.docs.map((doc) => {
            const data = doc.data();
            return {
              clientId: doc.id,
              fullName: data.fullName || "",
              phone: data.phone || "",
              ltv: Number(data.ltv) || 0,
              orderCount: Number(data.orderCount) || 0,
              lastOrderAtMs: Number(data.lastOrderAtMs) || 0,
            };
          })
        );
        setLoading(false);
      },
      (err) => {
        setError(err.message);
        setLoading(false);
      }
    );
    return () => unsubscribe();
  }, [sellerId]);

  return { customers, loading, error };
};

export default useCrmOrders;
