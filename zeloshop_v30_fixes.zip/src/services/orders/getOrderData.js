import { db } from '@/firebase/config';
import { collection, query, where, orderBy, limit as fbLimit, Timestamp } from 'firebase/firestore';
import { subscribeWithFastInitial } from '@/services/shared/subscribeWithFastInitial';

const mapOrderDoc = (doc) => {
  const data = doc.data();
  return {
    id: doc.id,
    ...data,
    createdAt: data.createdAt ? data.createdAt.toMillis() : null,
  };
};

// OLDIN: to'g'ridan-to'g'ri `onSnapshot()` — bu birinchi natija
// kelishidan oldin real-vaqtli kanal ulanishini talab qilardi (o'lchov
// bo'yicha ~2.5s). ENDI: `subscribeWithFastInitial` orqali — avval
// tez, bir martalik o'qish, keyin fon rejimida jonli ulanish. Tashqi
// interfeys (parametrlar, qaytariladigan unsubscribe) O'ZGARMADI —
// shuning uchun buni chaqiradigan hook hech narsani bilishi shart emas.
//
// MUHIM: bu funksiya — Buyurtmalar boshqaruv sahifasi uchun
// (qidiruv, filtr, ko'plab tanlash — TO'LIQ ro'yxatga muhtoj).
// OLDIN bu HECH QANDAY chegarasiz edi. Endi standart holatda FAQAT
// so'nggi `pageSize` ta buyurtma yuklanadi ("Yana yuklash" tugmasi
// orqali kengaytiriladi) — sotuvchining tarixi yillar davomida
// qancha katta bo'lishidan qat'i nazar, sahifa DASTLABKI tez ochiladi.
const getOrderData = (sellerId, onSuccess, onError, pageSize = 150) => {
  if (!sellerId) throw new Error("Seller ID ko'rsatilmadi!");

  const q = query(
    collection(db, 'orders'),
    where("sellerId", "==", sellerId),
    orderBy("createdAt", "desc"),
    fbLimit(pageSize)
  );

  return subscribeWithFastInitial(q, mapOrderDoc, onSuccess, onError);
};

/**
 * Dashboard uchun — faqat so'nggi N kunlik buyurtmalarni yuklaydi.
 * Sotuvchining butun tarixi qancha katta bo'lishidan qat'i nazar,
 * bu so'rov har doim CHEGARALANGAN, bir xil hajmda qoladi.
 */
export const getRecentOrderData = (sellerId, daysBack, onSuccess, onError) => {
  if (!sellerId) throw new Error("Seller ID ko'rsatilmadi!");

  const cutoff = new Date();
  cutoff.setDate(cutoff.getDate() - daysBack);
  cutoff.setHours(0, 0, 0, 0);

  const q = query(
    collection(db, 'orders'),
    where("sellerId", "==", sellerId),
    where("createdAt", ">=", Timestamp.fromDate(cutoff)),
    orderBy("createdAt", "desc")
  );

  return subscribeWithFastInitial(q, mapOrderDoc, onSuccess, onError);
};

/**
 * BITTA mijozning TO'LIQ xarid tarixini yuklaydi — CRM Hub'dagi
 * mijoz tafsilotlari oynasi uchun.
 *
 * MUHIM, ARXITEKTURA IZOHI: mijozlar RO'YXATI (segmentatsiya/LTV)
 * endi server tomonida oldindan hisoblangan YIG'MA yozuvlardan
 * (`useCrmCustomers`/`customers` kolleksiyasi) o'qiladi - u yerda
 * har bir buyurtmaning O'ZI (alohida qatorlari) SAQLANMAYDI, faqat
 * jamlangan sonlar (LTV, buyurtmalar soni). Shuning uchun, mijoz
 * kartochkasi bosilganda, uning TO'LIQ xarid tarixini ko'rsatish
 * uchun BU YERDA, TALAB BO'YICHA (faqat o'sha BITTA mijoz uchun,
 * ro'yxatdagi HAMMA mijozlar uchun EMAS) alohida so'rov yuboriladi -
 * bu, ro'yxat ochilganda BARCHA mijozlarning BARCHA buyurtmalarini
 * oldindan yuklab olishdan (eski, ko'lamga chidamsiz yondashuv)
 * ANCHA arzon.
 */
export const getCustomerOrderHistory = (sellerId, clientId, onSuccess, onError) => {
  if (!sellerId || !clientId) throw new Error("Sotuvchi yoki mijoz ID'si ko'rsatilmadi!");

  const q = query(
    collection(db, 'orders'),
    where("sellerId", "==", sellerId),
    where("clientId", "==", clientId),
    orderBy("createdAt", "desc"),
    fbLimit(200)
  );

  return subscribeWithFastInitial(q, mapOrderDoc, onSuccess, onError);
};

export default getOrderData;
