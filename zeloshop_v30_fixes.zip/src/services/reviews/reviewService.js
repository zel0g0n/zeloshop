import { httpsCallable } from "firebase/functions";
import { functions, db } from "@/firebase/config";
import { collection, query, orderBy, onSnapshot } from "firebase/firestore";

export const submitProductReview = async (productId, rating, text) => {
  const callable = httpsCallable(functions, "submitProductReview");
  const { data } = await callable({ productId, rating, text });
  return data;
};

export const moderateProductReview = async (productId, reviewId, action) => {
  const callable = httpsCallable(functions, "moderateProductReview");
  const { data } = await callable({ productId, reviewId, action });
  return data;
};

/**
 * Mahsulot sharhlarini JONLI (real-vaqtli) kuzatadi — pin qilingan
 * sharh birinchi, qolganlari eng yangisidan boshlab.
 */
export const subscribeToProductReviews = (productId, onSuccess, onError) => {
  if (!productId) {
    onSuccess([]);
    return () => {};
  }
  const reviewsQuery = query(
    collection(db, "products", productId, "reviews"),
    orderBy("pinned", "desc"),
    orderBy("createdAt", "desc")
  );
  return onSnapshot(
    reviewsQuery,
    (snap) => onSuccess(snap.docs.map((d) => ({ id: d.id, ...d.data() }))),
    onError
  );
};
