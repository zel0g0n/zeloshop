import { httpsCallable } from "firebase/functions";
import { functions } from "@/firebase/config";

/**
 * "Hafta"/"Oy" davrlari uchun noyob tashriflar sonini serverdan
 * so'raydi (mijoz SDK'i `visits` kolleksiyasini to'g'ridan-to'g'ri
 * o'qiy olmaydi — Firestore qoidalari buni taqiqlaydi).
 */
export const getVisitorCount = async (sellerId, daysBack) => {
  const callable = httpsCallable(functions, "getVisitorCount");
  const { data } = await callable({ sellerId, daysBack });
  return data.visitorCount;
};
