import { db } from "@/firebase/config.js";
import { collection, query, where } from "firebase/firestore";
import { subscribeWithFastInitial } from "@/services/shared/subscribeWithFastInitial";

// OLDIN: BUTUN "products" kolleksiyasi (barcha sotuvchilarning barcha
// mahsulotlari) yuklanardi, hech qanday sotuvchi bo'yicha filtrsiz.
// Bu — ilovaning ENG MUHIM izolyatsiya talabini buzardi. Endi FAQAT
// shu sotuvchining mahsulotlari Firestore darajasida (`where`)
// filtrlanadi.
//
// KEYINGI TUZATISH: OLDIN bu — bir martalik `getDocs()` edi. Bu
// degani, sotuvchi biror mahsulotni O'CHIRGANDA yoki BUYURTMA
// YETKAZILIB, ombor kamayganda — mijoz tomonida bu O'ZGARISHLAR
// sahifa QAYTA YUKLANMAGUNCHA ko'RINMASDI (eskirgan ma'lumot
// ko'rsatilardi). Endi — boshqa real-vaqtli xizmatlar kabi —
// `subscribeWithFastInitial` orqali (tez, bir martalik o'qish +
// fon rejimida jonli ulanish), o'zgarishlar DARHOL ko'rinadi.
const mapProductDoc = (doc) => ({ ...doc.data(), id: doc.id });

const getProducts = (sellerId, onSuccess, onError) => {
  if (!sellerId) {
    onSuccess([]);
    return () => {};
  }
  const scopedQuery = query(collection(db, "products"), where("sellerId", "==", sellerId));
  return subscribeWithFastInitial(scopedQuery, mapProductDoc, onSuccess, onError);
};

export default getProducts;
