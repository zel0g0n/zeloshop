import { useState, memo } from "react";
import { FaHeart, FaRegHeart, FaPlus, FaMinus } from "react-icons/fa";
import { MdOutlineShoppingBag } from "react-icons/md";
import { Share2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Link } from "react-router-dom";
import { useAddFavorite } from "@/hooks/useAddFavourite.jsx";
import { useAddToCart } from "@/hooks/useAddToCard";
import { useSession } from "@/context/SessionContext";
import { buildDeepLink } from "@/utils/shareLink";
import { buildProductShareText } from "@/utils/productShareText";
import { useLanguage } from "@/context/LanguageContext";


// OLDIN: `Intl.NumberFormat(..., { currency: 'USD' })` ishlatilgan edi —
// bu mahsulot kartochkalarida narxlarni "$" (dollar) belgisi bilan
// ko'rsatardi, holbuki butun qolgan ilova (checkout, mahsulot sahifasi,
// sotuvchi paneli) "so'm" ishlatadi. Bu — eng ko'p ko'rinadigan joyda
// (bosh sahifa, katalog) valyuta nomuvofiqligi edi.
const formatPrice = (value) => `${(Number(value) || 0).toLocaleString()} so'm`;

// MUHIM TUZATISH: OLDIN faqat CSS `line-clamp-1` ga tayanilgan edi -
// bu, NAZARIY jihatdan sarlavhani bitta qatorga cheklashi kerak edi,
// lekin foydalanuvchi HAR XIL uzunlikdagi nomlar bilan kartochka
// balandligi FARQ QILISHINI ANIQ payqadi. CSS'ning o'zi (brauzer/
// build muhitiga bog'liq bo'lishi mumkin) YETARLI ISHONCHLI EMAS
// ekan - shuning uchun endi nom matnining O'ZI, JavaScript darajasida,
// QAT'IY belgilar soniga kesiladi (ellipsis bilan). Bu - CSS qanday
// render qilinishidan MUSTAQIL, 100% kafolatlangan yechim: kesilgan
// matn HAR DOIM bir xil maksimal uzunlikda, demak bir xil balandlikda
// bo'ladi.
const MAX_NAME_LENGTH = 28;
const truncateName = (name) => {
  if (!name || name.length <= MAX_NAME_LENGTH) return name;
  return `${name.slice(0, MAX_NAME_LENGTH).trimEnd()}…`;
};


const ProductCard = ({ product }) => {
  const { t } = useLanguage();
  const { id, name, price, discountPrice, image, isNew, type } = product;
  const displayName = truncateName(name);
  const [imageLoaded, setImageLoaded] = useState(false);
  const [imageError, setImageError] = useState(false);
  const { isFavorite, toggleFavorite } = useAddFavorite(product);
  const { sellerId } = useSession();

  const { isInCart, quantity, toggleCart, incrementQuantity, decrementQuantity } = useAddToCart(product);


  const handleAddToCartClick = (e) => {
    e.preventDefault();
    e.stopPropagation();
    toggleCart();
  };


  const handlePlusClick = (e) => {
    e.preventDefault();
    e.stopPropagation();
    incrementQuantity(); // Hook ichidagi dispatch ishlaydi
  };


  const handleMinusClick = (e) => {
    e.preventDefault();
    e.stopPropagation();
    decrementQuantity(); // Hook ichidagi dispatch ishlaydi
  };


  const handleLike = (e) => {
    e.preventDefault();
    e.stopPropagation();
    toggleFavorite();
  };

  const handleShare = async (e) => {
    e.preventDefault();
    e.stopPropagation();
    const productLink = buildDeepLink(sellerId, `/product/${id}`);
    const shareText = buildProductShareText(product);

    if (navigator.share) {
      try {
        await navigator.share({ title: name, text: shareText, url: productLink });
      } catch {
        // Foydalanuvchi bekor qilgan - jim qolamiz.
      }
      return;
    }
    const shareUrl = `https://t.me/share/url?url=${encodeURIComponent(productLink)}&text=${encodeURIComponent(shareText)}`;
    window.open(shareUrl, "_blank");
  };


  return (
    <Link to={`/product/${id}`} className="w-full block transform-gpu">
      <motion.article
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.3 }}
        // MUHIM, YAKUNIY TUZATISH: OLDIN balandlik Tailwind'ning
        // `h-[300px]` KABI "arbitrary value" sinflari orqali
        // berilgan edi. Foydalanuvchi buni ikki marta tekshirib,
        // hamon nomuvofiqlik borligini aniq ko'rsatdi - shuning
        // uchun endi balandlik TO'G'RIDAN-TO'G'RI INLINE STYLE
        // orqali beriladi (`style={{height: ...}}`) - bu, brauzerda
        // ENG YUQORI CSS ustuvorlikka ega va Tailwind qurilish
        // (build) jarayonidagi HECH QANDAY nozikликка (masalan
        // sinflarning noto'g'ri generatsiya qilinishi) BOG'LIQ
        // EMAS - garov yo'q, balandlik SO'ZSIZ aniq piksel bo'ladi.
        //
        // MUHIM, YANGI TUZATISH: pastdagi barcha ICHKI bloklarning
        // (rasm 180px + p-3 padding 12+12px + sarlavha 18px + mb-1
        // 4px + narx-tugma bloki gap-2 bilan 20+8+48px) YIG'INDISI
        // ANIQ 302px - avval 300px edi, ya'ni 2px YETISHMAS edi
        // (kartochka `overflow-hidden` bilan kesib tashlagani uchun
        // ko'zga unchalik tashlanmasdi, lekin ba'zi holatlarda pastki
        // qatorning bir necha pikseli kesilib qolishi mumkin edi).
        // Endi ANIQ mos qilib tuzatildi - hech narsa kesilmaydi.
        style={{ height: "302px" }}
        className="group relative w-full flex flex-col overflow-hidden rounded-2xl border border-slate-100 dark:border-slate-800 bg-slate-50/90 dark:bg-slate-900 shadow-md transition-all duration-300 active:scale-[0.98]"
      >
        {/* BADGES & LIKES */}
        <div className="absolute left-3 top-3 z-20 flex flex-col gap-1.5">
          {isNew && (
            <span className="rounded-full bg-blue-600 px-2.5 py-1 text-[10px] font-black text-white shadow-sm">
              {t("productCard.new")}
            </span>
          )}
        </div>

        {/* MUHIM QO'SHIMCHA: mahsulotni ulashish - foydalanuvchi so'rovi
            bo'yicha qo'shildi. Bosilganda, qurilma darajasidagi
            "ulashish" oynasi ochiladi (Telegram, Instagram, SMS va
            h.k.) - tayyor, "SMM darajasidagi" matn bilan birga.
            MUHIM JOYLASHUV TUZATISHI: bu tugma endi RASM KONTEYNERI
            ICHIDA joylashgan (pastda), `bottom-3 right-3` bilan -
            shu orqali rasmning O'ZINING pastki-o'ng burchagiga
            aniq mos keladi (avval tashqarida, chap-yuqorida edi -
            UI/UX jihatdan noqulay ko'rinardi). */}

        <motion.button
          type="button"
          onClick={handleLike}
          aria-label={isFavorite ? `${name} - ${t("productCard.removeFromWishlist")}` : `${name} - ${t("productCard.addToWishlist")}`}
          whileTap={{ scale: 0.7 }}
          transition={{ type: "spring", stiffness: 500, damping: 15 }}
          className={`absolute right-3 top-3 z-20 flex h-10 w-10 items-center justify-center rounded-full transition-colors duration-300 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600 ${
            isFavorite ? "bg-blue-600 text-white shadow-md" : "bg-white/95 dark:bg-slate-800/95 text-slate-400"
          }`}
        >
          {isFavorite ? <FaHeart size={16} /> : <FaRegHeart size={16} />}
        </motion.button>


        <div style={{ height: "180px" }} className="relative w-full rounded-b-xl bg-slate-200 dark:bg-slate-800">
          {!imageLoaded && !imageError && <div className="absolute inset-0 bg-slate-200 dark:bg-slate-800 animate-pulse" />}
          {imageError ? (
            <div className="absolute inset-0 flex items-center justify-center bg-slate-100 dark:bg-slate-800 text-slate-300 dark:text-slate-600">
              <MdOutlineShoppingBag size={32} />
            </div>
          ) : (
            <img
              src={image}
              alt={name}
              loading="lazy"
              decoding="async"
              onLoad={() => setImageLoaded(true)}
              onError={() => setImageError(true)}
              className={`h-full w-full object-cover transition-transform duration-500 ${imageLoaded ? "opacity-100" : "opacity-0"}`}
            />
          )}

          <button
            type="button"
            onClick={handleShare}
            aria-label={t("productCard.share")}
            className="absolute right-3 bottom-3 z-20 flex h-8 w-8 items-center justify-center rounded-full bg-white/95 dark:bg-slate-800/95 text-slate-500 dark:text-slate-300 shadow-sm active:scale-90 transition-transform"
          >
            <Share2 size={13} />
          </button>
        </div>


        {/* MUHIM: bu qism qat'iy (`shrink-0`) balandlikka ega —
            sarlavha `line-clamp-1` bilan HAR DOIM bitta qatorga
            cheklangan, narx qismi ham doim bitta qatorlik joy oladi
            (chegirma bor-yo'qligidan qat'i nazar) — shu orqali barcha
            kartochkalarning pastki qismi ANIQ bir xil balandlikda bo'ladi. */}
        <div className="p-3 shrink-0">
          <h3 style={{ height: "18px" }} className="text-[14px] font-bold text-slate-900 dark:text-white mb-1 line-clamp-1 overflow-hidden">
            {displayName}
          </h3>


          <div className="flex flex-col gap-2 justify-between">
            <div style={{ height: "20px" }} className="w-full overflow-hidden">
              <span className="text-[16px] font-black tracking-tighter mr-2 text-blue-700 dark:text-blue-400">
                {formatPrice(discountPrice && Number(discountPrice) < Number(price) ? discountPrice : price)}
              </span>
              {discountPrice && Number(discountPrice) < Number(price) && (
                <span className="text-[13px] font-medium text-slate-400 line-through decoration-red-400/40">{formatPrice(price)}</span>
              )}
            </div>


            <div style={{ height: "48px" }} className="w-full relative">
              <AnimatePresence mode="wait">
                {isInCart ? (
                  <motion.div
                    key="counter"
                    initial={{ scale: 0.95, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 0.95, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                    className="flex h-full w-full items-center justify-between rounded-2xl bg-slate-100/80 dark:bg-slate-800 border border-slate-200/50 dark:border-slate-700 p-1.5"
                  >
                    <button
                      type="button"
                      onClick={handleMinusClick}
                      aria-label={`${name} - ${t("productCard.decreaseQty")}`}
                      className="flex h-9 w-9 items-center justify-center rounded-xl bg-white dark:bg-slate-700 text-slate-700 dark:text-slate-200 shadow-sm active:scale-90 hover:bg-slate-50 dark:hover:bg-slate-600 transition-all cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600"
                    >
                      <FaMinus size={10} />
                    </button>

                    <div className="flex flex-col items-center justify-center flex-1">
                      <span className="text-sm font-black text-slate-800 dark:text-white tracking-tight leading-none">
                        {quantity} ta
                      </span>
                    </div>

                    <button
                      type="button"
                      onClick={handlePlusClick}
                      aria-label={`${name} - ${t("productCard.increaseQty")}`}
                      className="flex h-9 w-9 items-center justify-center rounded-xl bg-blue-600 text-white shadow-sm shadow-blue-600/10 active:scale-90 hover:bg-blue-700 transition-all cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600"
                    >
                      <FaPlus size={10} />
                    </button>
                  </motion.div>
                ) : (
                  <motion.button
                    key="add-button"
                    type="button"
                    onClick={handleAddToCartClick}
                    aria-label={`${name} - ${t("productCard.addToCart")}`}
                    initial={{ scale: 0.95, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 0.95, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                    className="flex h-full w-full items-center justify-center rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 px-7 py-4 text-sm font-bold text-white shadow-[0_10px_25px_rgba(37,99,235,0.25)] active:scale-95 transition-all cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
                  >
                    <MdOutlineShoppingBag size={20} className="mr-2" />
                    <span>{t("productCard.addToCart")}</span>
                  </motion.button>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </motion.article>
    </Link>
  );
};


ProductCard.displayName = "ProductCard";
export default memo(ProductCard);
