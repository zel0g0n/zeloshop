import { memo } from 'react';
import ProductCard from './ProductCard';

// MUHIM TUZATISH: `contain-intrinsic-size` — brauzerga elementning
// HALI RENDER QILINMAGAN holatidagi TAXMINIY o'lchamini aytadi
// (`content-visibility-auto` bilan birga ishlaydi, uzoqdagi
// elementlarni render qilishni "kechiktirib", tezlik uchun). Bu
// qiymat OLDIN `420px` edi, lekin `ProductCard.jsx`ning HAQIQIY
// balandligi — `300px`! Bu NOMUVOFIQLIK, nazariy jihatdan, element
// birinchi marta "ko'rinishga kirganda" bir lahzalik o'lcham sakrashi
// (joy o'zgarishi)ga sabab bo'lishi mumkin edi. Endi ikkalasi BIR XIL.
//
// MUHIM, YANGI TUZATISH: gorizontal skroll qatorida (bosh sahifadagi
// "Ko'p sotilganlar"/"Yangi qo'shilganlar" kabi) kartochkalarning
// KENGLIGI turli xil ko'rinar edi. Sabab: wrapper faqat `min-w`
// (minimal kenglik) belgilagan, HAQIQIY `width` esa yo'q edi — flex
// qatorida, aniq `width` bo'lmasa, brauzer har bir elementning
// kengligini uning ICHIDAGI kontent asosida ("auto" flex-basis)
// hisoblaydi, bu esa kartochkadan-kartochkaga farq qilishi mumkin
// edi. Endi wrapper aniq, QAT'IY `width` oladi (`shrink-0` bilan —
// flex uni SIQIB kichraytirmasligi uchun) — barcha kartochkalar,
// kontentidan qat'i nazar, 100% bir xil kenglikda bo'ladi.
const ProductList = memo(({ products, filterTypeStyle, isHorizontal = true }) => {
  return (
    <div className="w-full mb-8">
      <div className={filterTypeStyle}>
        {products.map((product) => (
          <div
            key={product.id}
            className={`
              content-visibility-auto
              contain-intrinsic-size-[280px_302px]
              ${isHorizontal
                ? "w-[240px] xs:w-[280px] shrink-0 snap-start snap-always"
                : "w-full"
              }
            `}
          >
            <ProductCard product={product} />
          </div>
        ))}
        {isHorizontal && <div className="min-w-[20px] h-full flex-shrink-0" />}
      </div>
    </div>
  );
});

ProductList.displayName = "ProductList";
export default ProductList;