import React, { useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, CreditCard, Check, Sparkles, Send } from "lucide-react";
import { httpsCallable } from "firebase/functions";
import { functions } from "@/firebase/config";
import { useSession } from "@/context/SessionContext";
import StatusModal from "@/components/ui/StatusModal";
import { useLanguage } from "@/context/LanguageContext";

// HALOL IZOH: platforma hozircha o'zining to'lov yig'ish tizimiga ega
// emas (arxitektura ATAYLAB markazlashtirilmagan — har bir sotuvchi
// o'z Click/Payme hisobini ulaydi, pul to'g'ridan-to'g'ri sotuvchiga
// tushadi). Shuning uchun bu yerda "Pro'ni sotib olish" tugmasi YO'Q
// — soxta to'lov oqimi yaratish o'rniga, sotuvchi qiziqishini ADMIN'ga
// HAQIQIY xabar sifatida yuboramiz.
//
// MUHIM TUZATISH (haqiqiy, noto'g'ri ma'lumot topildi): PRO
// xususiyatlar ro'yxati OLDIN "Cheksiz P&L tahlili" va "Avtomatik
// CRM push xabarlari"ni PRO'GA XOS deb ko'rsatardi - lekin bu
// IKKALASI HAM aslida BEPUL, HAR BIR sotuvchi uchun ALLAQACHON
// OCHIQ edi (kodda `aiCeoEnabled` bilan HECH QANDAY cheklanmagan)!
// Bu, sotuvchini CHALG'ITUVCHI, noto'g'ri reklama edi. Endi ro'yxat
// FAQAT haqiqatan `aiCeoEnabled` bilan cheklangan (AI CEO)
// funksiyalarni ko'rsatadi. Shu bilan birga, foydalanuvchi so'ragan
// BASIC (bepul) tarifning xususiyatlari ham ALOHIDA ro'yxatda,
// aniq ko'rsatiladi.
const PRO_FEATURE_KEYS = ["proFeature1", "proFeature2", "proFeature3", "proFeature4"];
const BASIC_FEATURE_KEYS = ["basicFeature1", "basicFeature2", "basicFeature3", "basicFeature4", "basicFeature5", "basicFeature6"];

const TariffsPage = () => {
  const navigate = useNavigate();
  const { t } = useLanguage();
  const { store } = useSession();

  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState(null);

  const handleExpressInterest = useCallback(async () => {
    setSending(true);
    setError(null);
    try {
      const contactAdmin = httpsCallable(functions, "contactAdmin");
      await contactAdmin({
        category: "pro-interest",
        message: t("tariffs.interestMessage"),
      });
      setSent(true);
    } catch (err) {
      setError(err.message || t("tariffs.sendError"));
    } finally {
      setSending(false);
    }
  }, []);

  return (
    <div className="min-h-screen bg-[#F4F5F9] dark:bg-slate-950 text-slate-900 dark:text-white font-sans antialiased pb-36 transition-colors duration-300">

      <div className="sticky top-0 z-30 bg-white/95 dark:bg-slate-900/95 px-4 py-4 shadow-xs flex items-center gap-3">
        <button type="button" onClick={() => navigate(-1)} className="p-1 text-slate-500 dark:text-slate-300 active:scale-95 transition-transform">
          <ArrowLeft size={20} />
        </button>
        <div>
          <h1 className="text-base font-black text-slate-800 dark:text-white">{t("tariffs.title")}</h1>
          <p className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">{t("tariffs.subtitle")}</p>
        </div>
      </div>

      <div className="p-4 space-y-4">
        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-xs">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-11 h-11 bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 rounded-xl flex items-center justify-center shrink-0">
              <CreditCard size={20} />
            </div>
            <div className="min-w-0">
              <p className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">{t("tariffs.currentPlanLabel")}</p>
              <p className="text-base font-black text-slate-800 dark:text-white">{t("tariffs.basicPlan")}</p>
            </div>
          </div>
          <div className="space-y-2 pt-1 border-t border-slate-50 dark:border-slate-800">
            {BASIC_FEATURE_KEYS.map((key) => (
              <div key={key} className="flex items-center gap-2 pt-2">
                <div className="w-4 h-4 rounded-full bg-emerald-50 dark:bg-emerald-500/10 text-emerald-500 flex items-center justify-center shrink-0">
                  <Check size={11} />
                </div>
                <span className="text-xs font-medium text-slate-600 dark:text-slate-300">{t(`tariffs.${key}`)}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-gradient-to-br from-[#5346E0] to-[#4338CA] rounded-[24px] p-5 text-white shadow-lg shadow-indigo-600/20">
          <div className="flex items-center gap-1.5 mb-1">
            <Sparkles size={15} />
            <span className="text-xs font-black uppercase tracking-wider">{t("tariffs.proTitle")}</span>
          </div>
          <p className="text-[11px] text-indigo-200/90 mb-4">{t("tariffs.proSubtitle")}</p>

          <div className="space-y-2 mb-5">
            {PRO_FEATURE_KEYS.map((key) => (
              <div key={key} className="flex items-center gap-2">
                <div className="w-4 h-4 rounded-full bg-white/15 flex items-center justify-center shrink-0">
                  <Check size={11} />
                </div>
                <span className="text-xs font-medium text-white/90">{t(`tariffs.${key}`)}</span>
              </div>
            ))}
          </div>

          <button
            type="button"
            onClick={handleExpressInterest}
            disabled={sending || sent}
            className="w-full h-11 bg-white text-indigo-700 font-black text-xs rounded-xl flex items-center justify-center gap-1.5 active:scale-95 transition-transform disabled:opacity-70"
          >
            <Send size={13} />
            {sent ? (<><Check size={13} className="inline" /> {t("tariffs.messageSent")}</>) : sending ? t("tariffs.sending") : t("tariffs.expressInterest")}
          </button>
          {error && <p className="text-[11px] text-rose-200 font-semibold mt-2 text-center">{error}</p>}
        </div>

        <div className="bg-amber-50 dark:bg-amber-500/10 border border-amber-100 dark:border-amber-500/20 p-3.5 rounded-2xl">
          <p className="text-xs text-amber-800 dark:text-amber-300 leading-relaxed">
            <strong>{t("tariffs.noteLabel")}</strong> {t("tariffs.noteText")}
          </p>
        </div>
      </div>

      {sent && (
        <StatusModal
          variant="success"
          title={t("tariffs.sentModalTitle")}
          message={t("tariffs.sentModalMessage", { storeName: store?.storeName || t("tariffs.defaultStoreName") })}
          onClose={() => setSent(false)}
        />
      )}
    </div>
  );
};

export default TariffsPage;
