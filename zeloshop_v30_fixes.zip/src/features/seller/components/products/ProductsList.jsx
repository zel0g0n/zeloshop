import React, { memo } from 'react'
import ProductItem from './ProductItem'

// OLDIN: mahsulotlar 2 ustunli katakda (`sm:grid-cols-2`) ko'rsatilardi.
// Endi — spetsifikatsiyaga mos, YAGONA ustunli, ixcham ro'yxat (har
// bir mahsulot — o'zining, to'liq kenglikdagi qatorida).
const ProductsList = ({ products, selectedIds, onToggleSelect, onEditProduct, onDuplicate, onToggleActive, onDelete, onInlineUpdate }) => {
  return (
    <div>
      {products.map((product) => (
        <ProductItem
          key={product.id}
          prod={product}
          isSelected={selectedIds.has(product.id)}
          onToggleSelect={onToggleSelect}
          onEdit={onEditProduct}
          onDuplicate={onDuplicate}
          onToggleActive={onToggleActive}
          onDelete={onDelete}
          onInlineUpdate={onInlineUpdate}
        />
      ))}
    </div>
  )
}

export default memo(ProductsList)
