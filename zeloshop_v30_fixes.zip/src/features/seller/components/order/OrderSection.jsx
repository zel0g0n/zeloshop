import { useState, useMemo, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, ShoppingBag, BarChart3, ChevronRight } from 'lucide-react';
import useGetOrdersData from '@/hooks/seller/useFilterOrders';
import { useLanguage } from '@/context/LanguageContext';
import OrderRow from './OrderCard';
import OrdersBulkActionBar from './OrdersBulkActionBar';
import OrdersSkeleton from './OrdersSkeleton';
import Toast from '@/components/ui/Toast';
import { useSession } from '@/context/SessionContext';
import { ORDER_STATUS_TABS, getOrderStatusInfo } from '@/constants/orderStatus';
import bulkUpdateOrders from '@/services/orders/bulkUpdateOrders';
import { filterOrders, computeOrderNumbers, computeDeliveredRevenue, computeActiveOrdersCount } from '@/utils/orderFilters';

const SellerOrdersPage = () => {
  const { t } = useLanguage();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('new');
  const [searchQuery, setSearchQuery] = useState('');
  const { sellerId } = useSession();
  const { orders = [], loading, hasMore, loadMore } = useGetOrdersData(sellerId);
  const [selectedIds, setSelectedIds] = useState(new Set());
  const [bulkBusy, setBulkBusy] = useState(false);
  const [bulkError, setBulkError] = useState(null);
  const [toastMessage, setToastMessage] = useState(null);

  const isLoading = loading;

  const filteredOrders = useMemo(
    () => filterOrders(orders, { activeTab, searchQuery }),
    [orders, activeTab, searchQuery]
  );

  const orderNumbers = useMemo(() => computeOrderNumbers(orders), [orders]);
  const totalRevenue = useMemo(() => computeDeliveredRevenue(orders), [orders]);
  const activeOrdersCount = useMemo(() => computeActiveOrdersCount(orders), [orders]);

  const handleToggleSelect = useCallback((id) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }, []);

  const handleBulkAction = useCallback(async (newStatus) => {
    setBulkBusy(true);
    setBulkError(null);
    try {
      await bulkUpdateOrders(Array.from(selectedIds), newStatus);
      setSelectedIds(new Set());
    } catch (err) {
      setBulkError(err.message);
    } finally {
      setBulkBusy(false);
    }
  }, [selectedIds]);

  return (
    <div className="h-screen flex flex-col bg-[#f8fafc] dark:bg-slate-950 transition-colors duration-300">

      <div className="shrink-0 sticky top-0 z-40 bg-[#f8fafc]/95 dark:bg-slate-950/95 border-b border-gray-100 dark:border-slate-800 p-4 space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-lg font-black text-[#1e293b] dark:text-white">{t("sellerOrders.title")}</h1>
            <p className="text-[10px] font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider">{t("sellerOrders.subtitle")}</p>
          </div>
          <button
            type="button"
            onClick={() => navigate("/seller/orders/analytics")}
            className="group shrink-0 flex items-center gap-2 pl-2 pr-2.5 py-1.5 rounded-2xl bg-gradient-to-br from-indigo-50 to-indigo-100/60 dark:from-indigo-500/15 dark:to-indigo-500/5 border border-indigo-100 dark:border-indigo-500/20 active:scale-95 transition-transform"
          >
            <span className="relative w-8 h-8 rounded-xl bg-indigo-600 flex items-center justify-center shrink-0 shadow-sm shadow-indigo-600/30">
              <BarChart3 size={14} className="text-white" />
              <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-emerald-400 border-2 border-white dark:border-slate-950 animate-pulse" />
            </span>
            <div className="text-right leading-tight">
              <span className="block text-xs font-black text-slate-800 dark:text-white">{totalRevenue.toLocaleString()} so'm</span>
              <span className="block text-[10px] font-bold text-indigo-600 dark:text-indigo-400">{activeOrdersCount} {t("sellerOrders.activeSuffix")}</span>
            </div>
            <ChevronRight size={13} className="text-indigo-400 dark:text-indigo-500 shrink-0 group-active:translate-x-0.5 transition-transform" />
          </button>
        </div>

        <div className="relative">
          <span className="absolute inset-y-0 left-3 flex items-center text-gray-400 dark:text-slate-500">
            <Search size={15} />
          </span>
          <input
            type="text"
            placeholder={t("sellerOrders.searchPlaceholder")}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full h-10 pl-9 pr-4 bg-white dark:bg-slate-900 border border-gray-100 dark:border-slate-800 rounded-xl text-xs font-semibold text-gray-800 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500 placeholder:text-gray-400 dark:placeholder:text-slate-500"
          />
        </div>

        <div className="flex gap-2 overflow-x-auto whitespace-nowrap scrollbar-hide -mx-4 px-4">
          {ORDER_STATUS_TABS.map((status) => {
            const info = getOrderStatusInfo(status);
            const count = orders.filter((o) => o.status === status).length;
            const isActive = activeTab === status;
            return (
              <button
                key={status}
                onClick={() => setActiveTab(status)}
                className={`shrink-0 px-3.5 py-2 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 ${
                  isActive
                    ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                    : 'bg-white dark:bg-slate-900 text-gray-600 dark:text-slate-300 border border-gray-100 dark:border-slate-800'
                }`}
              >
                <span>{t(`orderStatus.${info.key}`)}</span>
                <span className={`px-1.5 py-0.5 rounded-md text-[10px] ${isActive ? 'bg-white/20 text-white' : 'bg-gray-100 dark:bg-slate-800 text-gray-500 dark:text-slate-400'}`}>
                  {count}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-4 pb-36 pt-3 max-w-md mx-auto w-full">
        {bulkError && <div className="text-center py-2 text-rose-500 dark:text-rose-400 text-xs font-semibold">{bulkError}</div>}

        {selectedIds.size > 0 && (
          <OrdersBulkActionBar
            selectedCount={selectedIds.size}
            busy={bulkBusy}
            onCancelReset={() => setSelectedIds(new Set())}
            onApprove={() => handleBulkAction("processing")}
            onShip={() => handleBulkAction("shipped")}
            onCancel={() => handleBulkAction("cancel")}
          />
        )}

        {isLoading && <OrdersSkeleton />}

        {!isLoading && filteredOrders.length === 0 && (
          <div className="flex flex-col items-center justify-center py-20 text-center gap-2">
            <div className="w-14 h-14 rounded-2xl bg-white dark:bg-slate-900 border border-gray-100 dark:border-slate-800 flex items-center justify-center text-gray-400 dark:text-slate-500">
              <ShoppingBag size={24} />
            </div>
            <p className="text-sm font-bold text-gray-700 dark:text-slate-200">{t("sellerOrders.emptyState")}</p>
          </div>
        )}

        {!isLoading && filteredOrders.length > 0 && (
          <div className="space-y-3">
            {filteredOrders.map((order) => (
              <OrderRow
                key={order.id}
                order={order}
                orderNumber={orderNumbers.get(order.id)}
                isSelected={selectedIds.has(order.id)}
                onToggleSelect={handleToggleSelect}
                onCopied={() => setToastMessage(t("sellerOrders.copied"))}
              />
            ))}
          </div>
        )}

        {!isLoading && hasMore && (
          <button
            type="button"
            onClick={loadMore}
            className="w-full h-11 mt-3 bg-white dark:bg-slate-900 border border-gray-100 dark:border-slate-800 text-indigo-600 dark:text-indigo-400 font-bold text-xs rounded-2xl active:scale-95 transition-transform"
          >
            {t("sellerOrders.loadMore")}
          </button>
        )}
      </div>

      {toastMessage && <Toast message={toastMessage} onDone={() => setToastMessage(null)} />}
    </div>
  );
};

export default SellerOrdersPage;
