import React, { memo } from "react";
import { X, Truck, CheckCircle2, Ban } from "lucide-react";
import { useLanguage } from "@/context/LanguageContext";

const OrdersBulkActionBar = ({ selectedCount, onApprove, onShip, onCancel, onCancelReset, busy }) => {
  const { t } = useLanguage();
  return (
    <div className="sticky top-0 z-30 bg-indigo-600 text-white px-4 py-2.5 flex items-center justify-between rounded-2xl shadow-md mb-2.5 animate-fade-in">
      <div className="flex items-center gap-2">
        <button onClick={onCancelReset} className="w-6 h-6 rounded-full bg-white/15 text-white flex items-center justify-center" aria-label={t("sellerProducts.bulkCancel")}>
          <X size={13} />
        </button>
        <span className="text-xs font-black">{t("sellerProducts.bulkSelected", { count: selectedCount })}</span>
      </div>

      <div className="flex items-center gap-1.5">
        <button type="button" disabled={busy} onClick={onApprove} title={t("sellerOrders.bulkApprove")} className="w-8 h-8 rounded-lg bg-white/15 flex items-center justify-center disabled:opacity-50">
          <CheckCircle2 size={14} />
        </button>
        <button type="button" disabled={busy} onClick={onShip} title={t("orderStatus.actions.handToCourier")} className="w-8 h-8 rounded-lg bg-white/15 flex items-center justify-center disabled:opacity-50">
          <Truck size={14} />
        </button>
        <button type="button" disabled={busy} onClick={onCancel} title={t("sellerOrders.bulkCancel")} className="w-8 h-8 rounded-lg bg-rose-500 flex items-center justify-center disabled:opacity-50">
          <Ban size={14} />
        </button>
      </div>
    </div>
  );
};

export default memo(OrdersBulkActionBar);
