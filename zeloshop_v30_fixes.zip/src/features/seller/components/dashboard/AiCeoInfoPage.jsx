import { useState, useCallback, useMemo, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {
  ArrowLeft, Bot, TrendingUp, TrendingDown, Package, Instagram, Users, Check, Clock,
  Info, X, Tag, RotateCcw, ShoppingCart, Heart, Send, Loader2, RefreshCw,
  ChevronRight, ChevronDown, Star, MessageCircle, Zap, Sparkles, HelpCircle, Target,
} from "lucide-react";
import { useSession } from "@/context/SessionContext";
import updateSeller from "@/services/sellers/updateSeller";
import { generateDailyAiCeoReport, askAiCeo } from "@/services/ai/aiCeoInsights";
import CustomSelect from "@/components/ui/CustomSelect";
import { useLanguage } from "@/context/LanguageContext";

/**
 * AI CEO — ENDI ASOSIY SAHIFA "KUNLIK HISOBOT" (avval - faqat statik
 * tushuntirish edi).
 *
 * MUHIM, KATTA O'ZGARISH (foydalanuvchi so'ragan): sotuvchi AI CEO
 * o'zi UCHUN HAQIQATAN ISHLAYOTGANINI SEZISHI kerak edi - shuning
 * uchun bu sahifa endi HAR SAFAR ochilganda, `generateDailyAiCeoReport`
 * orqali BUGUNGI HAQIQIY ma'lumotdan hisobot tuzadi va ko'rsatadi.
 * "AI CEO nima qila oladi" (avvalgi statik tushuntirish) endi FAQAT
 * kichik "ℹ" tugmasi orqali ochiladigan modal ichida.
 */
const FEATURES = [
  { icon: TrendingUp, titleKey: "aiCeo.infoFeature1Title", descKey: "aiCeo.infoFeature1Desc" },
  { icon: Package, titleKey: "aiCeo.infoFeature2Title", descKey: "aiCeo.infoFeature2Desc" },
  { icon: Instagram, titleKey: "aiCeo.infoFeature3Title", descKey: "aiCeo.infoFeature3Desc" },
  { icon: Users, titleKey: "aiCeo.infoFeature4Title", descKey: "aiCeo.infoFeature4Desc" },
];

const formatMoney = (n) => `${Math.round(Number(n) || 0).toLocaleString()} so'm`;

/**
 * "Nima qila oladi" + xavfsizlik ro'yxatini ko'rsatadigan modal -
 * avvalgi sahifaning TO'LIQ mazmuni, endi shu yerga ko'chirilgan.
 */
const CapabilitiesModal = ({ onClose, t }) => (
  <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/40" onClick={onClose}>
    <div onClick={(e) => e.stopPropagation()} className="w-full max-w-md bg-[#F4F5F9] dark:bg-slate-950 rounded-t-[28px] max-h-[85vh] overflow-y-auto">
      <div className="sticky top-0 bg-white/95 dark:bg-slate-900/95 border-b border-slate-100 dark:border-slate-800 p-4 flex items-center justify-between">
        <h3 className="text-sm font-black text-slate-800 dark:text-white">{t("aiCeo.infoPageTitle")}</h3>
        <button type="button" onClick={onClose} className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center">
          <X size={14} className="text-slate-500 dark:text-slate-400" />
        </button>
      </div>
      <div className="p-4 space-y-4">
        <div className="bg-gradient-to-br from-indigo-600 to-indigo-700 rounded-[24px] p-5 text-white text-center shadow-lg shadow-indigo-600/20">
          <div className="w-12 h-12 rounded-2xl bg-white/15 flex items-center justify-center mx-auto mb-2.5">
            <Bot size={22} />
          </div>
          <h2 className="text-sm font-black">{t("aiCeo.infoHeroTitle")}</h2>
          <p className="text-[11px] font-medium text-white/80 mt-1.5 leading-relaxed">{t("aiCeo.infoHeroSubtitle")}</p>
        </div>

        <div className="space-y-2.5">
          {FEATURES.map(({ icon: Icon, titleKey, descKey }) => (
            <div key={titleKey} className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl p-3.5 flex gap-3">
              <span className="w-9 h-9 rounded-xl bg-indigo-50 dark:bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 flex items-center justify-center shrink-0">
                <Icon size={16} />
              </span>
              <div className="min-w-0">
                <p className="text-xs font-black text-slate-800 dark:text-white">{t(titleKey)}</p>
                <p className="text-[11px] text-slate-400 dark:text-slate-500 mt-1 leading-relaxed">{t(descKey)}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl p-4 space-y-2.5">
          <h3 className="text-[11px] font-black text-slate-500 dark:text-slate-400 uppercase tracking-wider">{t("aiCeo.infoSafetyTitle")}</h3>
          {["infoSafety1", "infoSafety2", "infoSafety3", "infoSafety4"].map((key) => (
            <div key={key} className="flex items-start gap-2">
              <Check size={13} className="text-emerald-500 shrink-0 mt-0.5" />
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">{t(`aiCeo.${key}`)}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  </div>
);

const TONE_CLASSES = {
  slate: "bg-slate-50 dark:bg-slate-500/10 text-slate-600 dark:text-slate-400",
  indigo: "bg-indigo-50 dark:bg-indigo-500/10 text-indigo-600 dark:text-indigo-400",
  emerald: "bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400",
};

const StatCard = ({ icon: Icon, label, value, tone = "slate" }) => (
  <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl p-3.5">
    <span className={`w-8 h-8 rounded-lg flex items-center justify-center mb-2 ${TONE_CLASSES[tone] || TONE_CLASSES.slate}`}>
      <Icon size={14} />
    </span>
    <p className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wide">{label}</p>
    <p className="text-sm font-black text-slate-800 dark:text-white mt-0.5">{value}</p>
  </div>
);

/**
 * "BUGUNGI REJALAR" — HARAKAT MARKAZI.
 *
 * MUHIM, KATTA O'ZGARISH (foydalanuvchi ATAYLAB so'ragan): OLDIN bu
 * sahifada "diqqat talab qiladi" (VIP/uxlab qolgan) va "mahsulot
 * tavsiyalari" (chegirma/aksiya nomzodlari) IKKI ALOHIDA, PASSIV
 * (faqat ma'lumot ko'rsatuvchi) blok edi - sotuvchi bu yerdan CRM
 * Hub'ga, keyin segmentni QO'LDA tanlab, "AI tavsiya" tugmasini
 * bosishi kerak edi (3 bosqich). Endi — BIR TA, USTUVORLIK bo'yicha
 * TARTIBLANGAN ro'yxat, va HAR BIR band uchun BITTA tugma bosilishi
 * bilan keyingi qadam TO'LIQ tayyorlangan holda ochiladi (masalan
 * "VIP'larga yubor" — CRM Hub'ni "vip" segmenti ALLAQACHON tanlangan
 * va AI matni ALLAQACHON generatsiya qilinayotgan holda ochadi).
 */
/**
 * AI CEO — 5-BOSQICH (1-qism): "O'ZI REJA TUZADI".
 *
 * `buildActionPlan()` (pastda) — MAVJUD harakat bandlarini va ULARNING
 * MAZMUNINI (matn, havola) hisoblaydi, VA standart holatda ularni
 * qattiq kodlangan qoida bo'yicha (VIP > churn > chegirma > aksiya)
 * tartiblaydi. Bu funksiya esa — agar backend (`buildDailyReport`,
 * `functions/aiCeo.js`) Gemini orqali BUGUNGI haqiqiy vaziyatga qarab
 * O'Z tartibini yaratgan bo'lsa (`report.aiActionPlan`), o'sha
 * tartibni QO'LLAYDI - qattiq kodlangan tartib endi FAQAT zaxira
 * (AI ishlamagan/hali hisoblanmagan holatlar uchun).
 */
export function applyAiActionPlanOrder(items, aiActionPlan) {
  if (!aiActionPlan || !Array.isArray(aiActionPlan.order) || aiActionPlan.order.length === 0) return items;
  const byKey = new Map(items.map((item) => [item.key, item]));
  const ordered = [];
  aiActionPlan.order.forEach((key) => {
    const item = byKey.get(key);
    if (item) {
      ordered.push(item);
      byKey.delete(key);
    }
  });
  // AI tartibida bo'lmagan (masalan formatlash muammosi tufayli
  // tushib qolgan) bandlar bo'lsa - HECH BIRI yo'qolib qolmasligi
  // uchun, oxiriga qo'shiladi.
  byKey.forEach((item) => ordered.push(item));
  return ordered;
}

export function buildActionPlan(report) {
  if (!report) return [];
  const items = [];

  if (report.attentionNeeded?.vipCount > 0) {
    items.push({
      key: "vip",
      icon: Star,
      tone: "amber",
      title: "aiCeo.actionVipTitle",
      titleParams: { count: report.attentionNeeded.vipCount },
      desc: "aiCeo.actionVipDesc",
      ctaKey: "aiCeo.actionVipCta",
      to: "/seller/crm?audience=vip&autoAi=1",
    });
  }
  if (report.attentionNeeded?.churnCount > 0) {
    items.push({
      key: "churn",
      icon: MessageCircle,
      tone: "rose",
      title: "aiCeo.actionChurnTitle",
      titleParams: { count: report.attentionNeeded.churnCount },
      desc: "aiCeo.actionChurnDesc",
      ctaKey: "aiCeo.actionChurnCta",
      to: "/seller/crm?audience=churn&autoAi=1",
    });
  }
  const discountCandidate = report.productRecommendations?.discountCandidates?.[0];
  if (discountCandidate) {
    items.push({
      key: "discount",
      icon: Tag,
      tone: "indigo",
      title: "aiCeo.actionDiscountTitle",
      titleParams: { name: discountCandidate.name },
      desc: "aiCeo.actionDiscountDesc",
      ctaKey: "aiCeo.actionDiscountCta",
      to: `/seller/products/${discountCandidate.id}/edit`,
    });
  }
  const promoteCandidate = report.productRecommendations?.promoteCandidates?.[0];
  if (promoteCandidate) {
    items.push({
      key: "promote",
      icon: Sparkles,
      tone: "emerald",
      title: "aiCeo.actionPromoteTitle",
      titleParams: { name: promoteCandidate.name },
      desc: "aiCeo.actionPromoteDesc",
      ctaKey: "aiCeo.actionPromoteCta",
      to: `/seller/products/${promoteCandidate.id}/edit`,
    });
  }
  return items;
}

const ACTION_TONE_CLASSES = {
  amber: { icon: "bg-amber-50 dark:bg-amber-500/10 text-amber-600 dark:text-amber-400", btn: "bg-amber-500 hover:bg-amber-600" },
  rose: { icon: "bg-rose-50 dark:bg-rose-500/10 text-rose-600 dark:text-rose-400", btn: "bg-rose-500 hover:bg-rose-600" },
  indigo: { icon: "bg-indigo-50 dark:bg-indigo-500/10 text-indigo-600 dark:text-indigo-400", btn: "bg-indigo-600 hover:bg-indigo-700" },
  emerald: { icon: "bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400", btn: "bg-emerald-600 hover:bg-emerald-700" },
};

const ActionPlanItem = ({ item, t, onNavigate }) => {
  const Icon = item.icon;
  const tone = ACTION_TONE_CLASSES[item.tone] || ACTION_TONE_CLASSES.indigo;
  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl p-3.5 flex items-center gap-3">
      <span className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${tone.icon}`}>
        <Icon size={16} />
      </span>
      <div className="min-w-0 flex-1">
        <p className="text-xs font-black text-slate-800 dark:text-white truncate">{t(item.title, item.titleParams)}</p>
        <p className="text-[11px] text-slate-400 dark:text-slate-500 mt-0.5 leading-relaxed">{t(item.desc)}</p>
      </div>
      <button
        type="button"
        onClick={() => onNavigate(item.to)}
        className={`shrink-0 h-9 px-3 text-white text-[11px] font-black rounded-xl flex items-center gap-1 active:scale-95 transition-transform ${tone.btn}`}
      >
        {t(item.ctaKey)} <ChevronRight size={12} />
      </button>
    </div>
  );
};

const AiCeoInfoPage = () => {
  const navigate = useNavigate();
  const { t } = useLanguage();
  const { sellerId, store } = useSession();
  const [enabled, setEnabled] = useState(store?.aiCeoDigestEnabled !== false);
  const [saving, setSaving] = useState(false);
  const [draftHour, setDraftHour] = useState(
    Number.isInteger(store?.aiCeoDraftProcessHour) ? String(store.aiCeoDraftProcessHour) : "21"
  );
  const [savingHour, setSavingHour] = useState(false);
  const [showCapabilities, setShowCapabilities] = useState(false);
  // AI CEO — TIER-1 "ISHONCH ZINAPOYASI": standart holatda O'CHIQ
  // (opt-in, opt-out EMAS) - yoqilsa, 30 kun xarid qilmagan
  // mijozlarga AI CEO matnni O'ZI yozadi va SOTUVCHI TASDIQISIZ
  // avtomatik yuboradi (batafsil izoh: `functions/engagementReminders.js`).
  const [autoWinBackEnabled, setAutoWinBackEnabled] = useState(store?.aiCeoAutoWinBackEnabled === true);
  const [savingAutoWinBack, setSavingAutoWinBack] = useState(false);
  // YANGI: xuddi shu "ishonch zinapoyasi" - Tier-1 avtonom ijro -
  // ENDI sevimlilar eslatmasiga ham kengaytirilgan (standart holatda
  // O'CHIQ, batafsil izoh: `functions/engagementReminders.js`).
  const [autoFavoriteEnabled, setAutoFavoriteEnabled] = useState(store?.aiCeoAutoFavoriteEnabled === true);
  const [savingAutoFavorite, setSavingAutoFavorite] = useState(false);
  // YANGI (8-BOSQICH — "avtonom harakatlar doirasini kengaytirish"):
  // xuddi yuqoridagi kabi "ishonch zinapoyasi", lekin bu safar HAQIQIY
  // moliyaviy oqibatga ega - yoqilsa (VA `autoWinBackEnabled` ham
  // yoqilgan bo'lsa, VA AI CEO'ning matni ISBOTLANGAN holda yetarlicha
  // ishlamayotgan bo'lsa), qaytarish xabariga HAQIQIY, bir martalik
  // chegirma promokodi ham avtomatik qo'shiladi (standart holatda
  // O'CHIQ, batafsil izoh: `functions/aiCeoAutoDiscount.js`).
  const [autoDiscountEnabled, setAutoDiscountEnabled] = useState(store?.aiCeoAutoDiscountEnabled === true);
  const [savingAutoDiscount, setSavingAutoDiscount] = useState(false);
  const [discountPercent, setDiscountPercent] = useState(
    Number.isInteger(store?.aiCeoAutoDiscountPercent) ? String(store.aiCeoAutoDiscountPercent) : "10"
  );
  const [savingDiscountPercent, setSavingDiscountPercent] = useState(false);
  // YANGI (SODDALASHTIRISH, foydalanuvchi so'ragan): joriy 5+ ta mayda
  // sozlama tajribasini murakkablashtirib yuborgani uchun, endi ular
  // standart holatda "Kengaytirilgan sozlamalar" ostiga YOPIQ holda
  // yig'iladi (hech biri OLIB TASHLANMAGAN, faqat yashirilgan).
  const [advancedOpen, setAdvancedOpen] = useState(false);
  const [savingMaster, setSavingMaster] = useState(false);
  // YANGI: Telegram orqali "1-tugmali tasdiqlash" - Mini App'ni
  // OCHMASDAN, to'g'ridan-to'g'ri Telegram chatida AI CEO tavsiyasini
  // ko'rib, bitta tugma bilan tasdiqlash (standart holatda O'CHIQ,
  // batafsil izoh: `functions/telegramApproval.js`).
  const [telegramApprovalEnabled, setTelegramApprovalEnabled] = useState(store?.aiCeoTelegramApprovalEnabled === true);
  const [savingTelegramApproval, setSavingTelegramApproval] = useState(false);

  const [report, setReport] = useState(null);
  const [reportLoading, setReportLoading] = useState(true);
  const [reportError, setReportError] = useState(null);

  // YANGI (6-BOSQICH — "tool-calling arxitekturasi"): "AI CEO'dan
  // so'rang" - sotuvchi erkin matnda savol beradi, backend
  // (`functions/aiCeoAgent.js`) Gemini'ga HAQIQIY, chaqiriladigan
  // vositalar (tools) berib, Gemini O'ZI qaysi ma'lumot kerakligini hal
  // qiladi. FAQAT O'QISH - hech qanday tasdiqlash/ishonch zinapoyasi
  // shart emas (batafsil izoh: `functions/aiCeoAgent.js`).
  const [askQuestion, setAskQuestion] = useState("");
  const [askAnswer, setAskAnswer] = useState(null);
  const [askLoading, setAskLoading] = useState(false);
  const [askError, setAskError] = useState(null);

  // "BUGUNGI REJALAR" - hisobotdan olingan, ustuvorlik bo'yicha
  // tartiblangan, HAR BIRI bitta tugmali harakat markazi. Standart
  // tartib qattiq kodlangan qoida bo'yicha, lekin agar backend
  // Gemini orqali BUGUNGI o'z tartibini yaratgan bo'lsa
  // (`report.aiActionPlan`), o'sha qo'llaniladi - AI CEO "o'zi reja
  // tuzadi" (5-bosqich).
  const baseActionPlan = useMemo(() => buildActionPlan(report), [report]);
  const actionPlan = useMemo(
    () => applyAiActionPlanOrder(baseActionPlan, report?.aiActionPlan),
    [baseActionPlan, report]
  );

  const hourOptions = useMemo(
    () => Array.from({ length: 24 }, (_, h) => ({ value: String(h), label: `${String(h).padStart(2, "0")}:00` })),
    []
  );

  // YANGI (8-BOSQICH): moliyaviy xavfni cheklash uchun qat'iy
  // chegaralangan tanlov (backend, `aiCeoAutoDiscount.js`dagi
  // `MIN_DISCOUNT_PERCENT`/`MAX_DISCOUNT_PERCENT` bilan MOS).
  const discountPercentOptions = useMemo(
    () => [5, 10, 15, 20].map((p) => ({ value: String(p), label: `${p}%` })),
    []
  );

  // YANGI (SODDALASHTIRISH): katta "yoqish" tugmasi FAQAT uchta
  // moliyaviy XAVFSIZ sozlama (kunlik xulosa + ikkala avtomatik xabar
  // turi) HAMMASI birdaniga yoqilgan holatdagina "yoqilgan" ko'rinadi -
  // aralash holat (masalan faqat 2tasi yoqilgan, kengaytirilgan
  // bo'limdan qo'lda sozlangan) "o'chiq" deb ko'rsatiladi, chunki
  // "to'liq yoqilmagan".
  const allCoreEnabled = enabled && autoWinBackEnabled && autoFavoriteEnabled;

  const loadReport = useCallback(async () => {
    setReportLoading(true);
    setReportError(null);
    try {
      const data = await generateDailyAiCeoReport();
      setReport(data);
    } catch (err) {
      setReportError(err.message || t("aiCeo.reportError"));
    } finally {
      setReportLoading(false);
    }
  }, [t]);

  useEffect(() => {
    loadReport();
  }, [loadReport]);

  const handleHourChange = useCallback(async (value) => {
    const previous = draftHour;
    setDraftHour(value);
    setSavingHour(true);
    try {
      await updateSeller(sellerId, { aiCeoDraftProcessHour: Number(value) });
    } catch {
      setDraftHour(previous);
    } finally {
      setSavingHour(false);
    }
  }, [draftHour, sellerId]);

  const handleToggle = useCallback(async () => {
    const next = !enabled;
    setEnabled(next);
    setSaving(true);
    try {
      await updateSeller(sellerId, { aiCeoDigestEnabled: next });
    } catch {
      setEnabled(!next);
    } finally {
      setSaving(false);
    }
  }, [enabled, sellerId]);

  const handleAutoWinBackToggle = useCallback(async () => {
    const next = !autoWinBackEnabled;
    setAutoWinBackEnabled(next);
    setSavingAutoWinBack(true);
    try {
      await updateSeller(sellerId, { aiCeoAutoWinBackEnabled: next });
    } catch {
      setAutoWinBackEnabled(!next);
    } finally {
      setSavingAutoWinBack(false);
    }
  }, [autoWinBackEnabled, sellerId]);

  const handleAutoFavoriteToggle = useCallback(async () => {
    const next = !autoFavoriteEnabled;
    setAutoFavoriteEnabled(next);
    setSavingAutoFavorite(true);
    try {
      await updateSeller(sellerId, { aiCeoAutoFavoriteEnabled: next });
    } catch {
      setAutoFavoriteEnabled(!next);
    } finally {
      setSavingAutoFavorite(false);
    }
  }, [autoFavoriteEnabled, sellerId]);

  const handleAutoDiscountToggle = useCallback(async () => {
    const next = !autoDiscountEnabled;
    setAutoDiscountEnabled(next);
    setSavingAutoDiscount(true);
    try {
      await updateSeller(sellerId, { aiCeoAutoDiscountEnabled: next });
    } catch {
      setAutoDiscountEnabled(!next);
    } finally {
      setSavingAutoDiscount(false);
    }
  }, [autoDiscountEnabled, sellerId]);

  const handleDiscountPercentChange = useCallback(async (value) => {
    const previous = discountPercent;
    setDiscountPercent(value);
    setSavingDiscountPercent(true);
    try {
      await updateSeller(sellerId, { aiCeoAutoDiscountPercent: Number(value) });
    } catch {
      setDiscountPercent(previous);
    } finally {
      setSavingDiscountPercent(false);
    }
  }, [discountPercent, sellerId]);

  // YANGI (SODDALASHTIRISH): bitta bosish bilan uchta sozlamani
  // BIRDANIGA yozadi (kaskad) - imkoniyat KAMAYMAYDI (har biri
  // "Kengaytirilgan sozlamalar"da baribir alohida ham sozlanadi),
  // faqat TEZKOR yo'l qo'shiladi. Xatolik bo'lsa - UCHALASI HAM
  // eski holatiga qaytariladi (yarim-yozilgan holat qolmasligi uchun).
  const handleMasterToggle = useCallback(async () => {
    const next = !allCoreEnabled;
    const prevEnabled = enabled;
    const prevAutoWinBack = autoWinBackEnabled;
    const prevAutoFavorite = autoFavoriteEnabled;
    setEnabled(next);
    setAutoWinBackEnabled(next);
    setAutoFavoriteEnabled(next);
    setSavingMaster(true);
    try {
      await updateSeller(sellerId, {
        aiCeoDigestEnabled: next,
        aiCeoAutoWinBackEnabled: next,
        aiCeoAutoFavoriteEnabled: next,
      });
    } catch {
      setEnabled(prevEnabled);
      setAutoWinBackEnabled(prevAutoWinBack);
      setAutoFavoriteEnabled(prevAutoFavorite);
    } finally {
      setSavingMaster(false);
    }
  }, [allCoreEnabled, enabled, autoWinBackEnabled, autoFavoriteEnabled, sellerId]);

  const handleAskSubmit = useCallback(async (e) => {
    e.preventDefault();
    const trimmed = askQuestion.trim();
    if (!trimmed || askLoading) return;
    setAskLoading(true);
    setAskError(null);
    try {
      const { answer } = await askAiCeo(trimmed);
      setAskAnswer(answer);
    } catch (err) {
      setAskError(err.message || t("aiCeo.askAiCeoError"));
    } finally {
      setAskLoading(false);
    }
  }, [askQuestion, askLoading, t]);

  const handleAskReset = useCallback(() => {
    setAskQuestion("");
    setAskAnswer(null);
    setAskError(null);
  }, []);

  const handleTelegramApprovalToggle = useCallback(async () => {
    const next = !telegramApprovalEnabled;
    setTelegramApprovalEnabled(next);
    setSavingTelegramApproval(true);
    try {
      await updateSeller(sellerId, { aiCeoTelegramApprovalEnabled: next });
    } catch {
      setTelegramApprovalEnabled(!next);
    } finally {
      setSavingTelegramApproval(false);
    }
  }, [telegramApprovalEnabled, sellerId]);

  return (
    <div className="h-screen overflow-y-auto bg-[#F4F5F9] dark:bg-slate-950 text-slate-900 dark:text-white font-sans antialiased transition-colors duration-300">

      <div className="sticky top-0 z-30 bg-white/95 dark:bg-slate-900/95 px-4 py-4 shadow-xs flex items-center gap-3">
        <button
          type="button"
          onClick={() => navigate(-1)}
          className="w-9 h-9 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-600 dark:text-slate-300 active:scale-95 transition-transform shrink-0"
        >
          <ArrowLeft size={17} />
        </button>
        <h1 className="text-sm font-black text-slate-800 dark:text-white flex-1">{t("aiCeo.dailyReportTitle")}</h1>
        <button
          type="button"
          onClick={loadReport}
          disabled={reportLoading}
          className="w-9 h-9 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-500 dark:text-slate-400 active:scale-95 transition-transform shrink-0 disabled:opacity-50"
          aria-label={t("aiCeo.refreshLabel")}
        >
          <RefreshCw size={14} className={reportLoading ? "animate-spin" : ""} />
        </button>
        {/* MUHIM: "AI CEO nima qila oladi" - endi shu KICHIK tugma
            orqali, alohida modalda ochiladi (avval, bu - butun
            sahifaning O'ZI edi). */}
        <button
          type="button"
          onClick={() => setShowCapabilities(true)}
          className="w-9 h-9 rounded-full bg-indigo-50 dark:bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 flex items-center justify-center active:scale-95 transition-transform shrink-0"
          aria-label={t("aiCeo.infoPageTitle")}
        >
          <Info size={16} />
        </button>
      </div>

      <div className="p-4 space-y-4 pb-36">

        {reportLoading && (
          <div className="flex items-center justify-center gap-2 py-16 text-xs text-slate-400 dark:text-slate-500">
            <Loader2 size={16} className="animate-spin" /> {t("aiCeo.reportLoading")}
          </div>
        )}

        {!reportLoading && reportError && (
          <div className="bg-rose-50 dark:bg-rose-500/10 border border-rose-100 dark:border-rose-500/20 rounded-2xl p-4 text-center space-y-2">
            <p className="text-xs text-rose-600 dark:text-rose-400 font-semibold">{reportError}</p>
            <button type="button" onClick={loadReport} className="text-xs font-bold text-indigo-600 dark:text-indigo-400 underline">
              {t("aiCeo.retryButton")}
            </button>
          </div>
        )}

        {!reportLoading && !reportError && report && (
          <>
            {/* 1. MOLIYAVIY QISQA HISOBOT */}
            <div className="bg-gradient-to-br from-indigo-600 to-indigo-700 rounded-[24px] p-5 text-white shadow-lg shadow-indigo-600/20">
              <p className="text-[10px] font-bold text-white/70 uppercase tracking-wider mb-1">{t("aiCeo.todayRevenueLabel")}</p>
              <p className="text-xl font-black">{formatMoney(report.financial.todayRevenue)}</p>
              {report.financial.revenueChangePercent !== null && (
                <div className={`inline-flex items-center gap-1 mt-2 text-[11px] font-bold px-2 py-0.5 rounded-md ${report.financial.revenueChangePercent >= 0 ? "bg-emerald-500/20 text-emerald-100" : "bg-rose-500/20 text-rose-100"}`}>
                  {report.financial.revenueChangePercent >= 0 ? <TrendingUp size={11} /> : <TrendingDown size={11} />}
                  {report.financial.revenueChangePercent >= 0 ? "+" : ""}{report.financial.revenueChangePercent.toFixed(0)}% {t("aiCeo.vsYesterdayLabel")}
                </div>
              )}
              <div className="flex gap-4 mt-3 pt-3 border-t border-white/15">
                <div>
                  <p className="text-[10px] text-white/60">{t("aiCeo.todayOrdersLabel")}</p>
                  <p className="text-sm font-black">{report.financial.todayOrderCount}</p>
                </div>
                <div>
                  <p className="text-[10px] text-white/60">{t("aiCeo.todayDeliveredLabel")}</p>
                  <p className="text-sm font-black">{report.financial.todayDeliveredCount}</p>
                </div>
              </div>
            </div>

            {/* 2. MAHSULOT QO'SHISH STATISTIKASI */}
            <div className="grid grid-cols-2 gap-2.5">
              <StatCard icon={Package} label={t("aiCeo.productsAddedLabel")} value={`${report.productAdditions.addedTodayCount} ta`} tone="indigo" />
              <StatCard icon={TrendingUp} label={t("aiCeo.salesFromNewLabel")} value={formatMoney(report.productAdditions.salesFromNewProducts)} tone="emerald" />
            </div>

            {/* "BUGUNGI REJALAR" — HARAKAT MARKAZI. OLDIN: ikkita
                alohida, PASSIV blok ("mahsulot tavsiyalari" + "diqqat
                talab qiladi"). ENDI: BIR TA, ustuvorlik bo'yicha
                tartiblangan ro'yxat - har biri BITTA tugma bilan
                keyingi qadamni TO'LIQ tayyorlangan holda ochadi. */}
            {actionPlan.length > 0 && (
              <div className="space-y-2.5">
                <h3 className="text-xs font-black text-slate-800 dark:text-white flex items-center gap-1.5 px-1">
                  <Zap size={14} className="text-indigo-500" /> {t("aiCeo.actionPlanTitle")}
                </h3>
                {/* YANGI (5-bosqich): agar AI CEO BUGUNGI ustuvorlikni
                    o'zi tanlagan bo'lsa, sababi shu yerda ko'rsatiladi
                    - sotuvchi nima uchun aynan shu tartib ekanini
                    tushunadi ("qora quti" emas). */}
                {report?.aiActionPlan?.reasoning && (
                  <div className="bg-indigo-50/60 dark:bg-indigo-500/10 border border-indigo-100 dark:border-indigo-500/20 rounded-xl px-3 py-2.5 flex items-start gap-2">
                    <Bot size={13} className="text-indigo-600 dark:text-indigo-400 shrink-0 mt-0.5" />
                    <p className="text-[11px] text-indigo-700 dark:text-indigo-300 leading-relaxed">{report.aiActionPlan.reasoning}</p>
                  </div>
                )}
                {actionPlan.map((item) => (
                  <ActionPlanItem key={item.key} item={item} t={t} onNavigate={navigate} />
                ))}
              </div>
            )}

            {/* 4. CRM FAOLIYATI */}
            <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl p-4 space-y-3">
              <h3 className="text-xs font-black text-slate-800 dark:text-white flex items-center gap-1.5">
                <Send size={14} className="text-indigo-500" /> {t("aiCeo.crmActivityTitle")}
              </h3>
              <div className="grid grid-cols-2 gap-2">
                <div className="flex items-center gap-2 text-xs text-slate-600 dark:text-slate-300">
                  <ShoppingCart size={12} className="text-slate-400 shrink-0" /> {t("aiCeo.cartRemindersLabel")}: <strong>{report.crmActivity.cartRemindersSent}</strong>
                </div>
                <div className="flex items-center gap-2 text-xs text-slate-600 dark:text-slate-300">
                  <Heart size={12} className="text-slate-400 shrink-0" /> {t("aiCeo.favoriteRemindersLabel")}: <strong>{report.crmActivity.favoriteRemindersSent}</strong>
                </div>
                <div className="flex items-center gap-2 text-xs text-slate-600 dark:text-slate-300">
                  <RotateCcw size={12} className="text-slate-400 shrink-0" /> {t("aiCeo.repurchaseRemindersLabel")}: <strong>{report.crmActivity.repurchaseRemindersSent}</strong>
                </div>
                <div className="flex items-center gap-2 text-xs text-slate-600 dark:text-slate-300">
                  <Send size={12} className="text-slate-400 shrink-0" /> {t("aiCeo.crmBroadcastLabel")}: <strong>{report.crmActivity.crmMessagesSent}</strong>
                </div>
              </div>
              {report.crmActivity.crmMessagesSent > 0 && (
                <div className="bg-emerald-50 dark:bg-emerald-500/10 rounded-xl p-2.5 text-xs font-bold text-emerald-700 dark:text-emerald-400">
                  {t("aiCeo.conversionLabel", { count: report.crmActivity.convertedCount })}
                </div>
              )}
              {/* YANGI: Tier-1 shaffoflik - AI CEO o'zi, avtomatik
                  bajargan harakatlarni sotuvchiga KO'RSATADI (oldindan
                  tasdiqlash EMAS, lekin har doim ko'rinadigan hisobot). */}
              {report.crmActivity.aiAutoActionsCount > 0 && (
                <div className="bg-indigo-50 dark:bg-indigo-500/10 rounded-xl p-2.5 text-xs font-bold text-indigo-700 dark:text-indigo-400 flex items-center gap-1.5">
                  <Bot size={12} className="shrink-0" /> {t("aiCeo.autoActionsLabel", { count: report.crmActivity.aiAutoActionsCount })}
                </div>
              )}
              {/* YANGI (8-BOSQICH): moliyaviy oqibatga ega harakat -
                  ATAYLAB yuqoridagi "oddiy" avtomatik harakatlar
                  qatoridan ALOHIDA, alohida rangda (amber) ko'rsatiladi
                  - sotuvchi buni chalkashtirib yubormasligi uchun. */}
              {report.crmActivity.autoDiscountsIssuedCount > 0 && (
                <div className="bg-amber-50 dark:bg-amber-500/10 rounded-xl p-2.5 text-xs font-bold text-amber-700 dark:text-amber-400 flex items-center gap-1.5">
                  <Tag size={12} className="shrink-0" /> {t("aiCeo.autoDiscountsIssuedLabel", { count: report.crmActivity.autoDiscountsIssuedCount })}
                </div>
              )}
              <div className="flex gap-4 pt-2 border-t border-slate-50 dark:border-slate-800">
                <div>
                  <p className="text-[10px] text-slate-400 dark:text-slate-500">{t("aiCeo.activeCustomersLabel")}</p>
                  <p className="text-sm font-black text-emerald-600 dark:text-emerald-400">{report.crmActivity.activeCustomers}</p>
                </div>
                <div>
                  <p className="text-[10px] text-slate-400 dark:text-slate-500">{t("aiCeo.inactiveCustomersLabel")}</p>
                  <p className="text-sm font-black text-slate-400 dark:text-slate-500">{report.crmActivity.inactiveCustomers}</p>
                </div>
              </div>
            </div>

            {/* YANGI (7-BOSQICH — "natija kuzatuvi va o'rganish"): "AI
                CEO samaradorligi" - avvalgi bosqichlarda faqat "N ta
                xabar yuborildi" (harakat) ko'rsatilardi, endi esa
                HAQIQIY, evaluatsiya qilingan NATIJA ("shu xabarlardan
                necha foizi mijozni qaytardi") ham ko'rinadi - to'liq
                shaffoflik. Har bir tur (`winback`/`favorite`) FAQAT
                hech bo'lmasa bitta xabar yuborilgan bo'lsa ko'rsatiladi
                (batafsil izoh: `functions/aiCeoLearning.js`). */}
            {(report?.learningSummary?.winback || report?.learningSummary?.favorite) && (
              <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl p-4 space-y-3">
                <h3 className="text-xs font-black text-slate-800 dark:text-white flex items-center gap-1.5">
                  <Target size={14} className="text-indigo-500" /> {t("aiCeo.learningTitle")}
                </h3>
                <div className="grid grid-cols-2 gap-2.5">
                  {report.learningSummary.winback && (
                    <div className="bg-[#F4F5F9] dark:bg-slate-800/60 rounded-xl p-3">
                      <p className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wide">{t("aiCeo.learningWinbackLabel")}</p>
                      <p className="text-sm font-black text-emerald-600 dark:text-emerald-400 mt-0.5">{report.learningSummary.winback.conversionRatePercent}%</p>
                      <p className="text-[10px] text-slate-400 dark:text-slate-500 mt-0.5">{t("aiCeo.learningSentCount", { count: report.learningSummary.winback.sentCount })}</p>
                    </div>
                  )}
                  {report.learningSummary.favorite && (
                    <div className="bg-[#F4F5F9] dark:bg-slate-800/60 rounded-xl p-3">
                      <p className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wide">{t("aiCeo.learningFavoriteLabel")}</p>
                      <p className="text-sm font-black text-emerald-600 dark:text-emerald-400 mt-0.5">{report.learningSummary.favorite.conversionRatePercent}%</p>
                      <p className="text-[10px] text-slate-400 dark:text-slate-500 mt-0.5">{t("aiCeo.learningSentCount", { count: report.learningSummary.favorite.sentCount })}</p>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* YANGI (6-BOSQICH — "tool-calling arxitekturasi"): "AI
                CEO'dan so'rang". OLDINGI barcha bosqichlar
                (moliyaviy hisobot, rejalar tartibi va h.k.) OLDINDAN
                belgilangan promptlar edi - bu yerda esa sotuvchi
                ISTALGAN savolni beradi, Gemini esa O'ZI qaysi
                ma'lumot kerakligini hal qilib, HAQIQIY vositalarni
                chaqirib javob beradi. */}
            <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl p-4 space-y-3">
              <h3 className="text-xs font-black text-slate-800 dark:text-white flex items-center gap-1.5">
                <HelpCircle size={14} className="text-indigo-500" /> {t("aiCeo.askAiCeoTitle")}
              </h3>
              <p className="text-[11px] text-slate-400 dark:text-slate-500 leading-relaxed">{t("aiCeo.askAiCeoSubtitle")}</p>

              {!askAnswer && (
                <form onSubmit={handleAskSubmit} className="space-y-2">
                  <textarea
                    value={askQuestion}
                    onChange={(e) => setAskQuestion(e.target.value)}
                    placeholder={t("aiCeo.askAiCeoPlaceholder")}
                    maxLength={300}
                    rows={2}
                    disabled={askLoading}
                    className="w-full text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-[#F4F5F9] dark:bg-slate-800 p-3 text-slate-700 dark:text-slate-200 placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/30 resize-none disabled:opacity-60"
                  />
                  <button
                    type="submit"
                    disabled={askLoading || !askQuestion.trim()}
                    className="w-full h-10 rounded-xl bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-xs font-black flex items-center justify-center gap-2 active:scale-95 transition-transform"
                  >
                    {askLoading ? (
                      <>
                        <Loader2 size={14} className="animate-spin" /> {t("aiCeo.askAiCeoLoading")}
                      </>
                    ) : (
                      t("aiCeo.askAiCeoButton")
                    )}
                  </button>
                </form>
              )}

              {askError && <p className="text-[11px] text-rose-500 dark:text-rose-400 font-semibold">{askError}</p>}

              {askAnswer && (
                <div className="space-y-2.5">
                  <div className="bg-[#F4F5F9] dark:bg-slate-800/60 rounded-xl p-3">
                    <p className="text-[11px] font-bold text-slate-500 dark:text-slate-400 mb-1">{askQuestion}</p>
                    <p className="text-xs text-slate-700 dark:text-slate-200 leading-relaxed">{askAnswer}</p>
                  </div>
                  <button type="button" onClick={handleAskReset} className="text-xs font-bold text-indigo-600 dark:text-indigo-400 underline">
                    {t("aiCeo.askAiCeoAskAnother")}
                  </button>
                </div>
              )}
            </div>
          </>
        )}

        {/* YANGI (SODDALASHTIRISH): bitta katta "yoqish" tugmasi -
            foydalanuvchi ATAYLAB so'ragan "imkoniyatlarni saqlab qolgan
            holda soddalashtirish". Bosilganda, moliyaviy XAVFSIZ, faqat
            matn/xabar darajasidagi uchta sozlamani (kunlik xulosa +
            avtomatik qaytarish/sevimlilar xabari) BIRDANIGA, aqlli
            standart qiymat bilan yoqadi/o'chiradi - quyidagi
            "Kengaytirilgan sozlamalar" esa HAR BIR narsani baribir
            alohida, nozik sozlash imkonini SAQLAB QOLADI (hech narsa
            olib tashlanmagan). MUHIM: pul bilan bog'liq avtomatik
            chegirma (`aiCeoAutoDiscountEnabled`) ATAYLAB bu tugmaga
            QO'SHILMAGAN - u har doim, alohida, ongli ravishda
            yoqiladi (Kengaytirilgan bo'limda). */}
        <div className="bg-gradient-to-br from-indigo-600 to-indigo-700 rounded-2xl p-4 text-white shadow-sm space-y-3">
          <div className="flex items-center gap-3">
            <span className="w-9 h-9 rounded-xl bg-white/15 flex items-center justify-center shrink-0">
              <Bot size={16} />
            </span>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-black">{t("aiCeo.masterToggleTitle")}</p>
              <p className="text-[10px] font-medium text-white/70 mt-0.5 leading-relaxed">{t("aiCeo.masterToggleDesc")}</p>
            </div>
            <button
              type="button"
              onClick={handleMasterToggle}
              disabled={savingMaster}
              aria-label={t("aiCeo.masterToggleTitle")}
              className={`w-10 h-6 rounded-full flex items-center px-0.5 transition-colors shrink-0 ${savingMaster ? "opacity-60" : ""} ${allCoreEnabled ? "bg-white/90 justify-end" : "bg-white/20 justify-start"}`}
            >
              <span className={`w-5 h-5 rounded-full shadow-sm ${allCoreEnabled ? "bg-indigo-600" : "bg-white"}`} />
            </button>
          </div>

          <div className="pt-3 border-t border-white/15 space-y-2">
            <div className="flex items-center gap-2">
              <Clock size={13} className="text-white/70" />
              <p className="text-[11px] font-bold text-white/70">{t("aiCeo.processTimeTitle")}</p>
            </div>
            <CustomSelect value={draftHour} onChange={handleHourChange} options={hourOptions} disabled={savingHour} />
          </div>
        </div>

        {/* YANGI (SODDALASHTIRISH): joriy 5 ta mayda sozlama endi
            standart holatda YOPIQ - sotuvchi ularni ko'rish uchun
            ATAYLAB ochishi kerak. Hech biri OLIB TASHLANMAGAN, faqat
            "sodda" ko'rinishdan chetga surilgan. */}
        <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl overflow-hidden">
          <button
            type="button"
            onClick={() => setAdvancedOpen((prev) => !prev)}
            className="w-full flex items-center justify-between gap-2 p-4"
          >
            <div className="text-left">
              <p className="text-xs font-bold text-slate-700 dark:text-slate-200">{t("aiCeo.advancedSettingsTitle")}</p>
              <p className="text-[10px] text-slate-400 dark:text-slate-500 mt-0.5">{t("aiCeo.advancedSettingsSubtitle")}</p>
            </div>
            <ChevronDown size={16} className={`text-slate-400 dark:text-slate-500 shrink-0 transition-transform ${advancedOpen ? "rotate-180" : ""}`} />
          </button>

          {advancedOpen && (
            <div className="px-4 pb-4 space-y-3">
              <div className="pt-3 border-t border-slate-50 dark:border-slate-800 flex items-center justify-between">
                <span className="text-xs font-bold text-slate-700 dark:text-slate-200">{t("aiCeo.dashboardCardTitle")}</span>
                <button
                  type="button"
                  onClick={handleToggle}
                  disabled={saving}
                  aria-label={t("aiCeo.dashboardCardTitle")}
                  className={`w-10 h-6 rounded-full flex items-center px-0.5 transition-colors shrink-0 ${saving ? "opacity-60" : ""} ${enabled ? "bg-indigo-600 justify-end" : "bg-slate-200 dark:bg-slate-700 justify-start"}`}
                >
                  <span className="w-5 h-5 rounded-full bg-white shadow-sm" />
                </button>
              </div>

              {/* YANGI: AI CEO Tier-1 avtonom ijro - standart holatda
                  O'CHIQ (opt-in). Bu, boshqa sozlamalardan farqli, MATNNI
                  AI YOZADI VA SOTUVCHI TASDIQISIZ YUBORADI - shuning uchun
                  tavsif ORQALI ANIQ tushuntiriladi, nima o'zgarishini
                  yashirmasdan. */}
              <div className="pt-3 border-t border-slate-50 dark:border-slate-800 space-y-1.5">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-bold text-slate-700 dark:text-slate-200 flex-1">{t("aiCeo.autoWinBackTitle")}</span>
                  <button
                    type="button"
                    onClick={handleAutoWinBackToggle}
                    disabled={savingAutoWinBack}
                    aria-label={t("aiCeo.autoWinBackTitle")}
                    className={`w-10 h-6 rounded-full flex items-center px-0.5 transition-colors shrink-0 ${savingAutoWinBack ? "opacity-60" : ""} ${autoWinBackEnabled ? "bg-indigo-600 justify-end" : "bg-slate-200 dark:bg-slate-700 justify-start"}`}
                  >
                    <span className="w-5 h-5 rounded-full bg-white shadow-sm" />
                  </button>
                </div>
                <p className="text-[11px] text-slate-400 dark:text-slate-500 leading-relaxed">{t("aiCeo.autoWinBackDesc")}</p>
              </div>

              {/* YANGI: xuddi shu Tier-1 avtonomiya - sevimlilar
                  eslatmasiga kengaytirilgan. */}
              <div className="pt-3 border-t border-slate-50 dark:border-slate-800 space-y-1.5">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-bold text-slate-700 dark:text-slate-200 flex-1">{t("aiCeo.autoFavoriteTitle")}</span>
                  <button
                    type="button"
                    onClick={handleAutoFavoriteToggle}
                    disabled={savingAutoFavorite}
                    aria-label={t("aiCeo.autoFavoriteTitle")}
                    className={`w-10 h-6 rounded-full flex items-center px-0.5 transition-colors shrink-0 ${savingAutoFavorite ? "opacity-60" : ""} ${autoFavoriteEnabled ? "bg-indigo-600 justify-end" : "bg-slate-200 dark:bg-slate-700 justify-start"}`}
                  >
                    <span className="w-5 h-5 rounded-full bg-white shadow-sm" />
                  </button>
                </div>
                <p className="text-[11px] text-slate-400 dark:text-slate-500 leading-relaxed">{t("aiCeo.autoFavoriteDesc")}</p>
              </div>

              {/* YANGI (8-BOSQICH): "avtonom qaytarish xabari"ning
                  KUCHAYTIRILGAN varianti - shuning uchun `autoWinBackEnabled`
                  yoqilmagan bo'lsa, tugma O'CHIRILGAN (kulrang) va bosilmaydi
                  - bog'liqlik ANIQ ko'rinadi. */}
              <div className="pt-3 border-t border-slate-50 dark:border-slate-800 space-y-1.5">
                <div className="flex items-center justify-between gap-2">
                  <span className={`text-xs font-bold flex-1 ${autoWinBackEnabled ? "text-slate-700 dark:text-slate-200" : "text-slate-400 dark:text-slate-500"}`}>{t("aiCeo.autoDiscountTitle")}</span>
                  <button
                    type="button"
                    onClick={handleAutoDiscountToggle}
                    disabled={savingAutoDiscount || !autoWinBackEnabled}
                    aria-label={t("aiCeo.autoDiscountTitle")}
                    className={`w-10 h-6 rounded-full flex items-center px-0.5 transition-colors shrink-0 ${(savingAutoDiscount || !autoWinBackEnabled) ? "opacity-50" : ""} ${autoDiscountEnabled ? "bg-indigo-600 justify-end" : "bg-slate-200 dark:bg-slate-700 justify-start"}`}
                  >
                    <span className="w-5 h-5 rounded-full bg-white shadow-sm" />
                  </button>
                </div>
                <p className="text-[11px] text-slate-400 dark:text-slate-500 leading-relaxed">
                  {autoWinBackEnabled ? t("aiCeo.autoDiscountDesc") : t("aiCeo.autoDiscountRequiresWinBackNote")}
                </p>
                {autoDiscountEnabled && autoWinBackEnabled && (
                  <div className="pt-1.5">
                    <p className="text-[10px] font-bold text-slate-400 dark:text-slate-500 mb-1">{t("aiCeo.autoDiscountPercentLabel")}</p>
                    <CustomSelect value={discountPercent} onChange={handleDiscountPercentChange} options={discountPercentOptions} disabled={savingDiscountPercent} />
                  </div>
                )}
              </div>

              {/* YANGI: Telegram orqali "1-tugmali tasdiqlash" - Mini
                  App'ni ochmasdan, AI CEO tavsiyasini to'g'ridan-to'g'ri
                  Telegram chatida bitta tugma bilan tasdiqlash. */}
              <div className="pt-3 border-t border-slate-50 dark:border-slate-800 space-y-1.5">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-bold text-slate-700 dark:text-slate-200 flex-1">{t("aiCeo.telegramApprovalTitle")}</span>
                  <button
                    type="button"
                    onClick={handleTelegramApprovalToggle}
                    disabled={savingTelegramApproval}
                    aria-label={t("aiCeo.telegramApprovalTitle")}
                    className={`w-10 h-6 rounded-full flex items-center px-0.5 transition-colors shrink-0 ${savingTelegramApproval ? "opacity-60" : ""} ${telegramApprovalEnabled ? "bg-indigo-600 justify-end" : "bg-slate-200 dark:bg-slate-700 justify-start"}`}
                  >
                    <span className="w-5 h-5 rounded-full bg-white shadow-sm" />
                  </button>
                </div>
                <p className="text-[11px] text-slate-400 dark:text-slate-500 leading-relaxed">{t("aiCeo.telegramApprovalDesc")}</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {showCapabilities && <CapabilitiesModal onClose={() => setShowCapabilities(false)} t={t} />}
    </div>
  );
};

export default AiCeoInfoPage;
