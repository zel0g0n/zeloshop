import { useState, useMemo, useCallback, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
  Eye, EyeOff, Share2, Plus, Package, Megaphone, Flame, Bot,
  Wallet, TrendingUp, ArchiveX,
} from "lucide-react";
import { useSession } from "@/context/SessionContext";
import { useLanguage } from "@/context/LanguageContext";
import useGetOrdersData from "@/hooks/seller/useRecentOrders";
import useGetProductsData from "@/hooks/seller/useGetSellerProducts";
import { useOrderRollups } from "@/hooks/seller/useOrderRollups";
import { usePendingOrdersCount } from "@/hooks/seller/usePendingOrdersCount";
import { buildShopLink } from "@/utils/shareLink";
import { getRangeStart } from "@/utils/dateRange";
import { computeDashboardStatsFromRollups } from "@/utils/dashboardStats";
import { getVisitorCount } from "@/services/analytics/getVisitorCount";
import { backfillSellerRollups } from "@/services/analytics/backfillRollups";
import TimeframeTabs from "./TimeframeTabs";
import KpiCard from "./KpiCard";
import RecentOrdersList from "./RecentOrdersList";
import ShareStoreModal from "./ShareStoreModal";
import OnboardingChecklist from "./OnboardingChecklist";
import DashboardSkeleton from "./DashboardSkeleton";
import Toast from "@/components/ui/Toast";

const TIMEFRAME_DAYS = { Bugun: 1, Hafta: 7, Oy: 30 };

// EXECUTIVE DASHBOARD — ULTRA-KOMPAKT, TEZKOR YUKLANUVCHI.
//
// MUHIM: rang kombinatsiyasi ATAYLAB loyihaning BOSHQA barcha
// sahifalari (Mahsulotlar, Buyurtmalar, Sozlamalar) bilan BIR XIL —
// theme-aware (och/to'q rejimga moslashuvchan). "Pure dark" (faqat
// to'q, boshqa sahifalardan farq qiluvchi) uslub sinab ko'rilgan
// edi, lekin foydalanuvchi sahifalar orasidagi rang izchilligini
// afzal ko'rdi — shuning uchun standart palitraga qaytarildi.
//
// OLDIN: bu sahifada og'ir Canvas/Chart.js grafigi (`SalesSummaryCard`
// ichidagi `SalesChart`) bor edi. Grafik endi BUTUNLAY olib tashlandi
// — u Moliya/P&L bo'limiga tegishli, bu yerda esa faqat eng muhim
// 4 ta KPI (ixcham kartochkalar) ko'rsatiladi.
//
// HAQIQIY KONVERSIYA: sotuvchi bu ko'rsatkichni haqiqiy qilishni
// so'ragach, tashriflarni kuzatuvchi tizim qurildi (`visits`
// kolleksiyasi, server tomonida — mijoz SDK'i uchun yopiq). "Bugun"
// uchun ma'lumot `verifyTelegramAuth` javobida allaqachon tayyor
// keladi; "Hafta"/"Oy" uchun esa `getVisitorCount` Cloud Function
// alohida so'raladi (davr o'zgarganda).
const Dashboard = () => {
  const navigate = useNavigate();
  const { sellerId, store, dashboardSummary, patchStore } = useSession();
  const { t } = useLanguage();
  const [timeframe, setTimeframe] = useState("Bugun");
  const [showShareModal, setShowShareModal] = useState(false);
  const [isPrivate, setIsPrivate] = useState(false);
  const [toastMessage, setToastMessage] = useState(null);
  const [visitorCount, setVisitorCount] = useState(null);

  const { orders = [], loading: ordersLoading } = useGetOrdersData(sellerId);
  const { products = [], loading: productsLoading } = useGetProductsData(sellerId);

  // MUHIM, ARXITEKTURA O'ZGARISHI (real production darajasiga
  // chiqarish): KPI statistikasi (savdo/foyda) ENDI xom
  // `useRecentOrders` ro'yxatidan EMAS, server tomonida oldindan
  // hisoblangan KUNLIK yig'ma yozuvlardan (`useOrderRollups`)
  // hisoblanadi - bu, buyurtmalar hajmi o'sganda ham sahifa
  // tezligini/Firestore xarajatini O'ZGARISHSIZ saqlaydi. `orders`
  // (yuqorida) endi FAQAT "So'nggi buyurtmalar" ro'yxatini
  // ko'rsatish uchun ishlatiladi (statistika uchun EMAS).
  // `sinceMs` mount vaqtida BIR MARTA hisoblanadi (60 kun - "Oy"
  // tabining o'zi VA uning solishtirish davrini qamrab olish uchun
  // yetarli) - shu orqali tab almashtirilganda qayta so'ralmaydi.
  // MUHIM: `Date.now()` render VAQTIDA to'g'ridan-to'g'ri chaqirilmaydi
  // (React Compiler'ning "impure" qoidasi) - buning o'rniga, "hozirgi
  // vaqt" BIR MARTA, komponent birinchi render qilinganda, `useState`
  // dangasa (lazy) boshlang'ich qiymati orqali "suratga olinadi".
  const [mountedAtMs] = useState(() => Date.now());
  const sinceMs = useMemo(() => mountedAtMs - 60 * 24 * 60 * 60 * 1000, [mountedAtMs]);
  const { days: rollupDays, loading: rollupsLoading } = useOrderRollups(sellerId, sinceMs);
  const { pendingCount } = usePendingOrdersCount(sellerId);

  const isClientDataLoading = ordersLoading || productsLoading || rollupsLoading;

  const canShowServerSummary = Boolean(dashboardSummary) && timeframe === "Bugun" && isClientDataLoading;
  const isLoading = isClientDataLoading && !canShowServerSummary;

  const stats = useMemo(() => {
    const rangeStart = getRangeStart(timeframe);
    const rangeLength = mountedAtMs - rangeStart;
    const prevRangeStart = rangeStart - rangeLength;
    return { ...computeDashboardStatsFromRollups(rollupDays, products, rangeStart, prevRangeStart), pendingCount };
  }, [rollupDays, products, timeframe, pendingCount, mountedAtMs]);

  // "Bugun" uchun tashriflar soni — auth javobida allaqachon bor.
  // "Hafta"/"Oy" uchun — alohida, server'dan so'raladi.
  useEffect(() => {
    if (timeframe === "Bugun") {
      setVisitorCount(dashboardSummary?.visitorCount ?? null);
      return;
    }
    if (!sellerId) return;

    let cancelled = false;
    setVisitorCount(null);
    getVisitorCount(sellerId, TIMEFRAME_DAYS[timeframe])
      .then((count) => { if (!cancelled) setVisitorCount(count); })
      .catch((err) => {
        console.error("Tashriflar sonini olishda xatolik:", err);
        if (!cancelled) setVisitorCount(null);
      });

    return () => { cancelled = true; };
  }, [timeframe, sellerId, dashboardSummary?.visitorCount]);

  // BIR MARTALIK, KO'RINMAS MIGRATSIYA: yangi server-side rollup
  // tizimi (batafsil izoh: `functions/orderRollups.js`) qurilishidan
  // OLDIN yaratilgan sotuvchilar uchun, mavjud buyurtma tarixini
  // "orqaga hisoblab" to'ldiradi - shu orqali eski sotuvchilarning
  // Dashboard/P&L/CRM ma'lumotlari "birdan yo'qolib qolmaydi". Faqat
  // BIR MARTA (`store.rollupsBackfilledAt` hali yo'q bo'lsa) ishga
  // tushadi - sotuvchi buni HECH QACHON ko'rmaydi/bilmaydi, oddiy fon
  // jarayoni. Xato bo'lsa ham jim - Dashboard'ning qolgan qismi
  // (rollup so'ralganda hali bo'sh bo'lishi mumkin, lekin xato
  // bermaydi) ishlayverishi kerak.
  useEffect(() => {
    // MUHIM: DIQQAT bilan faqat `rollupsBackfilledAt` bayrog'ining
    // O'ZIGA bog'liq qilingan (butun `store` ob'ektiga EMAS) - aks
    // holda, do'kon boshqa SABAB bilan (masalan mahsulot soni
    // yangilanganda) patch qilinganda ham bu effekt QAYTA ishga
    // tushib, keraksiz takroriy chaqiruvlarga olib kelardi.
    if (!sellerId || !store || store.rollupsBackfilledAt) return;
    let cancelled = false;
    backfillSellerRollups(sellerId)
      .then(() => {
        if (!cancelled) patchStore({ rollupsBackfilledAt: Date.now() });
      })
      .catch((err) => {
        console.error("Rollup migratsiyasida xatolik:", err);
      });
    return () => { cancelled = true; };
  }, [sellerId, Boolean(store), store?.rollupsBackfilledAt, patchStore]);

  const conversionRate = useMemo(() => {
    if (visitorCount === null || visitorCount === 0) return null;
    const ordersCount = canShowServerSummary ? dashboardSummary.ordersCount : stats.ordersCount;
    return Math.round((ordersCount / visitorCount) * 1000) / 10;
  }, [visitorCount, canShowServerSummary, dashboardSummary, stats]);

  const effectiveStats = canShowServerSummary
    ? {
        totalSales: dashboardSummary.totalSales,
        growthPercent: null,
        netProfit: dashboardSummary.netProfit,
        profitMargin: dashboardSummary.profitMargin,
        ordersCount: dashboardSummary.ordersCount,
        pendingCount: dashboardSummary.pendingCount,
        activeProductsCount: dashboardSummary.activeProductsCount,
        lowStockCount: dashboardSummary.lowStockCount,
        averageOrderValue: dashboardSummary.ordersCount > 0
          ? Math.round(dashboardSummary.totalSales / dashboardSummary.ordersCount)
          : 0,
      }
    : stats;
  const effectiveOrders = canShowServerSummary ? dashboardSummary.recentOrders : orders;

  const handleQuickShare = useCallback(async () => {
    const link = buildShopLink(sellerId);
    try {
      await navigator.clipboard.writeText(link);
      setToastMessage(t("sellerDashboard.linkCopied"));
    } catch {
      setShowShareModal(true);
    }
  }, [sellerId, t]);

  const hide = (value) => (isPrivate ? "•••" : value);

  return (
    <div className="h-screen flex flex-col bg-[#F4F5F9] dark:bg-slate-950 text-slate-900 dark:text-white font-sans antialiased transition-colors duration-300">

      {/* Sticky yuqori qism — `backdrop-blur` olib tashlandi
          (qimmat GPU xarajati), oddiy, qattiq fon bilan almashtirildi. */}
      <div className="shrink-0 sticky top-0 z-50 bg-white/95 dark:bg-slate-900/95 shadow-xs">
        <div className="px-5 pt-5 pb-3 flex items-center justify-between">
          <div className="flex items-center gap-2 min-w-0">
            <span className="text-base font-black text-slate-800 dark:text-white tracking-tight truncate">
              {store?.storeName || t("sellerDashboard.defaultTitle")}
            </span>
            <div className="flex items-center gap-1 bg-emerald-50 dark:bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 text-[9px] font-black px-2 py-0.5 rounded-full border border-emerald-100 dark:border-emerald-500/20 shrink-0">
              <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-ping"></span>
              <span>LIVE</span>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            {/* MUHIM: OLDIN AI CEO uchun katta, TO'LIQ KENGLIKDAGI
                karta pastda (asosiy kontent ichida) joylashgan edi -
                foydalanuvchi buni "ekranni to'liq qoplab qolgan" deb
                topdi. Endi - FAQAT shu kichik, diqqatni tortadigan
                (pulsatsiyalanuvchi nuqta bilan) ikonka, Ko'z/Ulashish
                tugmalari BILAN BIR QATORDA. */}
            {store?.aiCeoEnabled === true && (
              <button
                type="button"
                onClick={() => navigate("/seller/ai-ceo")}
                className="relative w-8 h-8 rounded-lg bg-indigo-50 dark:bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 flex items-center justify-center active:scale-90 transition-transform"
                aria-label={t("aiCeo.dashboardCardTitle")}
              >
                <Bot size={14} />
                <span className="absolute -top-0.5 -right-0.5 w-2 h-2 bg-indigo-500 rounded-full animate-pulse" />
              </button>
            )}
            <button
              type="button"
              onClick={() => setIsPrivate((v) => !v)}
              className="w-8 h-8 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 flex items-center justify-center active:scale-90 transition-transform"
              aria-label={isPrivate ? t("sellerDashboard.show") : t("sellerDashboard.hide")}
            >
              {isPrivate ? <EyeOff size={15} /> : <Eye size={15} />}
            </button>
            <button
              type="button"
              onClick={handleQuickShare}
              className="w-8 h-8 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 flex items-center justify-center active:scale-90 transition-transform"
              aria-label={t("sellerDashboard.shareAria")}
            >
              <Share2 size={14} />
            </button>
          </div>
        </div>

        <div className="px-5 pb-3">
          <TimeframeTabs timeframe={timeframe} onChange={setTimeframe} />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto">
        {isLoading ? (
          <DashboardSkeleton />
        ) : (
          <div className="p-4 space-y-4 pb-36 animate-fade-in">

            <OnboardingChecklist
              sellerId={sellerId}
              store={store}
              dashboardSummary={dashboardSummary}
              onOpenShareModal={() => setShowShareModal(true)}
            />

            {/* 2x2 KOMPAKT KPI KATAKLARI */}
            <div className="grid grid-cols-2 gap-2.5">
              <KpiCard
                icon={Wallet}
                iconColorClass="text-[#5346E0] dark:text-[#8b85f5]"
                label={t("sellerDashboard.totalSales")}
                value={hide(`${effectiveStats.totalSales.toLocaleString()} so'm`)}
                subtext={!isPrivate ? t("sellerDashboard.netProfitTemplate", { amount: effectiveStats.netProfit.toLocaleString(), margin: effectiveStats.profitMargin }) : null}
              />
              <KpiCard
                icon={Package}
                iconColorClass="text-blue-500 dark:text-blue-400"
                label={t("sellerDashboard.orders")}
                value={`${effectiveStats.ordersCount} ta`}
                subtext={effectiveStats.pendingCount > 0 ? t("sellerDashboard.pending", { count: effectiveStats.pendingCount }) : t("sellerDashboard.allReviewed")}
                subtextColorClass={effectiveStats.pendingCount > 0 ? "text-amber-600 dark:text-amber-400" : "text-emerald-600 dark:text-emerald-400"}
              />
              <KpiCard
                icon={TrendingUp}
                iconColorClass="text-violet-500 dark:text-violet-400"
                label={t("sellerDashboard.conversion")}
                value={conversionRate !== null ? `${conversionRate}%` : (visitorCount === null ? "..." : "—")}
                subtext={visitorCount !== null ? t("sellerDashboard.visits", { count: visitorCount }) : t("sellerDashboard.calculating")}
              />
              <KpiCard
                icon={effectiveStats.lowStockCount > 0 ? ArchiveX : Package}
                iconColorClass={effectiveStats.lowStockCount > 0 ? "text-rose-500 dark:text-rose-400" : "text-emerald-600 dark:text-emerald-400"}
                label={t("sellerDashboard.stock")}
                value={t("sellerDashboard.active", { count: effectiveStats.activeProductsCount })}
                subtext={effectiveStats.lowStockCount > 0 ? t("sellerDashboard.lowStock", { count: effectiveStats.lowStockCount }) : t("sellerDashboard.safeLevel")}
                subtextColorClass={effectiveStats.lowStockCount > 0 ? "text-rose-600 dark:text-rose-400" : "text-emerald-600 dark:text-emerald-400"}
              />
            </div>

            {/* TEZKOR AMALLAR */}
            <div className="flex gap-2 overflow-x-auto">
              <Link
                to="/seller/add-product"
                className="shrink-0 bg-[#5346E0] text-white rounded-xl px-3.5 py-2 text-xs font-semibold flex items-center gap-1.5 active:scale-95 transition-transform"
              >
                <Plus size={14} />
                {t("sellerDashboard.newProduct")}
              </Link>
              <Link
                to="/seller/orders"
                className="shrink-0 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 text-slate-700 dark:text-slate-200 rounded-xl px-3.5 py-2 text-xs font-semibold flex items-center gap-1.5 active:scale-95 transition-transform"
              >
                <Package size={14} />
                {t("sellerDashboard.ordersLink")}
              </Link>
              <Link
                to="/seller/create-promotion"
                className="shrink-0 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 text-slate-700 dark:text-slate-200 rounded-xl px-3.5 py-2 text-xs font-semibold flex items-center gap-1.5 active:scale-95 transition-transform"
              >
                <Flame size={14} />
                {t("sellerDashboard.createPromotion")}
              </Link>
              <Link
                to="/seller/marketing"
                className="shrink-0 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 text-slate-700 dark:text-slate-200 rounded-xl px-3.5 py-2 text-xs font-semibold flex items-center gap-1.5 active:scale-95 transition-transform"
              >
                <Megaphone size={14} />
                {t("sellerDashboard.createCoupon")}
              </Link>
            </div>

            <RecentOrdersList orders={effectiveOrders} />
          </div>
        )}
      </div>

      {showShareModal && (
        <ShareStoreModal sellerId={sellerId} storeName={store?.storeName} onClose={() => setShowShareModal(false)} />
      )}

      {toastMessage && (
        <Toast message={toastMessage} onDone={() => setToastMessage(null)} />
      )}
    </div>
  );
};

export default Dashboard;
