import React, { useState, useCallback, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Tag, Plus, Trash2, Percent, Wallet, Gift, ShoppingCart, Heart, RotateCcw } from "lucide-react";
import { useSession } from "@/context/SessionContext";
import { useCoupons } from "@/hooks/seller/useCoupons";
import updateSeller from "@/services/sellers/updateSeller";
import StatusModal from "@/components/ui/StatusModal";
import CustomSelect from "@/components/ui/CustomSelect";
import { useLanguage } from "@/context/LanguageContext";

const MarketingCoupons = () => {
  const navigate = useNavigate();
  const { t } = useLanguage();
  const { sellerId, store } = useSession();
  const { coupons, loading, create, remove } = useCoupons(sellerId);

  const [code, setCode] = useState("");
  const [discountType, setDiscountType] = useState("percent"); // "percent" | "fixed"
  const [discountValue, setDiscountValue] = useState("");
  const [expiresAt, setExpiresAt] = useState("");
  const [usageLimit, setUsageLimit] = useState("");
  const [creating, setCreating] = useState(false);
  const [formError, setFormError] = useState(null);
  const [deletingCode, setDeletingCode] = useState(null);
  const [globalError, setGlobalError] = useState(null);

  // REFERAL DASTURI SOZLAMALARI - standart bo'yicha YOQILGAN (10%),
  // sotuvchi o'chirishi yoki foizni o'zgartirishi mumkin.
  const [referralEnabled, setReferralEnabled] = useState(store?.referralProgramEnabled !== false);
  const [referralPercent, setReferralPercent] = useState(store?.referralDiscountPercent || 10);
  const [referralDirty, setReferralDirty] = useState(false);
  const [referralSaving, setReferralSaving] = useState(false);

  useEffect(() => {
    if (!store) return;
    setReferralEnabled(store.referralProgramEnabled !== false);
    setReferralPercent(store.referralDiscountPercent || 10);
  }, [store]);

  const handleReferralToggle = useCallback(async () => {
    const next = !referralEnabled;
    setReferralEnabled(next);
    if (sellerId) {
      try {
        await updateSeller(sellerId, { referralProgramEnabled: next });
      } catch (err) {
        setGlobalError(err.message);
      }
    }
  }, [referralEnabled, sellerId]);

  const handleReferralPercentSave = useCallback(async () => {
    if (!sellerId) return;
    setReferralSaving(true);
    try {
      await updateSeller(sellerId, { referralDiscountPercent: Number(referralPercent) || 10 });
      setReferralDirty(false);
    } catch (err) {
      setGlobalError(err.message);
    } finally {
      setReferralSaving(false);
    }
  }, [sellerId, referralPercent]);

  // "TASHLAB KETILGAN SAVAT" ESLATMASI SOZLAMALARI - eslatmaning
  // o'zi standart bo'yicha YOQILGAN (chegirmasiz - shunchaki
  // xotirlatib qo'yish), chegirma esa IXTIYORIY (0 = chegirmasiz).
  const [cartReminderEnabled, setCartReminderEnabled] = useState(store?.cartReminderEnabled !== false);
  const [cartReminderPercent, setCartReminderPercent] = useState(store?.cartReminderDiscountPercent || 0);
  const [cartReminderDirty, setCartReminderDirty] = useState(false);
  const [cartReminderSaving, setCartReminderSaving] = useState(false);

  useEffect(() => {
    if (!store) return;
    setCartReminderEnabled(store.cartReminderEnabled !== false);
    setCartReminderPercent(store.cartReminderDiscountPercent || 0);
  }, [store]);

  const handleCartReminderToggle = useCallback(async () => {
    const next = !cartReminderEnabled;
    setCartReminderEnabled(next);
    if (sellerId) {
      try {
        await updateSeller(sellerId, { cartReminderEnabled: next });
      } catch (err) {
        setGlobalError(err.message);
      }
    }
  }, [cartReminderEnabled, sellerId]);

  const handleCartReminderPercentSave = useCallback(async () => {
    if (!sellerId) return;
    setCartReminderSaving(true);
    try {
      await updateSeller(sellerId, { cartReminderDiscountPercent: Number(cartReminderPercent) || 0 });
      setCartReminderDirty(false);
    } catch (err) {
      setGlobalError(err.message);
    } finally {
      setCartReminderSaving(false);
    }
  }, [sellerId, cartReminderPercent]);

  // SEVIMLILAR VA QAYTA SOTIB OLISH ESLATMALARI - endi haqiqiy,
  // qurilgan bildirishnomalar (`functions/engagementReminders.js`) -
  // xuddi savat eslatmasi bilan BIR XIL yoqish/o'chirish naqshi,
  // lekin chegirmasiz (soddaroq - shunchaki eslatib qo'yish).
  const [favoriteReminderEnabled, setFavoriteReminderEnabled] = useState(store?.favoriteReminderEnabled !== false);
  const [repurchaseReminderEnabled, setRepurchaseReminderEnabled] = useState(store?.repurchaseReminderEnabled !== false);

  useEffect(() => {
    if (!store) return;
    setFavoriteReminderEnabled(store.favoriteReminderEnabled !== false);
    setRepurchaseReminderEnabled(store.repurchaseReminderEnabled !== false);
  }, [store]);

  const handleFavoriteReminderToggle = useCallback(async () => {
    const next = !favoriteReminderEnabled;
    setFavoriteReminderEnabled(next);
    if (sellerId) {
      try {
        await updateSeller(sellerId, { favoriteReminderEnabled: next });
      } catch (err) {
        setGlobalError(err.message);
      }
    }
  }, [favoriteReminderEnabled, sellerId]);

  const handleRepurchaseReminderToggle = useCallback(async () => {
    const next = !repurchaseReminderEnabled;
    setRepurchaseReminderEnabled(next);
    if (sellerId) {
      try {
        await updateSeller(sellerId, { repurchaseReminderEnabled: next });
      } catch (err) {
        setGlobalError(err.message);
      }
    }
  }, [repurchaseReminderEnabled, sellerId]);

  const handleCreate = useCallback(async (e) => {
    e.preventDefault();
    setFormError(null);

    if (!code.trim()) {
      setFormError(t("marketing.codeRequired"));
      return;
    }
    if (!discountValue || Number(discountValue) <= 0) {
      setFormError(t("marketing.valueRequired"));
      return;
    }
    if (discountType === "percent" && Number(discountValue) > 100) {
      setFormError(t("marketing.percentMax"));
      return;
    }

    setCreating(true);
    try {
      await create({
        code,
        discountType,
        discountValue,
        expiresAt: expiresAt || null,
        usageLimit: usageLimit || null,
      });
      setCode("");
      setDiscountValue("");
      setExpiresAt("");
      setUsageLimit("");
    } catch (err) {
      setFormError(err.message || t("marketing.createError"));
    } finally {
      setCreating(false);
    }
  }, [code, discountType, discountValue, expiresAt, usageLimit, create]);

  const handleDelete = useCallback(async (couponCode) => {
    setDeletingCode(couponCode);
    try {
      await remove(couponCode);
    } catch (err) {
      setGlobalError(err.message);
    } finally {
      setDeletingCode(null);
    }
  }, [remove]);

  return (
    <div className="min-h-screen bg-[#F4F5F9] dark:bg-slate-950 text-slate-900 dark:text-white font-sans antialiased pb-36 transition-colors duration-300">

      <div className="sticky top-0 z-30 bg-white/95 dark:bg-slate-900/95 px-4 py-4 shadow-xs flex items-center gap-3">
        <button type="button" onClick={() => navigate(-1)} className="p-1 text-slate-500 dark:text-slate-300 active:scale-95 transition-transform">
          <ArrowLeft size={20} />
        </button>
        <div>
          <h1 className="text-base font-black text-slate-800 dark:text-white">{t("marketing.title")}</h1>
          <p className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">{t("marketing.subtitle")}</p>
        </div>
      </div>

      <div className="p-4 space-y-4">

        {/* REFERAL DASTURI */}
        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-slate-400 dark:text-slate-500">
              <Gift size={13} />
              <h3 className="text-xs font-black uppercase tracking-wider">{t("marketing.referral.title")}</h3>
            </div>
            <button
              type="button"
              onClick={handleReferralToggle}
              className={`w-10 h-6 rounded-full flex items-center px-0.5 transition-colors ${referralEnabled ? "bg-indigo-600 justify-end" : "bg-slate-200 dark:bg-slate-700 justify-start"}`}
            >
              <span className="w-5 h-5 rounded-full bg-white shadow-sm" />
            </button>
          </div>
          <p className="text-[11px] text-slate-400 dark:text-slate-500 leading-relaxed">{t("marketing.referral.description")}</p>

          {referralEnabled && (
            <div className="flex items-center gap-2 pt-1">
              <div className="flex-1">
                <label className="text-[10px] font-bold text-slate-500 dark:text-slate-400">{t("marketing.referral.percentLabel")}</label>
                <div className="relative mt-1">
                  <input
                    type="number"
                    min="1"
                    max="50"
                    value={referralPercent}
                    onChange={(e) => { setReferralPercent(e.target.value); setReferralDirty(true); }}
                    className="w-full h-10 px-3 pr-8 bg-[#F4F5F9] dark:bg-slate-800 text-slate-900 dark:text-white rounded-xl text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-indigo-500"
                  />
                  <Percent size={12} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 dark:text-slate-500" />
                </div>
              </div>
              {referralDirty && (
                <button
                  type="button"
                  onClick={handleReferralPercentSave}
                  disabled={referralSaving}
                  className="h-10 px-4 mt-4 bg-indigo-600 text-white text-xs font-black rounded-xl disabled:opacity-60"
                >
                  {referralSaving ? t("marketing.referral.saving") : t("marketing.referral.save")}
                </button>
              )}
            </div>
          )}
        </div>

        {/* TASHLAB KETILGAN SAVAT ESLATMASI */}
        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-slate-400 dark:text-slate-500">
              <ShoppingCart size={13} />
              <h3 className="text-xs font-black uppercase tracking-wider">{t("marketing.cartReminder.title")}</h3>
            </div>
            <button
              type="button"
              onClick={handleCartReminderToggle}
              className={`w-10 h-6 rounded-full flex items-center px-0.5 transition-colors ${cartReminderEnabled ? "bg-indigo-600 justify-end" : "bg-slate-200 dark:bg-slate-700 justify-start"}`}
            >
              <span className="w-5 h-5 rounded-full bg-white shadow-sm" />
            </button>
          </div>
          <p className="text-[11px] text-slate-400 dark:text-slate-500 leading-relaxed">{t("marketing.cartReminder.description")}</p>

          {cartReminderEnabled && (
            <div className="flex items-center gap-2 pt-1">
              <div className="flex-1">
                <label className="text-[10px] font-bold text-slate-500 dark:text-slate-400">{t("marketing.cartReminder.percentLabel")}</label>
                <div className="relative mt-1">
                  <input
                    type="number"
                    min="0"
                    max="50"
                    placeholder="0"
                    value={cartReminderPercent}
                    onChange={(e) => { setCartReminderPercent(e.target.value); setCartReminderDirty(true); }}
                    className="w-full h-10 px-3 pr-8 bg-[#F4F5F9] dark:bg-slate-800 text-slate-900 dark:text-white rounded-xl text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-indigo-500"
                  />
                  <Percent size={12} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 dark:text-slate-500" />
                </div>
                <p className="text-[10px] text-slate-400 dark:text-slate-500 mt-1">{t("marketing.cartReminder.percentHint")}</p>
              </div>
              {cartReminderDirty && (
                <button
                  type="button"
                  onClick={handleCartReminderPercentSave}
                  disabled={cartReminderSaving}
                  className="h-10 px-4 mt-4 bg-indigo-600 text-white text-xs font-black rounded-xl disabled:opacity-60 shrink-0"
                >
                  {cartReminderSaving ? t("marketing.cartReminder.saving") : t("marketing.cartReminder.save")}
                </button>
              )}
            </div>
          )}
        </div>

        {/* SEVIMLILAR ESLATMASI (yangi qurilgan bildirishnoma) */}
        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-xs space-y-1">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-slate-400 dark:text-slate-500">
              <Heart size={13} />
              <h3 className="text-xs font-black uppercase tracking-wider">{t("marketing.favoriteReminder.title")}</h3>
            </div>
            <button
              type="button"
              onClick={handleFavoriteReminderToggle}
              className={`w-10 h-6 rounded-full flex items-center px-0.5 transition-colors ${favoriteReminderEnabled ? "bg-indigo-600 justify-end" : "bg-slate-200 dark:bg-slate-700 justify-start"}`}
            >
              <span className="w-5 h-5 rounded-full bg-white shadow-sm" />
            </button>
          </div>
          <p className="text-[11px] text-slate-400 dark:text-slate-500 leading-relaxed">{t("marketing.favoriteReminder.description")}</p>
        </div>

        {/* QAYTA SOTIB OLISH TAKLIFI (yangi qurilgan bildirishnoma) */}
        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-xs space-y-1">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-slate-400 dark:text-slate-500">
              <RotateCcw size={13} />
              <h3 className="text-xs font-black uppercase tracking-wider">{t("marketing.repurchaseReminder.title")}</h3>
            </div>
            <button
              type="button"
              onClick={handleRepurchaseReminderToggle}
              className={`w-10 h-6 rounded-full flex items-center px-0.5 transition-colors ${repurchaseReminderEnabled ? "bg-indigo-600 justify-end" : "bg-slate-200 dark:bg-slate-700 justify-start"}`}
            >
              <span className="w-5 h-5 rounded-full bg-white shadow-sm" />
            </button>
          </div>
          <p className="text-[11px] text-slate-400 dark:text-slate-500 leading-relaxed">{t("marketing.repurchaseReminder.description")}</p>
        </div>

        <form onSubmit={handleCreate} className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-xs space-y-3">
          <div className="flex items-center gap-1.5 text-slate-400 dark:text-slate-500">
            <Tag size={13} />
            <h3 className="text-xs font-black uppercase tracking-wider">{t("marketing.newCouponTitle")}</h3>
          </div>

          <input
            type="text"
            disabled={creating}
            placeholder={t("marketing.codePlaceholder")}
            value={code}
            onChange={(e) => setCode(e.target.value.toUpperCase())}
            className="w-full h-11 px-3 bg-[#F4F5F9] dark:bg-slate-800 text-slate-900 dark:text-white rounded-xl font-black text-sm uppercase tracking-wider focus:outline-none focus:ring-1 focus:ring-indigo-500 disabled:opacity-60"
          />

          <div className="grid grid-cols-2 gap-2">
            <CustomSelect
              disabled={creating}
              value={discountType}
              onChange={setDiscountType}
              options={[
                { value: "percent", label: t("marketing.percentOption") },
                { value: "fixed", label: t("marketing.fixedOption") },
              ]}
            />
            <input
              type="number"
              disabled={creating}
              placeholder={discountType === "percent" ? t("marketing.percentPlaceholder") : t("marketing.fixedPlaceholder")}
              value={discountValue}
              onChange={(e) => setDiscountValue(e.target.value)}
              className="h-11 px-3 bg-[#F4F5F9] dark:bg-slate-800 text-slate-900 dark:text-white rounded-xl text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-indigo-500 disabled:opacity-60"
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-500 dark:text-slate-400">{t("marketing.expiresLabel")}</label>
              <input
                type="date"
                disabled={creating}
                value={expiresAt}
                onChange={(e) => setExpiresAt(e.target.value)}
                className="w-full h-10 px-3 bg-[#F4F5F9] dark:bg-slate-800 text-slate-900 dark:text-white rounded-xl text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-indigo-500 disabled:opacity-60"
              />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-500 dark:text-slate-400">{t("marketing.usageLimitLabel")}</label>
              <input
                type="number"
                disabled={creating}
                placeholder={t("marketing.unlimitedPlaceholder")}
                value={usageLimit}
                onChange={(e) => setUsageLimit(e.target.value)}
                className="w-full h-10 px-3 bg-[#F4F5F9] dark:bg-slate-800 text-slate-900 dark:text-white rounded-xl text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-indigo-500 disabled:opacity-60"
              />
            </div>
          </div>

          {formError && <p className="text-[11px] text-rose-500 font-semibold">{formError}</p>}

          <button
            type="submit"
            disabled={creating}
            className="w-full h-11 bg-indigo-600 hover:bg-indigo-500 text-white font-black text-xs rounded-xl flex items-center justify-center gap-1.5 disabled:opacity-60"
          >
            <Plus size={14} /> {creating ? t("marketing.creating") : t("marketing.createButton")}
          </button>
        </form>

        <div className="space-y-2">
          <h3 className="text-xs font-black text-slate-500 dark:text-slate-400 uppercase tracking-wider px-1">{t("marketing.activeCouponsTitle")}</h3>

          {loading && <p className="text-center text-xs text-slate-400 dark:text-slate-500 py-6">{t("marketing.loading")}</p>}

          {!loading && coupons.length === 0 && (
            <p className="text-center text-xs text-slate-400 dark:text-slate-500 py-8">{t("marketing.noCoupons")}</p>
          )}

          {!loading && coupons.map((coupon) => (
            <div key={coupon.code} className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-xs p-3.5 flex items-center justify-between gap-2">
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-9 h-9 bg-indigo-50 dark:bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 rounded-xl flex items-center justify-center shrink-0">
                  {coupon.discountType === "percent" ? <Percent size={15} /> : <Wallet size={15} />}
                </div>
                <div className="min-w-0">
                  <p className="text-sm font-black text-slate-800 dark:text-white truncate flex items-center gap-1.5">
                    {coupon.code}
                    {coupon.isReferralReward && (
                      <span className="text-[9px] font-bold text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-500/10 px-1.5 py-0.5 rounded-md shrink-0">
                        {t("marketing.referral.rewardBadge")}
                      </span>
                    )}
                    {coupon.isCartRecoveryReward && (
                      <span className="text-[9px] font-bold text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-500/10 px-1.5 py-0.5 rounded-md shrink-0">
                        {t("marketing.cartReminder.rewardBadge")}
                      </span>
                    )}
                    {coupon.isAiCeoWinBackReward && (
                      <span className="text-[9px] font-bold text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-500/10 px-1.5 py-0.5 rounded-md shrink-0">
                        {t("marketing.aiCeoWinBack.rewardBadge")}
                      </span>
                    )}
                  </p>
                  <p className="text-[11px] text-slate-400 dark:text-slate-500">
                    {coupon.discountType === "percent" ? t("marketing.percentDiscount", { value: coupon.discountValue }) : t("marketing.fixedDiscount", { value: Number(coupon.discountValue).toLocaleString() })}
                    {coupon.usageLimit ? ` · ${t("marketing.usedOfLimit", { used: coupon.usedCount, limit: coupon.usageLimit })}` : ` · ${t("marketing.usedCount", { count: coupon.usedCount })}`}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => handleDelete(coupon.code)}
                disabled={deletingCode === coupon.code}
                className="w-8 h-8 rounded-lg bg-rose-50 dark:bg-rose-500/10 text-rose-500 flex items-center justify-center shrink-0 disabled:opacity-50"
                aria-label={t("marketing.deleteAria")}
              >
                <Trash2 size={14} />
              </button>
            </div>
          ))}
        </div>
      </div>

      {globalError && (
        <StatusModal variant="error" title={t("marketing.errorTitle")} message={globalError} onClose={() => setGlobalError(null)} />
      )}
    </div>
  );
};

export default MarketingCoupons;
