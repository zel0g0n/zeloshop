import React, { useState, useEffect, useCallback } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { ChevronLeft } from "lucide-react";
import { useSession } from "@/context/SessionContext";
import { useLanguage } from "@/context/LanguageContext";
import FullScreenSpinner from "@/components/ui/FullScreenSpinner";
import { useLoadProductForEdit } from "@/hooks/seller/useLoadProductForEdit";
import useUpdateProductFull from "@/hooks/seller/useUpdateProductFull";
import { useUploadImage } from "@/hooks/storage/useUploadStorage";
import { useProductImages } from "@/hooks/seller/useProductImages";
import { useAIDescription } from "@/hooks/seller/useAIDescription";
import { useSocialPost } from "@/hooks/seller/useSocialPost";
import { getCategoriesForNiche } from "@/constants/productCategories";
import StatusModal from "@/components/ui/StatusModal";

import FormErrors from "./FormErrors";
import AIBanner from "./AIBanner";
import MultiImageUploadCard from "./MultiImageUploadCard";
import BasicInfoCard from "./BasicInfoCard";
import PricingCard from "./PricingCard";
import VariantsCard from "./VariantsCard";
import DescriptionCard from "./DescriptionCard";
import SocialPostGeneratorCard from "./SocialPostGeneratorCard";
import SellerReviewsCard from "./SellerReviewsCard";
import SubmitBar from "./SubmitBar";

// OLDIN: mahsulotni tahrirlash faqat pastdan chiqadigan tor modal
// (QuickEditSheet) orqali, faqat narx va stok uchun mumkin edi. Endi
// bu — to'liq, alohida marshrutga ega sahifa (/seller/products/:id/edit),
// AddProductPage bilan bir xil, tanish shaklda — shu jumladan
// "Saqlash" tugmasi ham, formaning ODDIY, TABIIY oxirgi elementi
// sifatida (sun'iy joylashuvsiz, forma bilan birga skroll bo'ladi).
const EditProductPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { sellerId, store } = useSession();
  const { t } = useLanguage();
  const { product, loading: productLoading, error: productError } = useLoadProductForEdit(id);
  const { updateProduct, loading: saving, error: saveError } = useUpdateProductFull();
  const {
    uploadImage,
    progress: uploadProgress,
    loading: uploadLoading,
    error: uploadError,
    setError: setUploadError,
  } = useUploadImage();
  const { images, addFiles, removeImage, setThumbnail, initFromUrls, resolveUploadedUrls } = useProductImages();

  const [title, setTitle] = useState("");
  const [category, setCategory] = useState("");
  const [price, setPrice] = useState("");
  const [costPrice, setCostPrice] = useState("");
  const [discountPrice, setDiscountPrice] = useState("");
  const [paymentTypes, setPaymentTypes] = useState(["prepay"]);
  const [stock, setStock] = useState("");
  const [description, setDescription] = useState("");
  const [variants, setVariants] = useState([]);
  const [showSavedModal, setShowSavedModal] = useState(false);
  const [notOwner, setNotOwner] = useState(false);

  const { generating: aiGenerating, error: aiError, generate: handleGenerateAI } = useAIDescription({
    productName: title,
    category,
    thumbnailImage: images[0],
    onResult: setDescription,
  });

  const {
    platform: socialPlatform,
    setPlatform: setSocialPlatform,
    postText: socialPostText,
    setPostText: setSocialPostText,
    generating: socialGenerating,
    error: socialError,
    generate: handleGenerateSocialPost,
  } = useSocialPost({
    productName: title,
    description,
    price,
    thumbnailImage: images[0],
  });

  useEffect(() => {
    if (!product) return;

    if (product.sellerId && sellerId && product.sellerId !== sellerId) {
      setNotOwner(true);
      return;
    }

    setTitle(product.name || "");
    setCategory(product.category || getCategoriesForNiche(store?.category)[0]?.value || "");
    setPrice(String(product.price ?? ""));
    setCostPrice(String(product.costPrice ?? ""));
    setDiscountPrice(product.discountPrice != null ? String(product.discountPrice) : "");
    setPaymentTypes(
      Array.isArray(product.paymentTypes) && product.paymentTypes.length > 0
        ? product.paymentTypes
        : (product.paymentType ? [product.paymentType] : ["prepay"])
    );
    setStock(String(product.stock ?? ""));
    setDescription(product.description || "");
    setVariants(product.variants || []);

    const existingImages = Array.isArray(product.images) && product.images.length > 0
      ? product.images
      : (product.image ? [product.image] : []);
    initFromUrls(existingImages);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [product, sellerId, store]);

  const handleAddFiles = useCallback(
    (files) => {
      setUploadError(null);
      addFiles(files);
    },
    [addFiles, setUploadError]
  );

  const handleTogglePaymentType = useCallback((type) => {
    setPaymentTypes((prev) =>
      prev.includes(type) ? prev.filter((t) => t !== type) : [...prev, type]
    );
  }, []);

  const isGlobalLoading = uploadLoading || saving;

  const handleSubmit = useCallback(
    async (e) => {
      e.preventDefault();
      try {
        const imageUrls = await resolveUploadedUrls(uploadImage, `products/${sellerId}`);
        await updateProduct(id, {
          title,
          category,
          price: Number(price),
          costPrice: Number(costPrice),
          discountPrice: discountPrice !== "" ? Number(discountPrice) : null,
          paymentTypes,
          stock: Number(stock),
          description,
          images: imageUrls,
          variants,
        });
        setShowSavedModal(true);
      } catch (err) {
        console.error("Mahsulotni yangilashda xatolik:", err);
      }
    },
    [id, sellerId, resolveUploadedUrls, uploadImage, title, category, price, costPrice, discountPrice, paymentTypes, stock, description, variants, updateProduct]
  );

  if (productLoading) {
    return <FullScreenSpinner />;
  }

  if (productError || notOwner) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-3 bg-[#F4F5F9] dark:bg-slate-950 px-6 text-center">
        <p className="text-sm font-bold text-slate-800 dark:text-white">
          {notOwner ? t("sellerProductForm.notOwner") : productError}
        </p>
        <button
          onClick={() => navigate("/seller/products")}
          className="px-5 py-2.5 bg-indigo-600 text-white text-xs font-bold rounded-xl"
        >
          Ortga qaytish
        </button>
      </div>
    );
  }

  return (
    <div className="h-screen overflow-y-auto bg-[#F4F5F9] dark:bg-slate-950 text-slate-900 dark:text-white font-sans antialiased transition-colors duration-300">
      <div className="sticky top-0 z-30 bg-white dark:bg-slate-900 px-5 py-4 shadow-xs flex items-center gap-3">
        <button
          type="button"
          className="p-1 text-slate-500 dark:text-slate-300 active:scale-95 transition-transform"
          onClick={() => navigate("/seller/products")}
        >
          <ChevronLeft size={20} strokeWidth={2.5} />
        </button>
        <div>
          <h1 className="text-base font-black text-slate-800 dark:text-white tracking-tight">{t("sellerProductForm.editTitle")}</h1>
          <p className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider truncate max-w-[220px]">{title}</p>
        </div>
      </div>

      <form id="edit-product-form" onSubmit={handleSubmit} className="p-4 pb-36 space-y-4">
        <FormErrors uploadError={uploadError} dbError={saveError} />

        <AIBanner generating={aiGenerating} error={aiError} onGenerate={handleGenerateAI} />

        <MultiImageUploadCard
          images={images}
          disabled={isGlobalLoading}
          onAddFiles={handleAddFiles}
          onRemoveImage={removeImage}
          onSetThumbnail={setThumbnail}
        />

        <BasicInfoCard
          title={title}
          category={category}
          disabled={isGlobalLoading}
          onTitleChange={setTitle}
          onCategoryChange={setCategory}
        />

        <PricingCard
          price={price}
          costPrice={costPrice}
          discountPrice={discountPrice}
          paymentTypes={paymentTypes}
          stock={stock}
          disabled={isGlobalLoading}
          onPriceChange={setPrice}
          onCostPriceChange={setCostPrice}
          onDiscountPriceChange={setDiscountPrice}
          onTogglePaymentType={handleTogglePaymentType}
          onStockChange={setStock}
        />

        <VariantsCard
          variants={variants}
          disabled={isGlobalLoading}
          onVariantsChange={setVariants}
        />

        <DescriptionCard
          description={description}
          disabled={isGlobalLoading}
          generating={aiGenerating}
          onGenerate={handleGenerateAI}
          onDescriptionChange={setDescription}
        />

        {store?.aiCeoEnabled === true && (
          <SocialPostGeneratorCard
            platform={socialPlatform}
            onPlatformChange={setSocialPlatform}
            postText={socialPostText}
            onPostTextChange={setSocialPostText}
            generating={socialGenerating}
            error={socialError}
            onGenerate={handleGenerateSocialPost}
            productImageUrl={images[0]?.url || null}
          />
        )}

        <SellerReviewsCard productId={id} />

        <SubmitBar
          isGlobalLoading={isGlobalLoading}
          uploadLoading={uploadLoading}
          uploadProgress={uploadProgress}
          idleLabel={t("sellerProductForm.saveChanges")}
          savingLabel={t("sellerProductForm.saving")}
        />
      </form>

      {showSavedModal && (
        <StatusModal
          variant="success"
          title={t("sellerProductForm.changesSaved")}
          onClose={() => navigate(-1)}
        />
      )}
    </div>
  );
};

export default EditProductPage;
