import React, { useState, useEffect, useCallback } from "react";
import { useSession } from "@/context/SessionContext";
import { useLanguage } from "@/context/LanguageContext";
import useAddProduct from "@/hooks/seller/useAddProduct";
import { useUploadImage } from "@/hooks/storage/useUploadStorage";
import { useProductImages } from "@/hooks/seller/useProductImages";
import { useAIDescription } from "@/hooks/seller/useAIDescription";
import StatusModal from "@/components/ui/StatusModal";

import PageHeader from "./PageHeader";
import FormErrors from "./FormErrors";
import QuickAddAICard from "./QuickAddAICard";
import MultiImageUploadCard from "./MultiImageUploadCard";
import BasicInfoCard from "./BasicInfoCard";
import PricingCard from "./PricingCard";
import VariantsCard from "./VariantsCard";
import DescriptionCard from "./DescriptionCard";
import SubmitBar from "./SubmitBar";

// OLDIN (1-bosqich): tugma `position: fixed` orqali ekranga
// mahkamlangan edi — mobil klaviatura ochilganda ba'zi WebView'larda
// noto'g'ri joyda qolib ketishi mumkin edi.
//
// OLDIN (2-bosqich): shu muammoni hal qilish uchun, forma va tugma
// IKKI ALOHIDA skroll hududiga (flex-column) bo'lingan edi — tugma
// har doim ko'rinardi, lekin bu, "tugma forma bilan birga tabiiy
// skroll bo'lishi kerak" talabiga zid edi.
//
// ENDI: eng oddiy, ENG TABIIY yondashuv — butun sahifa (sarlavha +
// forma + tugma) BITTA umumiy hujjat oqimida, oddiy `overflow-y-auto`
// bilan skroll bo'ladi. Tugma — formaning haqiqiy, oxirgi elementi.
const AddProductPage = () => {
  const { sellerId, store, dashboardSummary, patchDashboardSummary } = useSession();
  const isAiCeoEnabled = store?.aiCeoEnabled === true;
  const { t } = useLanguage();
  const { addProduct, loading: dbLoading, success: dbSuccess, error: dbError, resetState } = useAddProduct();
  const {
    uploadImage,
    progress: uploadProgress,
    loading: uploadLoading,
    error: uploadError,
    setError: setUploadError,
  } = useUploadImage();

  const { images, addFiles, removeImage, setThumbnail, resolveUploadedUrls, reset: resetImages } = useProductImages();

  const [title, setTitle] = useState("");
  const [category, setCategory] = useState("");
  const [price, setPrice] = useState("");
  const [costPrice, setCostPrice] = useState("");
  const [discountPrice, setDiscountPrice] = useState("");
  const [paymentTypes, setPaymentTypes] = useState(["prepay"]);
  const [stock, setStock] = useState("");
  const [description, setDescription] = useState("");
  const [variants, setVariants] = useState([]);

  const { generating: aiGenerating, error: aiError, generate: handleGenerateAI } = useAIDescription({
    productName: title,
    category,
    thumbnailImage: images[0],
    onResult: setDescription,
  });

  const resetForm = useCallback(() => {
    setTitle("");
    setCategory("");
    setPrice("");
    setCostPrice("");
    setDiscountPrice("");
    setPaymentTypes(["prepay"]);
    setStock("");
    setDescription("");
    setVariants([]);
    resetImages();
  }, [resetImages]);

  const [showSavedModal, setShowSavedModal] = useState(false);

  useEffect(() => {
    if (dbSuccess) {
      setShowSavedModal(true);
      resetForm();
      resetState();
      // Checklistdagi "Birinchi mahsulotingizni qo'shing" bosqichi
      // `dashboardSummary.totalProductsCount`ga qarab hisoblanadi -
      // sahifa yangilanmasdan darhol "bajarilgan" ko'rinishi uchun.
      patchDashboardSummary({ totalProductsCount: (dashboardSummary?.totalProductsCount || 0) + 1 });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dbSuccess, resetState, resetForm]);

  const handleAddFiles = useCallback(
    (files) => {
      setUploadError(null);
      addFiles(files);
    },
    [addFiles, setUploadError]
  );

  const handleTogglePaymentType = useCallback((type) => {
    setPaymentTypes((prev) =>
      prev.includes(type) ? prev.filter((t) => t !== type) : [...prev, type]
    );
  }, []);

  const isGlobalLoading = uploadLoading || dbLoading;

  const handleSubmit = useCallback(
    async (e) => {
      e.preventDefault();

      try {
        const imageUrls = await resolveUploadedUrls(uploadImage, `products/${sellerId}`);

        const finalProductData = {
          title,
          category,
          price: Number(price),
          costPrice: Number(costPrice),
          discountPrice: discountPrice !== "" ? Number(discountPrice) : null,
          paymentTypes,
          stock: Number(stock),
          description,
          images: imageUrls,
          variants,
        };

        await addProduct(finalProductData);
      } catch (err) {
        console.error("Mahsulot yaratishda xatolik:", err);
      }
    },
    [sellerId, resolveUploadedUrls, uploadImage, title, category, price, costPrice, discountPrice, paymentTypes, stock, description, variants, addProduct]
  );

  return (
    <div className="h-screen overflow-y-auto bg-[#F4F5F9] dark:bg-slate-950 text-slate-900 dark:text-white font-sans antialiased transition-colors duration-300">
      <PageHeader />

      <form id="add-product-form" onSubmit={handleSubmit} className="p-4 pb-36 space-y-4">
        <FormErrors uploadError={uploadError} dbError={dbError} />

        {isAiCeoEnabled && <QuickAddAICard />}

        <MultiImageUploadCard
          images={images}
          disabled={isGlobalLoading}
          onAddFiles={handleAddFiles}
          onRemoveImage={removeImage}
          onSetThumbnail={setThumbnail}
        />

        <BasicInfoCard
          title={title}
          category={category}
          disabled={isGlobalLoading}
          onTitleChange={setTitle}
          onCategoryChange={setCategory}
        />

        <PricingCard
          price={price}
          costPrice={costPrice}
          discountPrice={discountPrice}
          paymentTypes={paymentTypes}
          stock={stock}
          disabled={isGlobalLoading}
          onPriceChange={setPrice}
          onCostPriceChange={setCostPrice}
          onDiscountPriceChange={setDiscountPrice}
          onTogglePaymentType={handleTogglePaymentType}
          onStockChange={setStock}
        />

        <VariantsCard
          variants={variants}
          disabled={isGlobalLoading}
          onVariantsChange={setVariants}
        />

        <DescriptionCard
          description={description}
          disabled={isGlobalLoading}
          generating={aiGenerating}
          error={aiError}
          onGenerate={handleGenerateAI}
          onDescriptionChange={setDescription}
        />

        <SubmitBar isGlobalLoading={isGlobalLoading} uploadLoading={uploadLoading} uploadProgress={uploadProgress} />
      </form>

      {showSavedModal && (
        <StatusModal
          variant="success"
          title={t("sellerProductForm.savedTitle")}
          onClose={() => setShowSavedModal(false)}
        />
      )}
    </div>
  );
};

export default AddProductPage;
