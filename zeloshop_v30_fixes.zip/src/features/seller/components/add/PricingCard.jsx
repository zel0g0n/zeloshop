import React from "react";
import { Calculator, CreditCard, Package, Check } from "lucide-react";
import { computeProfitMetrics } from "@/utils/productPricing";
import { useLanguage } from "@/context/LanguageContext";

// OLDIN: hisob-kitob mantig'i shu komponent ICHIDA edi — endi sof,
// alohida sinov (test) qilinadigan funksiyaga (`utils/productPricing.js`)
// ajratildi. Bu ham kodni tozalaydi, ham xatolarni oldindan tutish
// imkonini beradi.
const PricingCard = ({
  price,
  costPrice,
  discountPrice,
  paymentTypes,
  stock,
  disabled,
  onPriceChange,
  onCostPriceChange,
  onDiscountPriceChange,
  onStockChange,
  onTogglePaymentType,
}) => {
  const { t } = useLanguage();
  const { profit, marginPercentage, hasValues } = computeProfitMetrics(price, costPrice, discountPrice);

  return (
    <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-xs space-y-3.5">
      <div className="flex justify-between items-center">
        <label className="text-[11px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-wider block">{t("sellerProductForm.pricingLabel")}</label>
        <span className="text-[9px] font-black bg-indigo-50 dark:bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 px-2 py-0.5 rounded-sm flex items-center gap-1">
          <Calculator size={10} /> {t("sellerProductForm.smartCalculator")}
        </span>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-1">
          <label className="text-[10px] font-bold text-slate-500 dark:text-slate-400 block">{t("sellerProductForm.costPriceLabel")}</label>
          <input
            type="number"
            required
            disabled={disabled}
            placeholder="0"
            value={costPrice}
            onChange={(e) => onCostPriceChange(e.target.value)}
            className="w-full h-11 px-3 bg-[#F4F5F9] dark:bg-slate-800 text-slate-900 dark:text-white rounded-xl font-black text-xs focus:outline-none focus:ring-1 focus:ring-indigo-500 disabled:opacity-60"
          />
        </div>

        <div className="space-y-1">
          <label className="text-[10px] font-bold text-slate-500 dark:text-slate-400 block">{t("sellerProductForm.sellPriceLabel")}</label>
          <input
            type="number"
            required
            disabled={disabled}
            placeholder="0"
            value={price}
            onChange={(e) => onPriceChange(e.target.value)}
            className="w-full h-11 px-3 bg-[#F4F5F9] dark:bg-slate-800 text-slate-900 dark:text-white rounded-xl font-black text-xs focus:outline-none focus:ring-1 focus:ring-indigo-500 disabled:opacity-60"
          />
        </div>

        <div className="space-y-1 col-span-2">
          <label className="text-[10px] font-bold text-slate-500 dark:text-slate-400 block">{t("sellerProductForm.discountPriceLabel")}</label>
          <input
            type="number"
            disabled={disabled}
            placeholder={t("sellerProductForm.discountPlaceholder")}
            value={discountPrice}
            onChange={(e) => onDiscountPriceChange(e.target.value)}
            className="w-full h-11 px-3 bg-[#F4F5F9] dark:bg-slate-800 text-slate-900 dark:text-white rounded-xl font-black text-xs focus:outline-none focus:ring-1 focus:ring-indigo-500 disabled:opacity-60 placeholder:font-normal placeholder:text-[10px]"
          />
        </div>
      </div>

      {hasValues && (
        <div
          className={`border p-3 rounded-xl flex items-center justify-between ${
            profit >= 0
              ? "bg-emerald-50 dark:bg-emerald-500/10 border-emerald-100 dark:border-emerald-500/20 text-emerald-800 dark:text-emerald-400"
              : "bg-rose-50 dark:bg-rose-500/10 border-rose-100 dark:border-rose-500/20 text-rose-700 dark:text-rose-400"
          }`}
        >
          <div>
            <div className="text-[10px] font-bold uppercase tracking-wider opacity-70">{t("sellerProductForm.netProfit")}</div>
            <div className="text-sm font-black mt-0.5">
              {profit >= 0 ? "+" : ""}
              {profit.toLocaleString()} so'm
            </div>
          </div>
          <div className="text-right">
            <div className="text-[10px] font-bold uppercase tracking-wider opacity-70">{t("sellerProductForm.margin")}</div>
            <div className="text-sm font-black mt-0.5">{marginPercentage}%</div>
          </div>
        </div>
      )}

      <div className="space-y-1 pt-1">
        <label className="text-[11px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-wider block">{t("sellerProductForm.stockQtyLabel")}</label>
        <input
          type="number"
          required
          disabled={disabled}
          placeholder={t("sellerProductForm.stockPlaceholder")}
          value={stock}
          onChange={(e) => onStockChange(e.target.value)}
          className="w-full h-11 px-3 bg-[#F4F5F9] dark:bg-slate-800 text-slate-900 dark:text-white rounded-xl font-semibold text-xs focus:outline-none focus:ring-1 focus:ring-indigo-500 disabled:opacity-60"
        />
      </div>

      {/* TO'LOV TURI — sotuvchi belgilaydi, bir nechtasini tanlashi
          mumkin (masalan ikkalasi ham). Xaridor faqat sotuvchi
          yoqqan variantlar orasidan ko'radi, o'zi qo'shimcha tanlay
          olmaydi. */}
      <div className="space-y-1.5 pt-1">
        <label className="text-[11px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-wider block">{t("sellerProductForm.paymentTypeLabel")}</label>
        <div className="space-y-2">
          <button
            type="button"
            disabled={disabled}
            onClick={() => onTogglePaymentType("prepay")}
            className={`w-full flex items-center gap-3 p-3 rounded-2xl border transition-colors ${
              paymentTypes.includes("prepay")
                ? "bg-indigo-50 dark:bg-indigo-500/10 border-indigo-500"
                : "bg-[#F4F5F9] dark:bg-slate-800 border-transparent"
            }`}
          >
            <span className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
              paymentTypes.includes("prepay") ? "bg-indigo-600 text-white" : "bg-white dark:bg-slate-900 text-indigo-400"
            }`}>
              <CreditCard size={16} />
            </span>
            <div className="text-left flex-1">
              <p className={`text-xs font-black ${paymentTypes.includes("prepay") ? "text-indigo-700 dark:text-indigo-300" : "text-slate-600 dark:text-slate-300"}`}>{t("sellerProductForm.prepayTitle")}</p>
              <p className="text-[10px] text-slate-400 dark:text-slate-500">{t("sellerProductForm.prepayDesc")}</p>
            </div>
            <span className={`w-5 h-5 rounded-md border-2 flex items-center justify-center shrink-0 ${
              paymentTypes.includes("prepay") ? "bg-indigo-600 border-indigo-600 text-white" : "border-slate-300 dark:border-slate-600"
            }`}>
              {paymentTypes.includes("prepay") && <Check size={12} strokeWidth={3} />}
            </span>
          </button>

          <button
            type="button"
            disabled={disabled}
            onClick={() => onTogglePaymentType("cod")}
            className={`w-full flex items-center gap-3 p-3 rounded-2xl border transition-colors ${
              paymentTypes.includes("cod")
                ? "bg-indigo-50 dark:bg-indigo-500/10 border-indigo-500"
                : "bg-[#F4F5F9] dark:bg-slate-800 border-transparent"
            }`}
          >
            <span className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
              paymentTypes.includes("cod") ? "bg-indigo-600 text-white" : "bg-white dark:bg-slate-900 text-emerald-500"
            }`}>
              <Package size={16} />
            </span>
            <div className="text-left flex-1">
              <p className={`text-xs font-black ${paymentTypes.includes("cod") ? "text-indigo-700 dark:text-indigo-300" : "text-slate-600 dark:text-slate-300"}`}>{t("sellerProductForm.codTitle")}</p>
              <p className="text-[10px] text-slate-400 dark:text-slate-500">{t("sellerProductForm.codDesc")}</p>
            </div>
            <span className={`w-5 h-5 rounded-md border-2 flex items-center justify-center shrink-0 ${
              paymentTypes.includes("cod") ? "bg-indigo-600 border-indigo-600 text-white" : "border-slate-300 dark:border-slate-600"
            }`}>
              {paymentTypes.includes("cod") && <Check size={12} strokeWidth={3} />}
            </span>
          </button>
        </div>
        {paymentTypes.length === 0 && (
          <p className="text-[10px] text-rose-500 font-semibold pl-1">{t("sellerProductForm.paymentTypeRequired")}</p>
        )}
      </div>
    </div>
  );
};

export default React.memo(PricingCard);
