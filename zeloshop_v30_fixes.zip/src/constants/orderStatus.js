// OLDIN: faqat 3 ta status bor edi (new/approved/cancel) — bu haqiqiy
// buyurtma jarayonini (to'lov kutish, yig'ish, yo'lda, yetkazish)
// aks ettirmasdi. Endi 6 ta mantiqiy bosqich:
//
// KO'P TILLILIK TUZATISHI: OLDIN `label`/`shortLabel` maydonlari
// TO'G'RIDAN-TO'G'RI o'zbekcha matn edi — bu, funksiyani chaqiruvchi
// HAR BIR komponentda (xaridor VA sotuvchi tomonida) tarjima
// qilinmasdan qolishiga sabab bo'lgan edi. Endi bu yerda faqat RANG
// va STATUS KALITI (`key`) qaytariladi — chaqiruvchi tomon esa
// `t(\`orderStatus.${statusInfo.key}\`)` orqali, joriy tilga mos matnni
// oladi.
export const ORDER_STATUS_LABELS = {
  pending: { key: "pending", color: "bg-amber-100 text-amber-700 dark:bg-amber-500/10 dark:text-amber-400" },
  new: { key: "new", color: "bg-purple-100 text-purple-700 dark:bg-purple-500/10 dark:text-purple-400" },
  processing: { key: "processing", color: "bg-blue-100 text-blue-700 dark:bg-blue-500/10 dark:text-blue-400" },
  shipped: { key: "shipped", color: "bg-orange-100 text-orange-700 dark:bg-orange-500/10 dark:text-orange-400" },
  delivered: { key: "delivered", color: "bg-emerald-100 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-400" },
  cancel: { key: "cancel", color: "bg-rose-100 text-rose-700 dark:bg-rose-500/10 dark:text-rose-400" },
};

export const getOrderStatusInfo = (status) =>
  ORDER_STATUS_LABELS[status] || ORDER_STATUS_LABELS.new;

// Tab panelida ko'rsatiladigan tartib.
export const ORDER_STATUS_TABS = ["pending", "new", "processing", "shipped", "delivered", "cancel"];

// Har bir status uchun "keyingi bosqich" tugmasi — dinamik CTA.
// MUHIM: matnlar endi emoji ISHLATMAYDI — tugmalarda ko'rsatiladigan
// ikonka `lucide-react`dan, kod ichida (OrderCard.jsx) alohida
// tanlanadi (statusga qarab). Matn endi tarjima KALITI (`labelKey`) —
// chaqiruvchi tomon `t(\`orderStatus.actions.${labelKey}\`)` orqali oladi.
export const NEXT_STATUS_ACTION = {
  pending: { next: "new", labelKey: "markAsNew" },
  new: { next: "processing", labelKey: "confirmAndCollect" },
  processing: { next: "shipped", labelKey: "handToCourier" },
  shipped: { next: "delivered", labelKey: "markAsDelivered" },
  delivered: null,
  cancel: null,
};

// "Bekor qilish" tugmasi qaysi statuslarda ko'rsatiladi (yakuniy
// bosqichlarda — yetkazilgan yoki allaqachon bekor qilingan — endi
// bekor qilib bo'lmaydi).
export const CAN_CANCEL_STATUSES = ["pending", "new", "processing", "shipped"];

// Bekor qilish sabablari — endi tarjima kaliti sifatida (chaqiruvchi
// `t(\`orderStatus.cancelReasons.${key}\`)` orqali oladi).
export const CANCEL_REASON_KEYS = ["customerDeclined", "outOfStock", "unreachable", "other"];
