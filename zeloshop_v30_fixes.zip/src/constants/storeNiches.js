// Do'kon SOHASI (butun do'konga tegishli, keng ro'yxat) — bu
// `constants/productCategories.js` dagi (Skincare/Makeup/Perfume/Tools)
// mahsulot kategoriyalaridan FARQ QILADI. U yerdagi ro'yxat faqat
// kosmetika mahsulotlari uchun edi; bu yerdagi ro'yxat esa istalgan
// sohadagi sotuvchi ro'yxatdan o'tishi uchun.
//
// MUHIM: bu qiymatlar (`value`) — Firestore'da saqlanadigan va
// `getCategoriesForNiche()` orqali mos mahsulot kategoriyalarini
// topish uchun KALIT sifatida ishlatiladigan MA'LUMOT (xuddi
// mahsulot kategoriyalari kabi) — shuning uchun ATAYLAB tarjima
// qilinmaydi (Products bosqichida qabul qilingan qaror bilan bir xil).
//
// OLDIN bu yerda emoji (`icon`) maydoni bor edi — lekin bu ro'yxat
// FAQAT native HTML `<select><option>` ichida ishlatiladi, u yerda
// Lucide SVG ikonkalarini ko'rsatib bo'lmaydi (option — faqat matn).
// Shuning uchun emoji butunlay olib tashlandi (loyihaning "faqat
// lucide-react ikonkalar" qoidasiga mos ravishda).
//
// MUHIM eslatma: hozircha "Mahsulot qo'shish" formasi (BasicInfoCard)
// faqat kosmetika kategoriyalarini taklif qiladi. Agar sotuvchi bu yerda
// "Kiyim-kechak" yoki boshqa sohani tanlasa, mahsulot qo'shishda hali
// ham faqat kosmetika kategoriyalari ko'rinadi — bu nomuvofiqlik, lekin
// uni tuzatish (har bir soha uchun alohida mahsulot kategoriyalari
// tizimi) alohida, kattaroq ish, hozircha so'ralmagan.
export const STORE_NICHES = [
  { value: "Kosmetika" },
  { value: "Kiyim-kechak" },
  { value: "Poyabzal" },
  { value: "Elektronika" },
  { value: "Texnika mahsulotlari" },
  { value: "Uy-ro'zg'or buyumlari" },
  { value: "Bolalar tovarlari" },
  { value: "Oziq-ovqat" },
  { value: "Konditer mahsulotlari" },
  { value: "Sport va faollik" },
  { value: "Zargarlik va aksessuarlar" },
  { value: "Gullar" },
  { value: "Kitoblar" },
  { value: "Qo'l mehnati mahsulotlari" },
  { value: "Suvenir mahsulotlar" },
  { value: "Intim tovarlar" },
  { value: "Boshqa" },
];
