import { useState, useMemo, useCallback } from 'react';
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { Package, CreditCard } from 'lucide-react';
import { FiArrowLeft } from 'react-icons/fi';
import { useLanguage } from '@/context/LanguageContext';
import useSendOrder from '@/hooks/useSendOrder';
import { resetOrderStatus } from '@/store/slices/order/sendOrderSlice';
import { useSession } from '@/context/SessionContext';
import { formatUzPhone, isValidUzPhone } from '@/utils/phone';
import { validateCoupon } from '@/services/coupons/coupons';
import { resolveDeliveryTier } from '@/constants/deliveryTiers';
import { UZBEKISTAN_REGIONS } from '@/constants/uzbekistanRegions';
import CustomSelect from '@/components/ui/CustomSelect';
import StatusModal from '@/components/ui/StatusModal';
import LocationPickerModal from '@/components/ui/LocationPickerModal';

const CheckoutPage = () => {

  const { t } = useLanguage();
  const { sendOrder, loading, carts, success } = useSendOrder();
  const dispatch = useDispatch()
  const navigate = useNavigate();
  const { sellerId: currentSellerId, clientId: currentUserId, store, telegramUser } = useSession();

  // MUHIM: buyurtma formasidagi "F.I.Sh" maydoniga, Telegram'dan
  // kelgan HAQIQIY ism-familiya (`first_name`/`last_name`) BOSHLANG'ICH
  // qiymat sifatida qo'yiladi - Telegram USERNAME EMAS (masalan
  // "@alisher_dev" kabi taxallus ko'rsatilmaydi, "Alisher Davronov"
  // kabi haqiqiy ism ko'rsatiladi). Xaridor xohlasa, buni ERKIN
  // O'ZGARTIRISHI mumkin - bu shunchaki QULAY BOSHLANG'ICH holat,
  // majburiy qiymat emas (pastdagi input hamon oddiy, tahrirlanadigan
  // maydon).
  const defaultFullName = useMemo(
    () => [telegramUser?.firstName, telegramUser?.lastName].filter(Boolean).join(" "),
    [telegramUser]
  );

  const [formData, setFormData] = useState({
    fullName: defaultFullName,
    phone: '',
    address: '',
  });

  const [addressMode, setAddressMode] = useState('manual'); // 'manual' | 'map'
  const [mapLocation, setMapLocation] = useState(null); // { lat, lng }
  const [showMapPicker, setShowMapPicker] = useState(false);

  const [couponInput, setCouponInput] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState(null);
  const [couponError, setCouponError] = useState(null);
  const [applyingCoupon, setApplyingCoupon] = useState(false);

  // MUHIM, TO'LIQ QAYTA QURISH: OLDIN xaridor 5 ta QATTIQ BELGILANGAN
  // mintaqa ro'yxatidan birini QO'LDA tanlardi. Endi xaridor shunchaki
  // O'Z HUDUDINI (viloyatini) tanlaydi - tizim esa buni SOTUVCHINING
  // hududi bilan SOLISHTIRIB, qaysi narx bosqichi (Shahar/Tumanlar/
  // Boshqa viloyat) qo'llanilishini O'ZI hisoblab chiqadi
  // (`resolveDeliveryTier` - `constants/deliveryTiers.js`).
  const [customerRegion, setCustomerRegion] = useState('');

  const deliveryTier = useMemo(
    () => resolveDeliveryTier(store?.region, customerRegion),
    [store?.region, customerRegion]
  );

  const selectedTierInfo = deliveryTier ? store?.deliveryTiers?.[deliveryTier] : null;
  const hasDeliveryPricing = Boolean(selectedTierInfo && Number(selectedTierInfo.price) > 0);

  // OLDIN: xatolar faqat brauzerning alert() oynasi orqali ko'rsatilardi.
  // Endi har bir maydon o'zining aniq xatosini ko'rsatadi (mashhur
  // saytlardagi kabi) — bu foydalanuvchiga aynan qaysi maydon
  // to'ldirilmaganini ko'rsatadi, umumiy "hammasini to'ldiring" o'rniga.
  const [fieldErrors, setFieldErrors] = useState({});
  const [submitError, setSubmitError] = useState(null);

  const subtotal = useMemo(() => {
    return carts.reduce((sum, item) => sum + (item.price || 0) * (item.quantity || 0), 0);
  }, [carts]);

  const discountAmount = useMemo(() => {
    if (!appliedCoupon) return 0;
    if (appliedCoupon.discountType === "percent") {
      return Math.round((subtotal * appliedCoupon.discountValue) / 100);
    }
    return Math.min(appliedCoupon.discountValue, subtotal);
  }, [appliedCoupon, subtotal]);

  const amountAfterDiscount = Math.max(0, subtotal - discountAmount);

  // Eslatma: bu — faqat KO'RSATISH uchun taxmin. Haqiqiy yetkazib
  // berish narxi HAR DOIM server tomonida (`createOrder` Cloud
  // Function) sotuvchining haqiqiy sozlamasidan qayta hisoblanadi —
  // xuddi narx va promokod kabi.
  const isFreeDeliveryPreview = Boolean(
    store?.freeDeliveryEnabled &&
    store?.freeDeliveryThreshold &&
    amountAfterDiscount >= Number(store.freeDeliveryThreshold)
  );
  const deliveryFeePreview = hasDeliveryPricing ? (isFreeDeliveryPreview ? 0 : Number(selectedTierInfo.price) || 0) : 0;

  const totalAmount = amountAfterDiscount + deliveryFeePreview;

  const handleApplyCoupon = useCallback(async () => {
    if (!couponInput.trim()) return;
    setApplyingCoupon(true);
    setCouponError(null);
    try {
      const result = await validateCoupon(currentSellerId, couponInput);
      if (result.valid) {
        setAppliedCoupon(result.coupon);
      } else {
        setAppliedCoupon(null);
        setCouponError(result.error);
      }
    } finally {
      setApplyingCoupon(false);
    }
  }, [couponInput, currentSellerId]);

  const handleRemoveCoupon = useCallback(() => {
    setAppliedCoupon(null);
    setCouponInput('');
    setCouponError(null);
  }, []);

  // OLDIN: bu yerda mijoz "Kuryerga naqd" yoki "Karta orqali"ni ERKIN
  // tanlardi — bu sotuvchining mahsulotda belgilagan to'lov turidan
  // MUSTAQIL, alohida tanlov edi. Endi to'lov turi FAQAT sotuvchi
  // tomonidan (mahsulot qo'shishda) belgilanadi — bu yerda faqat
  // savatdagi barcha mahsulotlar UMUMIY qo'llab-quvvatlaydigan
  // (kesishgan) turlar ko'rsatiladi, mijoz o'zgartira olmaydi.
  const allowedPaymentTypes = useMemo(() => {
    if (carts.length === 0) return [];
    const perItemTypes = carts.map((item) =>
      Array.isArray(item.paymentTypes) && item.paymentTypes.length > 0
        ? item.paymentTypes
        : (item.paymentType ? [item.paymentType] : ["prepay"])
    );
    return perItemTypes.reduce((acc, curr) => acc.filter((t) => curr.includes(t)));
  }, [carts]);

  const handleInputChange = useCallback((e) => {
    const { name, value } = e.target;

    if (name === 'phone') {
      setFormData(prev => ({ ...prev, phone: formatUzPhone(value) }));
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
    setFieldErrors(prev => (prev[name] ? { ...prev, [name]: null } : prev));
  }, []);

  const validate = useCallback(() => {
    const { fullName, phone, address } = formData;
    const errors = {};

    if (!fullName.trim()) errors.fullName = "F.I.Sh kiritilishi shart";
    if (!phone.trim()) errors.phone = "Telefon raqam kiritilishi shart";
    else if (!isValidUzPhone(phone)) errors.phone = "To'liq telefon raqam kiriting (9 ta raqam)";

    if (addressMode === 'manual') {
      if (!address.trim()) errors.address = "Yetkazib berish manzili kiritilishi shart";
    } else if (!mapLocation) {
      errors.address = "Xaritadan joylashuvni belgilang";
    }

    if (store?.region && !customerRegion) {
      errors.deliveryZone = t("checkout.regionRequiredError");
    }

    setFieldErrors(errors);
    return Object.keys(errors).length === 0;
  }, [formData, addressMode, mapLocation, store?.region, customerRegion, t]);

  const handlePlaceOrder = useCallback(async (e) => {
    e.preventDefault();
    if (!validate()) return;
    
    const { fullName, phone, address } = formData;
    
    try {
      await sendOrder(
        { 
          fullName: fullName.trim(), 
          phone: phone.trim(), 
          address: addressMode === 'manual' ? address.trim() : `Xaritadagi joylashuv: ${mapLocation.lat.toFixed(5)}, ${mapLocation.lng.toFixed(5)}`,
          location: addressMode === 'map' ? mapLocation : null,
          paymentTypes: allowedPaymentTypes,
          couponCode: appliedCoupon?.code || null,
          discountAmount,
          customerRegion: customerRegion || null,
        }, 
        carts,
        currentSellerId, 
        currentUserId
      );
      setTimeout(() => {
        navigate('/')
        dispatch(resetOrderStatus())
      }, 1300);
    } catch (error) {
      setSubmitError(error.message || "Buyurtma jo'natilmadi");
    }
  }, [formData, addressMode, mapLocation, allowedPaymentTypes, appliedCoupon, discountAmount, customerRegion, carts, sendOrder, navigate, validate, currentSellerId, currentUserId, dispatch]);

  return (
    // MUHIM TUZATISH: pastdagi "Umumiy qiymat + Buyurtmani yakunlash"
    // paneli OLDIN `position: fixed` bilan ekranga QOTIRILGAN edi -
    // shu sababli sahifa pastki qismiga sun'iy, katta bo'sh joy
    // (`pb-52` + mahsulotlar bloki ostidagi `mb-[190px]`) qo'shishga
    // to'g'ri kelgan edi, klaviatura ochilganda esa uni alohida
    // yashirish (`useKeyboardVisible` + `translate-y`) kerak bo'lgan
    // edi. Foydalanuvchi so'rovi bo'yicha bu "position" xususiyati
    // OLIB TASHLANDI - panel endi sahifa oddiy oqimining (normal
    // document flow) bir qismi, boshqa kartochkalar kabi -
    // shuning uchun sun'iy bo'sh joy va klaviatura-yashirish mantiqi
    // ham endi kerak emas.
    <div className="min-h-screen bg-[#f8fafc] dark:bg-slate-950 pb-36 pt-4 select-none transition-colors duration-300">
      <div className="max-w-md mx-auto px-4 mb-6">
        <button
          type="button"
          onClick={() => navigate(-1)}
          className="w-9 h-9 rounded-full bg-white dark:bg-slate-900 border border-gray-100 dark:border-slate-800 shadow-sm flex items-center justify-center mb-3 active:scale-95 transition-transform"
        >
          <FiArrowLeft size={16} className="text-gray-600 dark:text-slate-300" />
        </button>
        <h1 className="text-2xl font-bold text-[#1e293b] dark:text-white">{t("checkout.title")}</h1>
        <p className="text-xs text-gray-400 dark:text-slate-500 mt-1">{t("checkout.subtitle")}</p>
      </div>

      <div className="max-w-md mx-auto px-4 space-y-6">
        
        <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl shadow-sm border border-gray-100/80 dark:border-slate-800">
          <h2 className="text-sm font-bold text-gray-400 dark:text-slate-500 uppercase tracking-wider mb-4">{t("checkout.deliverySection")}</h2>
          
          <form onSubmit={handlePlaceOrder} noValidate className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-gray-500 dark:text-slate-400 mb-1.5 pl-1">{t("checkout.fullName")}</label>
              <input 
                type="text" 
                name="fullName"
                value={formData.fullName}
                onChange={handleInputChange}
                placeholder={t("checkout.fullNamePlaceholder")} 
                className={`w-full px-4 py-3.5 rounded-2xl bg-[#f8fafc] dark:bg-slate-800 border outline-none focus:bg-white dark:focus:bg-slate-800 transition-all text-sm text-gray-800 dark:text-white placeholder-gray-400 dark:placeholder-slate-500 font-medium ${fieldErrors.fullName ? 'border-rose-400 focus:border-rose-500' : 'border-gray-100 dark:border-slate-700 focus:border-blue-500'}`}
              />
              {fieldErrors.fullName && <p className="text-[11px] text-rose-500 font-semibold mt-1 pl-1">{fieldErrors.fullName}</p>}
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-500 dark:text-slate-400 mb-1.5 pl-1">{t("checkout.phone")}</label>
              <input 
                type="tel" 
                inputMode="numeric"
                name="phone"
                value={formData.phone}
                onFocus={() => { if (!formData.phone) setFormData(prev => ({ ...prev, phone: '+998 ' })); }}
                onChange={handleInputChange}
                placeholder={t("checkout.phonePlaceholder")} 
                maxLength={17}
                className={`w-full px-4 py-3.5 rounded-2xl bg-[#f8fafc] dark:bg-slate-800 border outline-none focus:bg-white dark:focus:bg-slate-800 transition-all text-sm text-gray-800 dark:text-white placeholder-gray-400 dark:placeholder-slate-500 font-medium ${fieldErrors.phone ? 'border-rose-400 focus:border-rose-500' : 'border-gray-100 dark:border-slate-700 focus:border-blue-500'}`}
              />
              {fieldErrors.phone && <p className="text-[11px] text-rose-500 font-semibold mt-1 pl-1">{fieldErrors.phone}</p>}
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5 pl-1">
                <label className="block text-xs font-semibold text-gray-500 dark:text-slate-400">{t("checkout.address")}</label>
                <div className="flex items-center gap-1 bg-[#f8fafc] dark:bg-slate-800 rounded-full p-0.5">
                  <button
                    type="button"
                    onClick={() => setAddressMode('manual')}
                    className={`px-2.5 py-1 rounded-full text-[10px] font-bold transition-all ${addressMode === 'manual' ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-sm' : 'text-gray-400 dark:text-slate-500'}`}
                  >
                    {t("checkout.addressManual")}
                  </button>
                  <button
                    type="button"
                    onClick={() => setAddressMode('map')}
                    className={`px-2.5 py-1 rounded-full text-[10px] font-bold transition-all ${addressMode === 'map' ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-sm' : 'text-gray-400 dark:text-slate-500'}`}
                  >
                    {t("checkout.addressMap")}
                  </button>
                </div>
              </div>

              {addressMode === 'manual' ? (
                <textarea 
                  name="address"
                  rows="3"
                  value={formData.address}
                  onChange={handleInputChange}
                  placeholder={t("checkout.addressPlaceholder")} 
                  className={`w-full px-4 py-3.5 rounded-2xl bg-[#f8fafc] dark:bg-slate-800 border outline-none focus:bg-white dark:focus:bg-slate-800 transition-all text-sm text-gray-800 dark:text-white placeholder-gray-400 dark:placeholder-slate-500 resize-none font-medium ${fieldErrors.address ? 'border-rose-400 focus:border-rose-500' : 'border-gray-100 dark:border-slate-700 focus:border-blue-500'}`}
                ></textarea>
              ) : (
                <button
                  type="button"
                  onClick={() => setShowMapPicker(true)}
                  className={`w-full px-4 py-3.5 rounded-2xl bg-[#f8fafc] dark:bg-slate-800 border text-left transition-all ${fieldErrors.address ? 'border-rose-400' : 'border-gray-100 dark:border-slate-700'}`}
                >
                  {mapLocation ? (
                    <span className="text-sm font-semibold text-gray-800 dark:text-white">
                      {t("checkout.locationSet")} ({mapLocation.lat.toFixed(4)}, {mapLocation.lng.toFixed(4)})
                    </span>
                  ) : (
                    <span className="text-sm text-gray-400 dark:text-slate-500">{t("checkout.mapPick")}</span>
                  )}
                </button>
              )}
              {fieldErrors.address && <p className="text-[11px] text-rose-500 font-semibold mt-1 pl-1">{fieldErrors.address}</p>}
            </div>

            <div className="pt-2">
              <label className="block text-xs font-semibold text-gray-500 dark:text-slate-400 mb-2 pl-1">{t("checkout.paymentType")}</label>
              {/* OLDIN: bu yerda mijoz erkin radio tugma orqali tanlardi.
                  Endi — faqat ma'lumot: sotuvchi qaysi turlarni yoqqan
                  bo'lsa, o'shalar ko'rsatiladi. Mijoz o'zgartira olmaydi. */}
              <div className="flex flex-wrap gap-2">
                {allowedPaymentTypes.length === 0 ? (
                  <span className="text-xs text-gray-400 dark:text-slate-500">{t("checkout.cartEmpty")}</span>
                ) : (
                  allowedPaymentTypes.map((type) => (
                    <div
                      key={type}
                      className="flex items-center gap-2 px-4 py-3 rounded-2xl border border-blue-100 dark:border-blue-500/20 bg-blue-50/50 dark:bg-blue-500/10"
                    >
                      {type === "cod" ? <Package size={16} className="text-blue-600 dark:text-blue-300" /> : <CreditCard size={16} className="text-blue-600 dark:text-blue-300" />}
                      <span className="text-sm font-semibold text-blue-700 dark:text-blue-300">
                        {type === "cod" ? t("checkout.paymentCod") : t("productDetail.prepay")}
                      </span>
                    </div>
                  ))
                )}
              </div>
            </div>

            <div className="pt-2">
              <label className="block text-xs font-semibold text-gray-500 dark:text-slate-400 mb-2 pl-1">{t("checkout.promoCode")}</label>
              {appliedCoupon ? (
                <div className="flex items-center justify-between px-4 py-3 rounded-2xl border border-emerald-200 dark:border-emerald-500/30 bg-emerald-50 dark:bg-emerald-500/10">
                  <div>
                    <p className="text-sm font-black text-emerald-700 dark:text-emerald-400">{appliedCoupon.code}</p>
                    <p className="text-[11px] text-emerald-600 dark:text-emerald-400">
                      -{discountAmount.toLocaleString()} so'm {t("checkout.couponDiscountApplied")}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={handleRemoveCoupon}
                    className="text-xs font-bold text-rose-500"
                  >
                    {t("common.cancel")}
                  </button>
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={couponInput}
                    onChange={(e) => { setCouponInput(e.target.value.toUpperCase()); setCouponError(null); }}
                    placeholder={t("checkout.promoPlaceholder")}
                    className="flex-1 h-11 px-4 rounded-2xl bg-[#f8fafc] dark:bg-slate-800 border border-gray-100 dark:border-slate-700 text-sm font-bold text-gray-800 dark:text-white placeholder-gray-400 dark:placeholder-slate-500 uppercase tracking-wider focus:outline-none focus:border-blue-500"
                  />
                  <button
                    type="button"
                    disabled={applyingCoupon || !couponInput.trim()}
                    onClick={handleApplyCoupon}
                    className="h-11 px-5 bg-slate-800 dark:bg-slate-700 text-white text-xs font-bold rounded-2xl disabled:opacity-50"
                  >
                    {applyingCoupon ? "..." : t("checkout.couponApply")}
                  </button>
                </div>
              )}
              {couponError && <p className="text-[11px] text-rose-500 font-semibold mt-1 pl-1">{couponError}</p>}
            </div>

            {store?.region && (
              <div className="pt-2">
                <label className="block text-xs font-semibold text-gray-500 dark:text-slate-400 mb-2 pl-1">{t("checkout.customerRegionLabel")}</label>
                <CustomSelect
                  value={customerRegion}
                  onChange={setCustomerRegion}
                  options={UZBEKISTAN_REGIONS}
                  placeholder={t("checkout.customerRegionPlaceholder")}
                  error={Boolean(fieldErrors.deliveryZone)}
                />
                {fieldErrors.deliveryZone && <p className="text-[11px] text-rose-500 font-semibold mt-1 pl-1">{fieldErrors.deliveryZone}</p>}

                {customerRegion && (
                  <div className={`mt-2 flex items-center justify-between p-3.5 rounded-2xl border ${
                    hasDeliveryPricing ? 'border-blue-500 bg-blue-50/30 dark:bg-blue-500/10' : 'border-amber-200 bg-amber-50/50 dark:bg-amber-500/10'
                  }`}>
                    {hasDeliveryPricing ? (
                      <>
                        <div>
                          <p className="text-xs font-bold text-gray-800 dark:text-white">{t(`logistics.tier_${deliveryTier}_label`)}</p>
                          {selectedTierInfo?.days && <p className="text-[10px] text-gray-400 dark:text-slate-500">{t(`deliveryZones.${selectedTierInfo.days}`)}</p>}
                        </div>
                        <span className={`text-xs font-black ${isFreeDeliveryPreview ? "text-emerald-600 dark:text-emerald-400" : "text-gray-700 dark:text-slate-200"}`}>
                          {isFreeDeliveryPreview ? t("checkout.free") : `${Number(selectedTierInfo.price).toLocaleString()} so'm`}
                        </span>
                      </>
                    ) : (
                      <p className="text-[11px] text-amber-700 dark:text-amber-400 font-semibold">{t("checkout.noDeliveryPricingSet")}</p>
                    )}
                  </div>
                )}
              </div>
            )}
          </form>
        </div>

        <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl shadow-sm border border-gray-100/80 dark:border-slate-800">
          <h2 className="text-sm font-bold text-gray-400 dark:text-slate-500 uppercase tracking-wider mb-3">{t("checkout.productsSection")}</h2>
          
          <div className="divide-y divide-gray-50 dark:divide-slate-800 max-h-[240px] overflow-y-auto pr-1">
            {carts.map((item) => (
              <div key={item.id} className="flex items-center gap-3 py-3 first:pt-0 last:pb-0">
                <img 
                  src={item.image} 
                  alt={item.name} 
                  className="w-12 h-12 object-cover rounded-xl bg-[#f8fafc] dark:bg-slate-800"
                />
                <div className="flex-1">
                  <h3 className="font-bold text-gray-800 dark:text-white text-xs line-clamp-1">{item.name}</h3>
                  <p className="text-[10px] text-gray-400 dark:text-slate-500 mt-0.5">{t("checkout.quantitySuffix")} {item.quantity} ta</p>
                </div>
                <span className="font-bold text-blue-600 dark:text-blue-400 text-sm">
                  {(item.price * item.quantity).toLocaleString()} so'm
                </span>
              </div>
            ))}
          </div>

          <div className="border-t border-gray-100 dark:border-slate-800 mt-4 pt-3 space-y-2">
            <div className="flex justify-between text-xs text-gray-400 dark:text-slate-500">
              <span>{t("checkout.productsTotal")}</span>
              <span className="font-medium text-gray-700 dark:text-slate-300">{subtotal.toLocaleString()} so'm</span>
            </div>
            {appliedCoupon && (
              <div className="flex justify-between text-xs text-gray-400 dark:text-slate-500">
                <span>{t("checkout.promoLabel")} ({appliedCoupon.code})</span>
                <span className="text-emerald-600 dark:text-emerald-400 font-bold">-{discountAmount.toLocaleString()} so'm</span>
              </div>
            )}
            <div className="flex justify-between text-xs text-gray-400 dark:text-slate-500">
              <span>{t("checkout.deliveryLabel")}</span>
              {/* MUHIM, TOPILGAN VA TUZATILGAN JIDDIY XATO: bu yerda
                  OLDIN `selectedZone` degan, ESKI (endi mavjud
                  bo'lmagan) o'zgaruvchi ishlatilgan edi - hudud
                  tizimi `deliveryTiers`ga qayta qurilganda, bu BITTA
                  joy tasodifan YANGILANMAY qolib ketgan edi. Natijada
                  `ReferenceError: selectedZone is not defined` -
                  Checkout sahifasi savatda MAHSULOT BO'LGAN har qanday
                  holatda, RENDER paytida DARHOL qulab tushardi (Error
                  Boundary'ning umumiy "Kutilmagan xatolik" ekranini
                  ko'rsatardi). Endi to'g'ri, MAVJUD o'zgaruvchilar
                  (`hasDeliveryPricing`/`selectedTierInfo`) ishlatiladi. */}
              {!customerRegion || !hasDeliveryPricing ? (
                <span className="text-gray-400 dark:text-slate-500">{t("checkout.zoneNotSelected")}</span>
              ) : isFreeDeliveryPreview ? (
                <span className="text-blue-500 dark:text-blue-400 font-bold">{t("checkout.free")}</span>
              ) : (
                <span className="font-medium text-gray-700 dark:text-slate-300">{deliveryFeePreview.toLocaleString()} so'm</span>
              )}
            </div>
          </div>
        </div>

        {/* MUHIM: bu panel endi ODDIY sahifa oqimining bir qismi
            (avvalgi `position: fixed` OLIB TASHLANDI) - shuning uchun
            yuqoridagi kartochkalar bilan bir xil `space-y-6`
            oralig'idan foydalanadi, alohida `max-w`/`px` berish
            shart emas. */}
        <div className="bg-white/95 dark:bg-slate-900/95 border border-gray-100 dark:border-slate-800 rounded-[24px] px-4 py-3 shadow-lg flex items-center justify-between gap-4">
          <div>
            <p className="text-[10px] text-gray-400 dark:text-slate-500 font-medium uppercase tracking-wider">{t("checkout.totalValue")}</p>
            <p className="text-2xl font-black text-blue-600 dark:text-blue-400">{totalAmount.toLocaleString()} so'm</p>
          </div>

          <button
            type="button"
            onClick={handlePlaceOrder}
            disabled={loading || carts.length === 0}
            className="flex-1 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold py-4 px-6 rounded-2xl text-center text-sm shadow-md shadow-blue-600/20 active:scale-[0.98] transition-all disabled:from-gray-300 disabled:to-gray-400 disabled:shadow-none cursor-pointer"
          >
            {loading ? t("checkout.placingOrder") : t("checkout.placeOrder")}
          </button>
        </div>

      </div>

      {showMapPicker && (
        <LocationPickerModal
          initialLocation={mapLocation}
          onConfirm={(loc) => { setMapLocation(loc); setShowMapPicker(false); setFieldErrors((prev) => ({ ...prev, address: null })); }}
          onClose={() => setShowMapPicker(false)}
        />
      )}

      {success && (
        <StatusModal
          variant="success"
          title="Buyurmangiz muvaffaqiyatli amalga oshdi!"
          message="Tez orada siz bilan bog'lanamiz."
          onClose={() => { navigate('/'); dispatch(resetOrderStatus()); }}
        />
      )}

      {submitError && (
        <StatusModal
          variant="error"
          title="Xatolik yuz berdi"
          message={submitError}
          onClose={() => setSubmitError(null)}
        />
      )}
    </div>
  );

};

export default CheckoutPage;
