import { useState } from 'react'
import { Outlet, Navigate } from 'react-router-dom'
import SellerNavbar from './SellerNavbar'
import PinLockScreen from '@/components/ui/PinLockScreen'
import { useSession } from '@/context/SessionContext'

// OLDIN: PIN kod sozlamasi (Maxfiylik va Xavfsizlik) faqat saqlanardi,
// lekin hech qayerda HAQIQATAN talab qilinmasdi. Endi, agar sotuvchi
// buni yoqqan bo'lsa, butun sotuvchi paneli shu qulf ortida —
// sessiya davomida (sessionStorage) bir marta to'g'ri kod kiritilgach,
// qayta so'ralmaydi.
//
// KEYINGI TUZATISH: OLDIN, bu komponent PIN holatini `sellers/{id}/
// private/security`dan O'ZI, ALOHIDA `getDoc()` so'rovi orqali
// yuklardi — bu, Dashboard render bo'lishidan OLDIN kutilishi kerak
// bo'lgan, diagnostikada aniqlanmagan UCHINCHI Firestore so'rovi edi
// (aynan shu "ikkinchi loader" sifatida ko'rinar edi). Endi bu
// ma'lumot `verifyTelegramAuth` javobining o'zida (server tomonida)
// allaqachon keladi — SessionContext orqali, qo'shimcha so'rovsiz.
//
// MUHIM TUZATISH (rol himoyasi): oldin bu yerda faqat PIN
// tekshirilardi — hatto ODDIY MIJOZ (masalan sotuvchining referal
// havolasi orqali kirgan xaridor) ham qo'lda `/seller/...` manziliga
// o'tsa, sotuvchi panelining UI QOBIG'INI ko'ra olardi (Firestore
// qoidalari haqiqiy ma'lumotni bloklaydi, lekin natija — chalkash,
// "bo'sh"/xato ko'rinishdagi sahifa bo'lardi, toza yo'naltirish
// o'rniga). Endi `isSeller`/`isAdmin` BO'LMAGAN har qanday
// foydalanuvchi butun sotuvchi bo'limidan bosh sahifaga qaytariladi.
const SellerLayout = () => {
  const { security, isSeller, isAdmin } = useSession();
  const [unlocked, setUnlocked] = useState(
    () => sessionStorage.getItem("zeloshop_pin_unlocked") === "true"
  );

  if (!isSeller && !isAdmin) {
    return <Navigate to="/" replace />;
  }

  const isLocked = Boolean(security?.pinLockEnabled) && security?.pinCode && !unlocked;

  if (isLocked) {
    return <PinLockScreen correctPin={security.pinCode} onUnlock={() => setUnlocked(true)} />;
  }

  return (
    <div className='w-full h-full seller-layout'>
      <main>
        <Outlet/>
      </main>
      <SellerNavbar/>
    </div>
  )
}

export default SellerLayout