/**
 * Foiz asosida chegirma narxini hisoblaydi (masalan "-20%" tugmasi
 * bosilganda). SOF FUNKSIYA - `CreatePromotionPage.jsx`dan
 * ajratilgan, to'g'ridan-to'g'ri test qilinadi.
 */
export function calculateDiscountFromPercent(originalPrice, percent) {
  const price = Number(originalPrice) || 0;
  return Math.round(price * (1 - percent / 100));
}

/**
 * Kiritilgan chegirma narxi HAQIQATAN amal qiladigan (asl narxdan
 * kichik, musbat) ekanini tekshiradi.
 */
export function isValidDiscountPrice(discountPrice, originalPrice) {
  const discount = Number(discountPrice);
  const original = Number(originalPrice) || 0;
  if (!discountPrice || Number.isNaN(discount) || discount <= 0) return false;
  return discount < original;
}
