/**
 * "Smart Calculator" — narx, tannarx va chegirma asosida sof foyda
 * va rentabellikni hisoblaydi. SOF funksiya — React'ga bog'liq emas,
 * to'g'ridan-to'g'ri sinov (test) faylida tekshiriladi.
 *
 * @param {string|number} price - sotish narxi
 * @param {string|number} costPrice - tannarx
 * @param {string|number} discountPrice - chegirma narxi (ixtiyoriy, "" bo'lishi mumkin)
 */
export function computeProfitMetrics(price, costPrice, discountPrice) {
  const priceNum = Number(price);
  const costNum = Number(costPrice);
  const discountNum = Number(discountPrice);

  // Bo'sh qatorni ("") haqiqiy 0 dan ajratamiz — aks holda narx "0"
  // kiritilganda hisoblash noto'g'ri (yo'q deb) ishlaydi.
  const valid = price !== "" && costPrice !== "" && !Number.isNaN(priceNum) && !Number.isNaN(costNum);

  if (!valid) {
    return { profit: 0, marginPercentage: 0, hasValues: false, effectivePrice: 0 };
  }

  // Agar chegirma narxi kiritilgan bo'lsa, foyda HAQIQIY (chegirmali)
  // narxdan hisoblanadi — chunki xaridor aslida shuni to'laydi.
  const sellingPrice = discountPrice !== "" && !Number.isNaN(discountNum) && discountNum > 0
    ? discountNum
    : priceNum;

  const profit = sellingPrice - costNum;
  const marginPercentage = sellingPrice !== 0 ? Math.round((profit / sellingPrice) * 100) : 0;

  return { profit, marginPercentage, hasValues: true, effectivePrice: sellingPrice };
}
