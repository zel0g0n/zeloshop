import { describe, test, expect } from "vitest";
import { computeProfitMetrics } from "./productPricing";

describe("computeProfitMetrics", () => {
  test("narx yoki tannarx kiritilmagan bo'lsa, hasValues=false qaytaradi", () => {
    expect(computeProfitMetrics("", "", "")).toEqual({ profit: 0, marginPercentage: 0, hasValues: false, effectivePrice: 0 });
    expect(computeProfitMetrics(100, "", "")).toEqual({ profit: 0, marginPercentage: 0, hasValues: false, effectivePrice: 0 });
  });

  test("tannarx \"0\" bo'lsa ham (bo'sh qator emas), to'g'ri hisoblaydi — falsy xatosi yo'q", () => {
    const result = computeProfitMetrics(50000, 0, "");
    expect(result.hasValues).toBe(true);
    expect(result.profit).toBe(50000);
  });

  test("chegirma bo'lmasa, oddiy narxdan foyda hisoblaydi", () => {
    const result = computeProfitMetrics(50000, 30000, "");
    expect(result.profit).toBe(20000);
    expect(result.marginPercentage).toBe(40); // 20000/50000 * 100
    expect(result.effectivePrice).toBe(50000);
  });

  test("chegirma kiritilgan bo'lsa, foyda CHEGIRMALI narxdan hisoblanadi (haqiqiy to'lov)", () => {
    const result = computeProfitMetrics(50000, 30000, 35000);
    expect(result.profit).toBe(5000); // 35000 - 30000
    expect(result.effectivePrice).toBe(35000);
  });

  test("chegirma narxi 0 yoki bo'sh bo'lsa, e'tiborga olinmaydi", () => {
    const result = computeProfitMetrics(50000, 30000, 0);
    expect(result.effectivePrice).toBe(50000);
  });

  test("manfiy foyda (zarar) to'g'ri hisoblanadi va belgilanadi", () => {
    const result = computeProfitMetrics(20000, 30000, "");
    expect(result.profit).toBe(-10000);
    expect(result.marginPercentage).toBe(-50);
  });
});
