/**
 * Buyurtmalarni status va qidiruv so'rovi bo'yicha filtrlaydi. SOF
 * funksiya — React'ga bog'liq emas, to'g'ridan-to'g'ri sinov (test)
 * faylida tekshiriladi.
 */
export function filterOrders(orders, { activeTab, searchQuery = "" }) {
  const query = searchQuery.trim().toLowerCase();
  return orders.filter((order) => {
    const matchesTab = order.status === activeTab;
    if (!query) return matchesTab;
    const idMatch = String(order.id || "").toLowerCase().includes(query);
    const nameMatch = (order.customer?.fullName || "").toLowerCase().includes(query);
    const phoneMatch = (order.customer?.phone || "").toLowerCase().includes(query);
    return matchesTab && (idMatch || nameMatch || phoneMatch);
  });
}

/**
 * Har bir buyurtmaga tushunarli, tartib raqamini beradi (#1, #2, ...)
 * — Firestore hujjat ID'si o'rniga.
 *
 * MUHIM, YAKUNIY TUZATISH: OLDIN bu funksiya raqamni FAQAT yuklab
 * olingan `orders` massivi ICHIDAGI o'rin asosida hisoblardi - bu,
 * 150 talik yuklash chegarasidan (`useFilterOrders.jsx`) OSHGAN
 * do'konlar uchun HAQIQIY tartib raqamini bermas edi (masalan 200-
 * buyurtma ham "#50" bo'lib ko'rinishi mumkin edi, chunki faqat
 * so'nggi 150 tasi yuklangan). Endi - `orders.js`dagi HAQIQIY,
 * DOIMIY hisoblagichdan kelgan `order.orderNumber` ustunlik qiladi
 * (mavjud bo'lsa) - faqat SHU TUZATISHDAN OLDIN yaratilgan (eski,
 * bu maydonga ega bo'lmagan) buyurtmalar uchun eskicha, massiv-
 * o'rniga-asoslangan usul ZAXIRA sifatida ishlatiladi.
 */
export function computeOrderNumbers(orders) {
  const sorted = [...orders].sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
  const map = new Map();
  sorted.forEach((o, index) => map.set(o.id, o.orderNumber ?? (index + 1)));
  return map;
}

/** Yetkazilgan buyurtmalarning umumiy summasini hisoblaydi. */
export function computeDeliveredRevenue(orders) {
  return orders
    .filter((o) => o.status === "delivered")
    .reduce((sum, o) => sum + (Number(o.totalAmount) || 0), 0);
}

/** Hali yakunlanmagan (yetkazilmagan va bekor qilinmagan) buyurtmalar sonini hisoblaydi. */
export function computeActiveOrdersCount(orders) {
  return orders.filter((o) => !["delivered", "cancel"].includes(o.status)).length;
}
