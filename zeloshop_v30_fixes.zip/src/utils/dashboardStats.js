/**
 * Dashboard uchun KPI statistikasini hisoblaydi. Bu — SOF funksiya
 * (React'ga, DOM'ga yoki joriy vaqtga bog'liq emas).
 *
 * MUHIM, ARXITEKTURA O'ZGARISHI (real production darajasiga
 * chiqarish, "kengayishni hisobga olgan holda"): OLDIN bu funksiya
 * XOM buyurtmalar RO'YXATINI qabul qilib, HAR SAFAR ularni o'zi
 * filtrlab/yig'ardi - bu, buyurtmalar soni o'sgan sari (Firestore
 * o'qish xarajati VA hisoblash vaqti) sekinlashadigan yondashuv edi.
 * Endi bu funksiya, server tomonida OLDINDAN hisoblangan KUNLIK
 * yig'ma yozuvlarni (`useOrderRollups`, batafsil izoh:
 * `functions/orderRollups.js`) qabul qiladi - kirish hajmi endi
 * BUYURTMALAR soniga emas, DAVR ICHIDAGI KUNLAR soniga bog'liq
 * (eng ko'pi - "Yil" uchun ~365 ta kichik hujjat), buyurtmalar soni
 * necha o'n minglab bo'lishidan QAT'I NAZAR.
 *
 * MUHIM: "kutilayotgan buyurtmalar" (`pendingCount`) — bu HOZIRGI
 * HOLAT ko'rsatkichi (davr bo'yicha emas), kunlik yig'ma yozuvlarga
 * mos kelmaydi - shuning uchun bu funksiya ENDI uni qaytarmaydi;
 * buning o'rniga alohida, engil `usePendingOrdersCount` hook'i
 * (Firestore `count()` agregatsiyasi) ishlatiladi.
 *
 * @param {Array<{dateMs:number, revenue:number, cogs:number, deliveredCount:number, ordersCreatedCount:number}>} days
 * @param {Array} products - sotuvchining barcha mahsulotlari.
 * @param {number} rangeStart - joriy davr boshlanishi (ms).
 * @param {number} prevRangeStart - oldingi (solishtirish uchun) davr boshlanishi (ms).
 */
export function computeDashboardStatsFromRollups(days, products, rangeStart, prevRangeStart) {
  const list = Array.isArray(days) ? days : [];
  const current = list.filter((d) => d.dateMs >= rangeStart);
  const previous = list.filter((d) => d.dateMs >= prevRangeStart && d.dateMs < rangeStart);

  const sum = (rows, key) => rows.reduce((s, d) => s + (Number(d[key]) || 0), 0);

  const totalSales = sum(current, "revenue");
  const previousSales = sum(previous, "revenue");
  const growthPercent = previousSales > 0 ? Math.round(((totalSales - previousSales) / previousSales) * 100) : null;

  const totalCost = sum(current, "cogs");
  const netProfit = totalSales - totalCost;
  const profitMargin = totalSales > 0 ? Math.round((netProfit / totalSales) * 100) : 0;

  const deliveredCount = sum(current, "deliveredCount");
  // "ordersCount" - BARCHA holatdagi buyurtmalarni sanaydi (bu
  // daromad emas, faoliyat ko'rsatkichi - Buyurtmalar analitikasidagi
  // "jami buyurtmalar"ga mos kelishi kerak).
  const ordersCount = sum(current, "ordersCreatedCount");

  // HALOL YONDASHUV: "Konversiya" (tashrif->buyurtma nisbati) uchun
  // sahifa tashriflarini kuzatuvchi tizim kerak (alohida, server
  // tomonidagi `visits` kolleksiyasi - `Dashboard.jsx`da ishlatiladi).
  // Bu yerda esa HAQIQIY hisoblanadigan ko'rsatkich - o'rtacha chek.
  const averageOrderValue = deliveredCount > 0 ? Math.round(totalSales / deliveredCount) : 0;

  const lowStockCount = products.filter((p) => Number(p.stock) <= 3).length;
  const activeProductsCount = products.filter((p) => p.isActive ?? true).length;

  return {
    totalSales,
    growthPercent,
    netProfit,
    profitMargin,
    ordersCount,
    deliveredCount,
    activeProductsCount,
    lowStockCount,
    averageOrderValue,
  };
}
