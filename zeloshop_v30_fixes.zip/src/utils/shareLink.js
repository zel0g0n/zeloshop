import { BOT_USERNAME, APP_SHORT_NAME } from "@/config/telegram";
import { encodeDeepLinkPath } from "@/utils/deepLink";

/**
 * MUHIM, JIDDIY TUZATISH (haqiqiy, production'ni butunlay to'xtatib
 * qo'ygan xato): OLDIN, agar sotuvchi o'z shaxsiy botini ulagan
 * bo'lsa (`customBotUsername`), BARCHA ulashiladigan havolalar
 * (do'kon havolasi, referal havolasi, mahsulot havolalari) O'SHA
 * bot orqali quriladigan edi: `t.me/{customBot}/shop?startapp=...`.
 *
 * BU — ISHLAMAYDI, chunki `t.me/{bot}/{app}?startapp=` formatida
 * ishlashi uchun, HAR BIR BOT'DA (nafaqat platformaning o'z botida)
 * BotFather orqali `/newapp` buyrug'i bilan ALOHIDA ro'yxatdan
 * o'tkazilgan Mini App (aynan "shop" qisqa nomi bilan) BO'LISHI
 * SHART. Bu — DASTURIY YO'L BILAN (Bot API orqali) SOZLAB
 * BO'LMAYDIGAN, faqat bot egasi tomonidan BotFather'da QO'LDA
 * bajariladigan amal - va sotuvchining shaxsiy botini ulash oqimi
 * (`connectCustomBot`) buni sotuvchidan HECH QACHON so'ramagan
 * (va so'rashi ham unchalik amaliy emas). Natijada: sotuvchining
 * shaxsiy boti uchun "/shop" yo'li UMUMAN MAVJUD EMAS - Telegram
 * "bot not found" beradi.
 *
 * TO'G'RI YECHIM: ulashiladigan (startapp'ga tayanadigan) HAVOLALAR
 * har doim FAQAT PLATFORMANING O'Z BOTI orqali quriladi (u yerda
 * "shop" Mini App'i HAQIQATAN ro'yxatdan o'tkazilgan) -
 * `customBotUsername` BU YERDA ENDI ISHLATILMAYDI. Sotuvchining
 * shaxsiy boti hamon FOYDALI - lekin FAQAT "Menyu" tugmasi orqali
 * (`setChatMenuButton` - bu, ro'yxatdan o'tgan Mini App'ga EMAS,
 * to'g'ridan-to'g'ri URL'ga ishora qiladi, shuning uchun HAR QANDAY
 * botda ishlaydi) - bu, xaridor ALLAQACHON o'sha bot bilan suhbat
 * ochgan holatlar uchun to'g'ri, lekin ULASHISH (hali suhbat
 * ochmagan odamga havola yuborish) uchun EMAS.
 */
export const buildShopLink = (sellerId) => {
  if (!sellerId) return "";
  return `https://t.me/${BOT_USERNAME}/${APP_SHORT_NAME}?startapp=${sellerId}`;
};

/**
 * Mijozning SHAXSIY "do'st taklif qilish" havolasini yasaydi.
 *
 * FORMAT: `buildShopLink`ning kengaytmasi - `startapp` qiymati
 * "{sellerId}_r{clientId}" ko'rinishida. Bu, `functions/lib/helpers.js`
 * dagi `parseStartParam()` bilan MOS bo'lishi SHART - ikkalasi ham
 * "_r" ajratkichini ishlatadi. sellerId va clientId - ikkalasi ham
 * Telegram foydalanuvchi ID'lari (faqat raqamlar), shuning uchun bu
 * ajratkich ular bilan hech qachon to'qnashmaydi.
 */
export const buildReferralLink = (sellerId, clientId) => {
  if (!sellerId || !clientId) return "";
  return `https://t.me/${BOT_USERNAME}/${APP_SHORT_NAME}?startapp=${sellerId}_r${clientId}`;
};

/**
 * Do'kon ICHIDAGI ma'lum bir sahifaga (masalan bitta kategoriya)
 * to'g'ridan-to'g'ri ochiladigan havola yasaydi - CRM broadcast
 * xabarlari va bosh sahifa bannerlarida ishlatish uchun.
 *
 * FORMAT: `buildShopLink`ning kengaytmasi - `startapp` qiymati
 * "{sellerId}_p{base64url-kodlangan-yol}" ko'rinishida.
 */
export const buildDeepLink = (sellerId, path) => {
  if (!sellerId || !path) return "";
  return `https://t.me/${BOT_USERNAME}/${APP_SHORT_NAME}?startapp=${sellerId}_p${encodeDeepLinkPath(path)}`;
};
