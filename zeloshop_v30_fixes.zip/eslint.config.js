import js from '@eslint/js'
import globals from 'globals'
import reactHooks from 'eslint-plugin-react-hooks'
import reactRefresh from 'eslint-plugin-react-refresh'
import { defineConfig, globalIgnores } from 'eslint/config'

export default defineConfig([
  globalIgnores(['dist']),
  {
    files: ['**/*.{js,jsx}'],
    // MUHIM: `functions/` endi pastdagi ALOHIDA blokda tekshiriladi
    // (Node.js/Jest globallari bilan) - shuning uchun bu yerda
    // chiqarib tashlangan, aks holda ikkala blok ham unga ustma-ust
    // tegib, chalkash natija berardi.
    ignores: ['functions/**'],
    extends: [
      js.configs.recommended,
      reactHooks.configs.flat.recommended,
      reactRefresh.configs.vite,
    ],
    languageOptions: {
      globals: globals.browser,
      parserOptions: { ecmaFeatures: { jsx: true } },
    },
  },
  // MUHIM, YANGI QO'SHILDI: `functions/` - Node.js/Cloud Functions
  // BACKEND kodi, React EMAS. Yuqoridagi (frontend) bloк faqat
  // `globals.browser`dan foydalanardi - unda `require`/`module`/
  // `exports`/`process`/`__dirname` kabi Node.js global
  // o'zgaruvchilari, shuningdek `jest`/`expect`/`describe` kabi Jest
  // globallari UMUMAN YO'Q edi. Natijada `functions/`dagi DEYARLI
  // HAR BIR FAYLDA bu so'zlarning HAR BIR ishlatilishi "no-undef"
  // xatosi sifatida hisoblanardi (~1350+ soxta xato) - bu `npm run
  // lint`ning umumiy natijasini deyarli FOYDASIZ qilib qo'ygan edi
  // (haqiqiy muammolar minglab soxta xato ichida ko'milib qolardi).
  // Endi to'g'ri Node.js+Jest global o'zgaruvchilari beriladi, va
  // React'ga xos qoidalar (hooks/refresh) - bu yerda ma'nosiz -
  // o'chirib qo'yiladi.
  {
    files: ['functions/**/*.js'],
    extends: [js.configs.recommended],
    languageOptions: {
      globals: { ...globals.node, ...globals.jest },
      sourceType: 'commonjs',
    },
  },
])
