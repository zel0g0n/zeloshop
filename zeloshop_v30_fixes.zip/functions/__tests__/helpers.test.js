/**
 * `lib/helpers.js`dagi `parseStartParam` uchun testlar - ayniqsa
 * YANGI qo'shilgan "chuqur havola" (_p) formatini tekshirish.
 */
const { parseStartParam, encodeDeepLinkPath, buildDeepLink } = require("../lib/helpers");

describe("parseStartParam", () => {
  test("oddiy sellerId (hech qanday qo'shimchasiz) to'g'ri o'qiladi", () => {
    const result = parseStartParam("seller123");
    expect(result).toMatchObject({ sellerId: "seller123", referrerId: null, deepLinkPath: null });
  });

  test("referal formatini (_r) to'g'ri ajratadi", () => {
    const result = parseStartParam("seller123_r99999");
    expect(result).toMatchObject({ sellerId: "seller123", referrerId: "99999", deepLinkPath: null });
  });

  test("chuqur havola formatini (_p) to'g'ri ajratadi va yo'lni deshifrlaydi", () => {
    // "/category/Skincare" ning base64url kodlanishi
    const encoded = Buffer.from("/category/Skincare", "utf-8").toString("base64").replace(/\+/g, "-").replace(/\//g, "_");
    const result = parseStartParam(`seller123_p${encoded}`);
    expect(result.sellerId).toBe("seller123");
    expect(result.referrerId).toBeNull();
    expect(result.deepLinkPath).toBe("/category/Skincare");
  });

  test("noto'g'ri/buzilgan chuqur havola kodini xato TASHLAMASDAN, null deb qaytaradi", () => {
    const result = parseStartParam("seller123_p!!!notbase64!!!");
    expect(result.sellerId).toBe("seller123");
    expect(result.deepLinkPath).toBeNull();
  });

  test("'/' bilan boshlanmaydigan deshifrlangan yo'lni RAD ETADI (xavfsizlik)", () => {
    // Tashqi manzilga (masalan "evil.com") yo'naltirishga urinishning oldini olish.
    const encoded = Buffer.from("evil.com/phishing", "utf-8").toString("base64").replace(/\+/g, "-").replace(/\//g, "_");
    const result = parseStartParam(`seller123_p${encoded}`);
    expect(result.deepLinkPath).toBeNull();
  });

  test("bo'sh yoki null qiymat uchun xato bermaydi", () => {
    expect(parseStartParam(null)).toMatchObject({ sellerId: null, referrerId: null, deepLinkPath: null });
    expect(parseStartParam("")).toMatchObject({ sellerId: null, referrerId: null, deepLinkPath: null });
  });
});

/**
 * `encodeDeepLinkPath`/`buildDeepLink` - `src/utils/deepLink.js` va
 * `src/utils/shareLink.js`ning SERVER TOMONI (masalan avtomatik kanal
 * posti, `productAutomation.js`, mahsulotga to'g'ridan-to'g'ri havola
 * yasashi uchun ishlatadi). MUHIM: bu ikkalasi `parseStartParam`
 * (yuqoridagi) bilan TO'LIQ round-trip mos kelishi SHART - aks holda
 * backend yasagan havola frontend'da to'g'ri ochilmaydi.
 */
describe("encodeDeepLinkPath + buildDeepLink (server tomoni)", () => {
  test("yasalgan havola `parseStartParam` orqali ORIGINAL yo'lga to'g'ri qaytariladi (round-trip)", () => {
    const link = buildDeepLink("seller123", "/product/abc-XYZ_1");
    expect(link).toMatch(/^https:\/\/t\.me\/zeloshop_bot\/shop\?startapp=seller123_p/);
    const startParam = link.split("startapp=")[1];
    const parsed = parseStartParam(startParam);
    expect(parsed).toEqual({ sellerId: "seller123", referrerId: null, deepLinkPath: "/product/abc-XYZ_1" });
  });

  test("sellerId yoki path berilmasa, null qaytaradi", () => {
    expect(buildDeepLink(null, "/product/1")).toBeNull();
    expect(buildDeepLink("seller123", null)).toBeNull();
  });

  test("bo'sh yo'l uchun bo'sh qator qaytaradi, xato tashlamaydi", () => {
    expect(encodeDeepLinkPath("")).toBe("");
    expect(encodeDeepLinkPath(null)).toBe("");
  });
});
