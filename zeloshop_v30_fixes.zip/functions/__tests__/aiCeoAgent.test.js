/**
 * `aiCeoAgent.js` — AI CEO 6-BOSQICH ("tool-calling arxitekturasi",
 * "avtonom agent" yo'l xaritasining 2-fazasi) uchun testlar.
 *
 * ASOSIY MAQSAD: (1) har bir VOSITA BAJARUVCHISI (`execGet*`) real
 * ma'lumotdan TO'G'RI agregatsiya qilishini, (2) `runToolCallingLoop`
 * ning aylanma suhbat mexanizmi (vosita chaqiruvi -> natija ->
 * yakuniy matn, VA xavfsizlik chegarasi - cheksiz tsiklga
 * tushmasligi) TO'G'RI ishlashini, va (3) `handleAskAiCeo`ning
 * auth/premium/validatsiya tekshiruvlari HAMDA muvaffaqiyatli
 * yo'lini tasdiqlash.
 */

jest.mock("../lib/sentry", () => ({
  withSentry: (fn) => fn,
  SENTRY_DSN: { value: () => null },
  Sentry: { captureException: jest.fn() },
  initSentry: jest.fn(),
}));

function buildMockDb({ sellerData = null, orders = [], products = [], customers = [], learningData = null, coupons = [] } = {}) {
  const db = {
    collection: (name) => {
      if (name === "sellers") {
        return {
          doc: () => ({
            get: async () => (sellerData ? { exists: true, data: () => sellerData } : { exists: false }),
            collection: (subName) => {
              if (subName === "customers") {
                return { get: async () => ({ docs: customers.map((c) => ({ data: () => c })), size: customers.length }) };
              }
              if (subName === "aiCeoLearning") {
                return { doc: () => ({ get: async () => (learningData ? { exists: true, data: () => learningData } : { exists: false }) }) };
              }
              // YANGI (8-BOSQICH bilan bog'lovchi vosita: `get_recent_auto_discounts`).
              if (subName === "coupons") {
                return { where: () => ({ limit: () => ({ get: async () => ({ docs: coupons.map((c) => ({ data: () => c })) }) }) }) };
              }
              return { doc: () => ({ get: async () => ({ exists: false }), set: async () => {} }) };
            },
          }),
        };
      }
      if (name === "products") {
        return { where: () => ({ get: async () => ({ docs: products.map((p) => ({ data: () => p })) }) }) };
      }
      if (name === "orders") {
        const chain = { where: () => chain, get: async () => ({ docs: orders.map((o) => ({ data: () => o })) }) };
        return chain;
      }
      return { doc: () => ({ get: async () => ({ exists: false }) }) };
    },
    // MUHIM: `checkRateLimit` shu orqali ishlaydi - standart holatda
    // "hali chegaradan o'tmagan" holatni simulyatsiya qiladi (bo'sh
    // oyna), shuning uchun aksariyat testlar rate-limit haqida
    // qayg'urmasligi mumkin.
    runTransaction: async (callback) => callback({ get: async () => ({ exists: false }), set: () => {} }),
  };
  return db;
}

function loadAiCeoAgentModule(mockDb, generateContentMock = jest.fn()) {
  jest.resetModules();
  jest.doMock("../lib/admin", () => ({
    admin: { firestore: { Timestamp: { fromMillis: (ms) => ({ toMillis: () => ms }) } } },
    db: mockDb,
    GEMINI_API_KEY: { value: () => "mock-gemini-key" },
  }));
  jest.doMock("@google/genai", () => ({
    GoogleGenAI: jest.fn().mockImplementation(() => ({ models: { generateContent: generateContentMock } })),
  }));
  return require("../aiCeoAgent");
}

describe("clampInt", () => {
  test("son berilgan va oraliqda bo'lsa, O'ZINI qaytaradi", () => {
    const { _testables } = loadAiCeoAgentModule(buildMockDb());
    expect(_testables.clampInt(5, 7, 1, 10)).toBe(5);
  });

  test("son berilmagan/noto'g'ri bo'lsa, FALLBACK qaytaradi", () => {
    const { _testables } = loadAiCeoAgentModule(buildMockDb());
    expect(_testables.clampInt(undefined, 7, 1, 10)).toBe(7);
    expect(_testables.clampInt("noto'g'ri", 7, 1, 10)).toBe(7);
  });

  test("chegaradan CHIQIB ketsa, MIN/MAX'ga qisqartiradi", () => {
    const { _testables } = loadAiCeoAgentModule(buildMockDb());
    expect(_testables.clampInt(999, 7, 1, 10)).toBe(10);
    expect(_testables.clampInt(-5, 7, 1, 10)).toBe(1);
  });
});

describe("execGetRevenueSummary", () => {
  test("FAQAT yetkazilgan buyurtmalardan tushum hisoblaydi, bekor qilish darajasini to'g'ri chiqaradi", async () => {
    const db = buildMockDb({
      orders: [
        { status: "delivered", totalAmount: 100_000 },
        { status: "delivered", totalAmount: 50_000 },
        { status: "cancel", totalAmount: 30_000 },
        { status: "new", totalAmount: 20_000 },
      ],
    });
    const { _testables } = loadAiCeoAgentModule(db);
    const result = await _testables.execGetRevenueSummary("seller-1", { days: 7 });
    expect(result).toEqual({ days: 7, orderCount: 4, deliveredCount: 2, revenue: 150_000, cancelRatePercent: 25 });
  });

  test("`days` berilmasa, standart 7 kunni ishlatadi", async () => {
    const db = buildMockDb({ orders: [] });
    const { _testables } = loadAiCeoAgentModule(db);
    const result = await _testables.execGetRevenueSummary("seller-1", {});
    expect(result.days).toBe(7);
    expect(result.orderCount).toBe(0);
  });
});

describe("execGetTopProducts", () => {
  test("eng ko'p sotilgan mahsulotlarni SONI bo'yicha kamayish tartibida qaytaradi", async () => {
    const db = buildMockDb({
      orders: [
        { status: "delivered", orders: [{ name: "Krem", quantity: 2, price: 50_000 }, { name: "Serum", quantity: 1, price: 80_000 }] },
        { status: "delivered", orders: [{ name: "Krem", quantity: 3, price: 50_000 }] },
      ],
    });
    const { _testables } = loadAiCeoAgentModule(db);
    const result = await _testables.execGetTopProducts("seller-1", { days: 7, limit: 5 });
    expect(result.products).toEqual([
      { name: "Krem", soldQty: 5, revenue: 250_000 },
      { name: "Serum", soldQty: 1, revenue: 80_000 },
    ]);
  });

  test("`limit` parametri natijalar sonini cheklaydi", async () => {
    const db = buildMockDb({
      orders: [
        { status: "delivered", orders: [{ name: "A", quantity: 1, price: 1000 }, { name: "B", quantity: 2, price: 1000 }, { name: "C", quantity: 3, price: 1000 }] },
      ],
    });
    const { _testables } = loadAiCeoAgentModule(db);
    const result = await _testables.execGetTopProducts("seller-1", { days: 7, limit: 2 });
    expect(result.products).toHaveLength(2);
    expect(result.products[0].name).toBe("C");
  });
});

describe("execGetCustomerSegments", () => {
  test("VIP (yuqori LTV) va uxlab qolgan (30+ kun) mijozlarni TO'G'RI sanaydi", async () => {
    const nowMs = Date.now();
    const DAY_MS = 24 * 60 * 60 * 1000;
    const db = buildMockDb({
      customers: [
        { ltv: 600_000, lastOrderAtMs: nowMs }, // VIP
        { ltv: 100_000, lastOrderAtMs: nowMs - 40 * DAY_MS }, // churn
        { ltv: 100_000, lastOrderAtMs: nowMs }, // faol, na VIP na churn
      ],
    });
    const { _testables } = loadAiCeoAgentModule(db);
    const result = await _testables.execGetCustomerSegments("seller-1");
    expect(result).toEqual({ vipCount: 1, churnCount: 1, totalCustomers: 3 });
  });
});

describe("execGetLowStockProducts", () => {
  test("FAQAT 0 dan katta, lekin 5 yoki undan kam zaxirali mahsulotlarni, o'sish tartibida qaytaradi", async () => {
    const db = buildMockDb({
      products: [
        { name: "Tugagan", stock: 0 },
        { name: "Ko'p", stock: 50 },
        { name: "Kam-2", stock: 2 },
        { name: "Kam-1", stock: 1 },
      ],
    });
    const { _testables } = loadAiCeoAgentModule(db);
    const result = await _testables.execGetLowStockProducts("seller-1", { limit: 5 });
    expect(result.lowStock).toEqual([{ name: "Kam-1", stock: 1 }, { name: "Kam-2", stock: 2 }]);
  });
});

describe("execGetAiCeoLearningSummary", () => {
  // AI CEO — 7-BOSQICH ("natija kuzatuvi va o'rganish") bilan
  // BOG'LOVCHI vosita - `aiCeoLearning.js`dagi
  // `buildLearningSummaryForDisplay` BILAN BIR XIL natija berishi kerak.
  test("hujjat mavjud bo'lmasa, ikkala tur ham NULL bo'lgan holatni qaytaradi", async () => {
    const db = buildMockDb({ sellerData: { aiCeoEnabled: true } });
    const { _testables } = loadAiCeoAgentModule(db);
    const result = await _testables.execGetAiCeoLearningSummary("seller-1");
    expect(result).toEqual({ winback: null, favorite: null });
  });

  test("ma'lumot mavjud bo'lsa, TO'G'RI konversiya foizini hisoblab qaytaradi", async () => {
    const db = buildMockDb({ learningData: { winbackAiSent: 10, winbackAiConverted: 3 } });
    const { _testables } = loadAiCeoAgentModule(db);
    const result = await _testables.execGetAiCeoLearningSummary("seller-1");
    expect(result).toEqual({ winback: { sentCount: 10, convertedCount: 3, conversionRatePercent: 30 }, favorite: null });
  });
});

describe("execGetRecentAutoDiscounts", () => {
  // AI CEO — 8-BOSQICH ("avtonom harakatlar doirasini kengaytirish")
  // bilan BOG'LOVCHI vosita - `aiCeoAutoDiscount.js` tomonidan
  // yaratilgan HAQIQIY promokod hujjatlarini (allaqachon mavjud
  // `coupons` kolleksiyasidan) o'qiydi.
  test("hech qanday AI CEO chegirmasi bo'lmasa, bo'sh natija qaytaradi", async () => {
    const db = buildMockDb({ coupons: [] });
    const { _testables } = loadAiCeoAgentModule(db);
    const result = await _testables.execGetRecentAutoDiscounts("seller-1");
    expect(result).toEqual({ totalIssuedCount: 0, activeUnusedCount: 0, recent: [] });
  });

  test("faol/ishlatilmagan sonini TO'G'RI hisoblaydi va ENG YANGI 5tasini qaytaradi", async () => {
    const coupons = [
      { code: "SOGINDIK-A", discountValue: 10, isActive: true, usedCount: 0, usageLimit: 1, createdAtMs: 1000 },
      { code: "SOGINDIK-B", discountValue: 15, isActive: true, usedCount: 1, usageLimit: 1, createdAtMs: 3000 }, // ishlatilgan
      { code: "SOGINDIK-C", discountValue: 5, isActive: false, usedCount: 0, usageLimit: 1, createdAtMs: 2000 }, // faol emas
    ];
    const db = buildMockDb({ coupons });
    const { _testables } = loadAiCeoAgentModule(db);
    const result = await _testables.execGetRecentAutoDiscounts("seller-1");
    expect(result.totalIssuedCount).toBe(3);
    expect(result.activeUnusedCount).toBe(1); // faqat SOGINDIK-A
    expect(result.recent.map((c) => c.code)).toEqual(["SOGINDIK-B", "SOGINDIK-C", "SOGINDIK-A"]); // eng yangidan eskiga
    expect(result.recent[0]).toEqual({ code: "SOGINDIK-B", discountPercent: 15, used: true });
  });
});

describe("runToolCallingLoop", () => {
  test("Gemini DARHOL matn bilan javob bersa (vosita chaqirmasa), BITTA turda tugaydi", async () => {
    const generateContentMock = jest.fn().mockResolvedValue({ text: "Javob tayyor.", functionCalls: undefined });
    const db = buildMockDb();
    const { _testables } = loadAiCeoAgentModule(db, generateContentMock);
    const result = await _testables.runToolCallingLoop({
      prompt: "test", toolDeclarations: [], executors: {}, executorContext: "seller-1",
    });
    expect(result).toEqual({ text: "Javob tayyor.", toolsUsed: [] });
    expect(generateContentMock).toHaveBeenCalledTimes(1);
  });

  test("Gemini vosita chaqirsa, NATIJANI oladi va YAKUNIY matn bilan javob beradi (2 turli suhbat)", async () => {
    const generateContentMock = jest.fn()
      .mockResolvedValueOnce({ functionCalls: [{ id: "1", name: "get_revenue_summary", args: { days: 7 } }] })
      .mockResolvedValueOnce({ text: "Bu hafta tushum 150,000 so'm.", functionCalls: undefined });
    const executor = jest.fn().mockResolvedValue({ revenue: 150_000 });
    const db = buildMockDb();
    const { _testables } = loadAiCeoAgentModule(db, generateContentMock);
    const result = await _testables.runToolCallingLoop({
      prompt: "test",
      toolDeclarations: [{ name: "get_revenue_summary" }],
      executors: { get_revenue_summary: executor },
      executorContext: "seller-1",
    });
    expect(result.text).toBe("Bu hafta tushum 150,000 so'm.");
    expect(result.toolsUsed).toEqual([{ name: "get_revenue_summary", args: { days: 7 } }]);
    expect(executor).toHaveBeenCalledWith("seller-1", { days: 7 });
    expect(generateContentMock).toHaveBeenCalledTimes(2);
  });

  test("noma'lum vosita chaqirilsa, XATOSIZ davom etadi (functionResponse'da xato xabari bilan)", async () => {
    const generateContentMock = jest.fn()
      .mockResolvedValueOnce({ functionCalls: [{ id: "1", name: "hech_qanday_vosita", args: {} }] })
      .mockResolvedValueOnce({ text: "Yakuniy javob.", functionCalls: undefined });
    const db = buildMockDb();
    const { _testables } = loadAiCeoAgentModule(db, generateContentMock);
    const result = await _testables.runToolCallingLoop({
      prompt: "test", toolDeclarations: [], executors: {}, executorContext: "seller-1",
    });
    expect(result.text).toBe("Yakuniy javob.");
    // Ikkinchi (yakuniy) chaqiruvga uzatilgan "contents"da functionResponse
    // xato bilan borganini bilvosita tekshiramiz - jarayon YIQILMAGANI
    // (davom etganligi) o'zi asosiy tasdiq.
    expect(generateContentMock).toHaveBeenCalledTimes(2);
  });

  test("vosita bajaruvchisi XATO tashlasa, jarayon YIQILMAYDI - xato natija sifatida qaytariladi", async () => {
    const generateContentMock = jest.fn()
      .mockResolvedValueOnce({ functionCalls: [{ id: "1", name: "buzilgan_vosita", args: {} }] })
      .mockResolvedValueOnce({ text: "Baribir javob berdim.", functionCalls: undefined });
    const brokenExecutor = jest.fn().mockRejectedValue(new Error("Firestore xatosi"));
    const db = buildMockDb();
    const { _testables } = loadAiCeoAgentModule(db, generateContentMock);
    const result = await _testables.runToolCallingLoop({
      prompt: "test",
      toolDeclarations: [],
      executors: { buzilgan_vosita: brokenExecutor },
      executorContext: "seller-1",
    });
    expect(result.text).toBe("Baribir javob berdim.");
  });

  test("Gemini 3 `thoughtSignature`ni (candidate.content orqali) KEYINGI turga O'ZGARISHSIZ uzatadi - vosita chaqirilgandan keyin bu maydon yo'qolib qolmasligi kerak (aks holda API 'missing thought_signature' 400-xatosi qaytaradi)", async () => {
    const modelContentWithSignature = {
      role: "model",
      parts: [{ functionCall: { id: "1", name: "get_revenue_summary", args: { days: 7 } }, thoughtSignature: "opaque-signature-abc" }],
    };
    const generateContentMock = jest.fn()
      .mockResolvedValueOnce({
        functionCalls: [{ id: "1", name: "get_revenue_summary", args: { days: 7 } }],
        candidates: [{ content: modelContentWithSignature }],
      })
      .mockResolvedValueOnce({ text: "Bu hafta tushum 150,000 so'm.", functionCalls: undefined });
    const executor = jest.fn().mockResolvedValue({ revenue: 150_000 });
    const db = buildMockDb();
    const { _testables } = loadAiCeoAgentModule(db, generateContentMock);
    await _testables.runToolCallingLoop({
      prompt: "test",
      toolDeclarations: [{ name: "get_revenue_summary" }],
      executors: { get_revenue_summary: executor },
      executorContext: "seller-1",
    });
    // Ikkinchi (keyingi) `generateContent` chaqiruviga uzatilgan `contents`
    // ichida, model turi ASL `thoughtSignature`ni saqlab qolgani SHART -
    // qo'lda `{ functionCall: c }` qayta qurish bu maydonni tushirib
    // qoldirar edi (chunki u `FunctionCall` emas, `Part` darajasida).
    const secondCallArgs = generateContentMock.mock.calls[1][0];
    const modelTurn = secondCallArgs.contents.find((c) => c.role === "model");
    expect(modelTurn).toEqual(modelContentWithSignature);
    expect(modelTurn.parts[0].thoughtSignature).toBe("opaque-signature-abc");
  });

  test("XAVFSIZLIK CHEGARASI: Gemini CHEKSIZ vosita chaqirsa ham, `maxRounds`dan keyin to'xtaydi (bo'sh matn bilan)", async () => {
    // Gemini HAR DOIM vosita chaqiryapti deb simulyatsiya qilamiz (hech
    // qachon yakuniy matn bermaydi) - bu, real hayotda, Gemini'ning
    // "gallyutsinatsiya"si yoki noto'g'ri konfiguratsiya bilan sodir
    // bo'lishi mumkin. MUHIM: loop CHEKSIZ aylanmasligi kerak.
    const generateContentMock = jest.fn().mockResolvedValue({ functionCalls: [{ id: "x", name: "get_revenue_summary", args: {} }] });
    const executor = jest.fn().mockResolvedValue({ ok: true });
    const db = buildMockDb();
    const { _testables } = loadAiCeoAgentModule(db, generateContentMock);
    const result = await _testables.runToolCallingLoop({
      prompt: "test",
      toolDeclarations: [{ name: "get_revenue_summary" }],
      executors: { get_revenue_summary: executor },
      executorContext: "seller-1",
      maxRounds: 2,
    });
    expect(result.text).toBe("");
    expect(generateContentMock).toHaveBeenCalledTimes(2);
    expect(result.toolsUsed).toHaveLength(2);
  });
});

describe("buildAskAiCeoPrompt", () => {
  test("savol va do'kon nomini promptga TO'G'RI kiritadi", () => {
    const { _testables } = loadAiCeoAgentModule(buildMockDb());
    const prompt = _testables.buildAskAiCeoPrompt("Bu hafta nima sotildi?", "Gulnora Cosmetics");
    expect(prompt).toContain("Bu hafta nima sotildi?");
    expect(prompt).toContain("Gulnora Cosmetics");
  });

  test("do'kon nomi berilmasa, standart \"Do'kon\"ni ishlatadi", () => {
    const { _testables } = loadAiCeoAgentModule(buildMockDb());
    const prompt = _testables.buildAskAiCeoPrompt("Savol", null);
    expect(prompt).toContain("\"Do'kon\"");
  });
});

describe("handleAskAiCeo", () => {
  test("tizimga kirmagan foydalanuvchini rad etadi", async () => {
    const { _testables } = loadAiCeoAgentModule(buildMockDb());
    await expect(_testables.handleAskAiCeo({ auth: null, data: { question: "Savol" } }))
      .rejects.toMatchObject({ code: "unauthenticated" });
  });

  test("premium bo'lmagan sotuvchini rad etadi", async () => {
    const db = buildMockDb({ sellerData: { aiCeoEnabled: false } });
    const { _testables } = loadAiCeoAgentModule(db);
    await expect(_testables.handleAskAiCeo({ auth: { uid: "seller-1" }, data: { question: "Savol" } }))
      .rejects.toMatchObject({ code: "permission-denied" });
  });

  test("bo'sh savolni rad etadi", async () => {
    const db = buildMockDb({ sellerData: { aiCeoEnabled: true } });
    const { _testables } = loadAiCeoAgentModule(db);
    await expect(_testables.handleAskAiCeo({ auth: { uid: "seller-1" }, data: { question: "   " } }))
      .rejects.toMatchObject({ code: "invalid-argument" });
  });

  test("juda uzun (300 belgidan ortiq) savolni rad etadi", async () => {
    const db = buildMockDb({ sellerData: { aiCeoEnabled: true } });
    const { _testables } = loadAiCeoAgentModule(db);
    await expect(_testables.handleAskAiCeo({ auth: { uid: "seller-1" }, data: { question: "a".repeat(301) } }))
      .rejects.toMatchObject({ code: "invalid-argument" });
  });

  test("muvaffaqiyatli holatda, javob VA ishlatilgan vositalar nomlarini qaytaradi", async () => {
    const generateContentMock = jest.fn()
      .mockResolvedValueOnce({ functionCalls: [{ id: "1", name: "get_revenue_summary", args: { days: 7 } }] })
      .mockResolvedValueOnce({ text: "Bu hafta tushum 150,000 so'm bo'ldi.", functionCalls: undefined });
    const db = buildMockDb({
      sellerData: { aiCeoEnabled: true, storeName: "Gulnora Cosmetics" },
      orders: [{ status: "delivered", totalAmount: 150_000 }],
    });
    const { _testables } = loadAiCeoAgentModule(db, generateContentMock);
    const result = await _testables.handleAskAiCeo({ auth: { uid: "seller-1" }, data: { question: "Bu hafta tushum qancha?" } });
    expect(result).toEqual({ answer: "Bu hafta tushum 150,000 so'm bo'ldi.", toolsUsed: ["get_revenue_summary"] });
  });

  test("AI bo'sh javob qaytarsa (yoki umuman javob bera olmasa), ICHKI xatolik tashlaydi", async () => {
    const generateContentMock = jest.fn().mockResolvedValue({ text: "", functionCalls: undefined });
    const db = buildMockDb({ sellerData: { aiCeoEnabled: true } });
    const { _testables } = loadAiCeoAgentModule(db, generateContentMock);
    await expect(_testables.handleAskAiCeo({ auth: { uid: "seller-1" }, data: { question: "Savol" } }))
      .rejects.toMatchObject({ code: "internal" });
  });
});
