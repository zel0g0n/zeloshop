/**
 * `telegramBotMenu.js` — foydalanuvchi so'ragan, platforma botiga
 * qo'shilgan IKKI yangi "menyu" tugmasi ("AI CEO hisobotlari" va "AI
 * CEO bilan mahsulot qo'shish") uchun testlar.
 */

jest.mock("../lib/sentry", () => ({
  withSentry: (fn) => fn,
  SENTRY_DSN: { value: () => null },
  Sentry: { captureException: jest.fn() },
  initSentry: jest.fn(),
}));

function buildMockDb({ sellerData = null, session = null } = {}) {
  const setCalls = [];
  const updateCalls = [];
  const deleteCalls = [];
  const addCalls = [];
  const db = {
    collection: (name) => {
      if (name === "sellers") {
        return {
          doc: (sellerId) => ({
            get: async () => (sellerData ? { exists: true, data: () => sellerData } : { exists: false }),
            collection: (subName) => {
              if (subName === "private") {
                return {
                  doc: (docId) => ({
                    get: async () => (session ? { exists: true, data: () => session } : { exists: false }),
                    set: async (data) => setCalls.push({ sellerId, docId, data }),
                    update: async (data) => {
                      updateCalls.push({ sellerId, docId, data });
                      // `arrayUnion`ni sodda simulyatsiya qilamiz - test
                      // ichida bevosita URL string'ini kuzatish uchun.
                      if (data.photoUrls && data.photoUrls.__op === "arrayUnion") {
                        session.photoUrls = [...(session.photoUrls || []), ...data.photoUrls.values];
                      }
                    },
                    delete: async () => deleteCalls.push({ sellerId, docId }),
                  }),
                };
              }
              if (subName === "productDrafts") {
                return {
                  add: async (data) => {
                    addCalls.push({ sellerId, data });
                    return { id: "draft-1", update: async () => {} };
                  },
                };
              }
              return { doc: () => ({ get: async () => ({ exists: false }) }) };
            },
          }),
        };
      }
      return { doc: () => ({ get: async () => ({ exists: false }) }) };
    },
    runTransaction: async (callback) => callback({ get: async () => ({ exists: false }), set: () => {} }),
    __setCalls: setCalls,
    __updateCalls: updateCalls,
    __deleteCalls: deleteCalls,
    __addCalls: addCalls,
  };
  return db;
}

function loadModule(db, { buildDailyReportMock, processDraftMock } = {}) {
  jest.resetModules();
  jest.doMock("../lib/admin", () => ({
    admin: {
      firestore: {
        FieldValue: {
          serverTimestamp: () => "MOCK_TS",
          arrayUnion: (...values) => ({ __op: "arrayUnion", values }),
        },
      },
      storage: () => ({
        bucket: () => ({
          name: "mock-bucket",
          file: () => ({ save: jest.fn(async () => undefined) }),
        }),
      }),
    },
    db,
    GEMINI_API_KEY: { value: () => "mock-gemini-key" },
  }));
  jest.doMock("../aiCeo", () => ({
    buildDailyReport: buildDailyReportMock || jest.fn(),
  }));
  jest.doMock("../productDrafts", () => ({
    processDraft: processDraftMock || jest.fn(async () => undefined),
  }));
  return require("../telegramBotMenu");
}

describe("buildMainMenuKeyboard / buildPhotoCollectionKeyboard (sof funksiyalar)", () => {
  test("asosiy menyu ikkala yangi tugmani o'z ichiga oladi", () => {
    const { buildMainMenuKeyboard, MENU_REPORT_TEXT, MENU_ADD_PRODUCT_TEXT } = loadModule(buildMockDb());
    const keyboard = buildMainMenuKeyboard();
    const allTexts = keyboard.keyboard.flat().map((b) => b.text);
    expect(allTexts).toEqual([MENU_REPORT_TEXT, MENU_ADD_PRODUCT_TEXT]);
    expect(keyboard.resize_keyboard).toBe(true);
  });

  test("rasm yig'ish menyusi 'Tayyor' va 'Bekor qilish' tugmalarini o'z ichiga oladi", () => {
    const { buildPhotoCollectionKeyboard, FINISH_TEXT, CANCEL_TEXT } = loadModule(buildMockDb());
    const keyboard = buildPhotoCollectionKeyboard();
    expect(keyboard.keyboard[0].map((b) => b.text)).toEqual([FINISH_TEXT, CANCEL_TEXT]);
  });
});

describe("pickLargestPhoto", () => {
  test("eng katta (width*height) o'lchamli rasmni tanlaydi", () => {
    const { pickLargestPhoto } = loadModule(buildMockDb());
    const sizes = [
      { file_id: "small", width: 90, height: 90 },
      { file_id: "large", width: 1280, height: 960 },
      { file_id: "medium", width: 320, height: 240 },
    ];
    expect(pickLargestPhoto(sizes).file_id).toBe("large");
  });

  test("bo'sh/null massiv uchun null qaytaradi", () => {
    const { pickLargestPhoto } = loadModule(buildMockDb());
    expect(pickLargestPhoto([])).toBeNull();
    expect(pickLargestPhoto(null)).toBeNull();
  });
});

describe("formatDailyReportForTelegram", () => {
  const baseReport = {
    date: "2026-08-25",
    financial: { todayRevenue: 450_000, yesterdayRevenue: 380_000, revenueChangePercent: 18.4, todayOrderCount: 12, todayDeliveredCount: 9 },
    productRecommendations: { discountCandidates: [], promoteCandidates: [] },
    productAdditions: { addedTodayCount: 0, salesFromNewProducts: 0 },
    crmActivity: {
      cartRemindersSent: 0, favoriteRemindersSent: 0, repurchaseRemindersSent: 0, crmMessagesSent: 0,
      convertedCount: 0, activeCustomers: 10, inactiveCustomers: 2, aiAutoActionsCount: 0, autoDiscountsIssuedCount: 0,
    },
    attentionNeeded: { vipCount: 0, churnCount: 0 },
    aiActionPlan: null,
    learningSummary: { winback: null, favorite: null },
  };

  test("asosiy moliyaviy ma'lumotni to'g'ri kiritadi", () => {
    const { formatDailyReportForTelegram } = loadModule(buildMockDb());
    const text = formatDailyReportForTelegram(baseReport, "Gulnora Cosmetics");
    expect(text).toContain("Gulnora Cosmetics");
    expect(text).toContain("450,000 so'm");
    expect(text).toContain("380,000 so'm");
    expect(text).toContain("+18%");
  });

  test("revenueChangePercent null bo'lsa, foizni EMAS, tushuntirish matnini yozadi", () => {
    const { formatDailyReportForTelegram } = loadModule(buildMockDb());
    const text = formatDailyReportForTelegram({ ...baseReport, financial: { ...baseReport.financial, revenueChangePercent: null } });
    expect(text).toContain("solishtirish uchun yetarli ma'lumot yo'q");
  });

  test("mahsulot tavsiyalari bo'sh bo'lsa, o'sha bo'limni QO'SHMAYDI", () => {
    const { formatDailyReportForTelegram } = loadModule(buildMockDb());
    const text = formatDailyReportForTelegram(baseReport);
    expect(text).not.toContain("Mahsulot tavsiyalari");
  });

  test("mahsulot tavsiyalari bo'lsa, nomlarini ko'rsatadi", () => {
    const { formatDailyReportForTelegram } = loadModule(buildMockDb());
    const report = {
      ...baseReport,
      productRecommendations: {
        discountCandidates: [{ id: "p1", name: "Krem A" }],
        promoteCandidates: [{ id: "p2", name: "Krem B", soldQty: 14 }],
      },
    };
    const text = formatDailyReportForTelegram(report);
    expect(text).toContain("Krem A");
    expect(text).toContain("Krem B (14 dona)");
  });

  test("AI harakat rejasi bo'lsa, sababini qo'shadi", () => {
    const { formatDailyReportForTelegram } = loadModule(buildMockDb());
    const text = formatDailyReportForTelegram({ ...baseReport, aiActionPlan: { order: ["vip"], reasoning: "VIP mijozlar ustuvor" } });
    expect(text).toContain("VIP mijozlar ustuvor");
  });
});

describe("handleTelegramMessage - marshrutlash", () => {
  test("aiCeoEnabled bo'lmagan sotuvchi 'hisobot' tugmasini bossa, premium xabarini oladi, Gemini chaqirilmaydi", async () => {
    const buildDailyReportMock = jest.fn();
    const db = buildMockDb({ sellerData: { aiCeoEnabled: false } });
    const originalFetch = global.fetch;
    global.fetch = jest.fn(async () => ({ json: async () => ({ ok: true }) }));
    try {
      const { handleTelegramMessage, MENU_REPORT_TEXT } = loadModule(db, { buildDailyReportMock });
      await handleTelegramMessage("mock-token", { text: MENU_REPORT_TEXT, from: { id: 555 }, chat: { id: 555 } });
      expect(buildDailyReportMock).not.toHaveBeenCalled();
      expect(global.fetch).toHaveBeenCalledWith(
        expect.stringContaining("/sendMessage"),
        expect.objectContaining({ body: expect.stringContaining("premium") })
      );
    } finally {
      global.fetch = originalFetch;
    }
  });

  test("aiCeoEnabled sotuvchi 'hisobot' tugmasini bossa, buildDailyReport chaqiriladi va natija yuboriladi", async () => {
    const buildDailyReportMock = jest.fn(async () => ({
      date: "2026-08-25",
      financial: { todayRevenue: 100, yesterdayRevenue: 50, revenueChangePercent: 100, todayOrderCount: 1, todayDeliveredCount: 1 },
      productRecommendations: { discountCandidates: [], promoteCandidates: [] },
      productAdditions: { addedTodayCount: 0, salesFromNewProducts: 0 },
      crmActivity: { cartRemindersSent: 0, favoriteRemindersSent: 0, repurchaseRemindersSent: 0, crmMessagesSent: 0, convertedCount: 0, activeCustomers: 0, inactiveCustomers: 0, aiAutoActionsCount: 0, autoDiscountsIssuedCount: 0 },
      attentionNeeded: { vipCount: 0, churnCount: 0 },
      aiActionPlan: null,
      learningSummary: { winback: null, favorite: null },
    }));
    const db = buildMockDb({ sellerData: { aiCeoEnabled: true, storeName: "Zelo" } });
    const originalFetch = global.fetch;
    global.fetch = jest.fn(async () => ({ json: async () => ({ ok: true }) }));
    try {
      const { handleTelegramMessage, MENU_REPORT_TEXT } = loadModule(db, { buildDailyReportMock });
      await handleTelegramMessage("mock-token", { text: MENU_REPORT_TEXT, from: { id: 555 }, chat: { id: 555 } });
      expect(buildDailyReportMock).toHaveBeenCalledWith("555", { aiCeoEnabled: true, storeName: "Zelo" });
      expect(global.fetch).toHaveBeenCalledWith(
        expect.stringContaining("/sendMessage"),
        expect.objectContaining({ body: expect.stringContaining("Zelo") })
      );
    } finally {
      global.fetch = originalFetch;
    }
  });

  test("'mahsulot qo'shish' tugmasi bosilsa, sessiya 'awaiting_photos' rejimida boshlanadi", async () => {
    const db = buildMockDb({ sellerData: { aiCeoEnabled: true } });
    const originalFetch = global.fetch;
    global.fetch = jest.fn(async () => ({ json: async () => ({ ok: true }) }));
    try {
      const { handleTelegramMessage, MENU_ADD_PRODUCT_TEXT } = loadModule(db, {});
      await handleTelegramMessage("mock-token", { text: MENU_ADD_PRODUCT_TEXT, from: { id: 555 }, chat: { id: 555 } });
      expect(db.__setCalls).toHaveLength(1);
      expect(db.__setCalls[0].data.mode).toBe("awaiting_photos");
      expect(db.__setCalls[0].data.photoUrls).toEqual([]);
    } finally {
      global.fetch = originalFetch;
    }
  });

  test("rasm kelganda, sessiya bo'lmasa - HECH NARSA qilmaydi (jim e'tiborsiz)", async () => {
    const db = buildMockDb({ sellerData: { aiCeoEnabled: true }, session: null });
    const originalFetch = global.fetch;
    global.fetch = jest.fn(async () => ({ json: async () => ({ ok: true }) }));
    try {
      const { handleTelegramMessage } = loadModule(db, {});
      await handleTelegramMessage("mock-token", {
        photo: [{ file_id: "f1", width: 100, height: 100 }],
        from: { id: 555 }, chat: { id: 555 },
      });
      expect(global.fetch).not.toHaveBeenCalled();
    } finally {
      global.fetch = originalFetch;
    }
  });

  test("'Tayyor' bosilganda, rasm YO'Q bo'lsa - kamida bitta rasm so'raladi, draft YARATILMAYDI", async () => {
    const db = buildMockDb({ sellerData: { aiCeoEnabled: true }, session: { mode: "awaiting_photos", photoUrls: [] } });
    const originalFetch = global.fetch;
    global.fetch = jest.fn(async () => ({ json: async () => ({ ok: true }) }));
    try {
      const { handleTelegramMessage, FINISH_TEXT } = loadModule(db, {});
      await handleTelegramMessage("mock-token", { text: FINISH_TEXT, from: { id: 555 }, chat: { id: 555 } });
      expect(db.__addCalls).toHaveLength(0);
    } finally {
      global.fetch = originalFetch;
    }
  });

  test("'Tayyor' bosilganda, rasm(lar) bor bo'lsa - draft yaratiladi va processDraft chaqiriladi", async () => {
    const processDraftMock = jest.fn(async (ai, ref, draft) => { draft.status = "ready_for_review"; });
    const db = buildMockDb({
      sellerData: { aiCeoEnabled: true },
      session: { mode: "awaiting_photos", photoUrls: ["https://example.com/1.jpg"] },
    });
    const originalFetch = global.fetch;
    global.fetch = jest.fn(async () => ({ json: async () => ({ ok: true }) }));
    try {
      const { handleTelegramMessage, FINISH_TEXT } = loadModule(db, { processDraftMock });
      await handleTelegramMessage("mock-token", { text: FINISH_TEXT, from: { id: 555 }, chat: { id: 555 } });
      expect(db.__addCalls).toHaveLength(1);
      expect(db.__addCalls[0].data).toMatchObject({ imageUrls: ["https://example.com/1.jpg"], status: "queued" });
      expect(processDraftMock).toHaveBeenCalledTimes(1);
      expect(db.__deleteCalls).toHaveLength(1); // sessiya tozalandi
    } finally {
      global.fetch = originalFetch;
    }
  });

  test("kunlik 4 ta mahsulot chegarasidan oshsa, draft YARATILMAYDI (Gemini chaqirilmaydi)", async () => {
    const processDraftMock = jest.fn();
    const rateLimitDb = buildMockDb({
      sellerData: { aiCeoEnabled: true },
      session: { mode: "awaiting_photos", photoUrls: ["https://example.com/1.jpg"] },
    });
    // `checkRateLimit` haqiqiy Firestore transaction orqali ishlaydi -
    // shu sababli `rateLimits` kolleksiyasini ALLAQACHON chegaraga
    // yetgan holatda simulyatsiya qilamiz.
    const originalCollection = rateLimitDb.collection;
    rateLimitDb.collection = (name) => {
      if (name === "rateLimits") {
        return { doc: () => ({}) };
      }
      return originalCollection(name);
    };
    rateLimitDb.runTransaction = async (callback) => callback({
      get: async () => ({ exists: true, data: () => ({ windowStart: Date.now(), count: 4 }) }),
      set: () => {},
    });

    const originalFetch = global.fetch;
    global.fetch = jest.fn(async () => ({ json: async () => ({ ok: true }) }));
    try {
      const { handleTelegramMessage, FINISH_TEXT } = loadModule(rateLimitDb, { processDraftMock });
      await handleTelegramMessage("mock-token", { text: FINISH_TEXT, from: { id: 555 }, chat: { id: 555 } });
      expect(processDraftMock).not.toHaveBeenCalled();
      expect(rateLimitDb.__addCalls).toHaveLength(0);
      expect(global.fetch).toHaveBeenCalledWith(
        expect.stringContaining("/sendMessage"),
        expect.objectContaining({ body: expect.stringContaining("Kunlik chegara") })
      );
    } finally {
      global.fetch = originalFetch;
    }
  });

  test("'Bekor qilish' bosilganda, sessiya o'chiriladi", async () => {
    const db = buildMockDb({ sellerData: { aiCeoEnabled: true }, session: { mode: "awaiting_photos", photoUrls: [] } });
    const originalFetch = global.fetch;
    global.fetch = jest.fn(async () => ({ json: async () => ({ ok: true }) }));
    try {
      const { handleTelegramMessage, CANCEL_TEXT } = loadModule(db, {});
      await handleTelegramMessage("mock-token", { text: CANCEL_TEXT, from: { id: 555 }, chat: { id: 555 } });
      expect(db.__deleteCalls).toHaveLength(1);
    } finally {
      global.fetch = originalFetch;
    }
  });

  test("sellerId/chatId bo'lmasa, hech narsa qilmaydi (xato tashlamaydi)", async () => {
    const { handleTelegramMessage } = loadModule(buildMockDb());
    await expect(handleTelegramMessage("mock-token", {})).resolves.toBeUndefined();
  });
});
