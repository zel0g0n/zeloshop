/**
 * `notifications.js`dagi `sendCrmNotification` uchun testlar.
 *
 * MUHIM, YAKUNIY TUZATISH TARIXI: bu testlar OLDIN "sotuvchi shaxsiy
 * bot ulagan bo'lsa, xabar O'SHA bot orqali yuborilishi kerak" deb
 * TASDIQLAR edi - bu, o'sha payt uchun TO'G'RI edi (mijoz haqiqatan
 * shaxsiy bot orqali kirgan bo'lardi). LEKIN keyinroq, `shareLink.js`
 * dagi "bot not found" xatosi tuzatilganda (barcha ulashiladigan
 * havolalar - do'kon, referal, mahsulot - endi DOIM platformaning
 * o'z boti orqali quriladi, chunki faqat O'SHA botda Mini App rasmiy
 * ro'yxatdan o'tkazilgan), bu ESKI FARAZ NOTO'G'RIGA AYLANDI: mijoz
 * ENDI DEYARLI HECH QACHON sotuvchining shaxsiy botini ishga
 * tushirmaydi - shuning uchun CRM xabarini O'SHA bot orqali
 * yuborishga urinish, aksincha, xabarning HECH QACHON YETIB
 * BORMASLIGIGA sabab bo'lardi ("chat not found"). Bu - foydalanuvchi
 * xabar qabul qilinmayotganini xabar qilgandan keyin TOPILGAN,
 * HAQIQIY production xatosi edi. Testlar endi TO'G'RILANGAN xatti-
 * harakatni (har doim platforma boti) tasdiqlaydi.
 */

function buildMockDb({ customerBotToken = null, verifiedClientIds = [] } = {}) {
  return {
    collection: (name) => {
      if (name === "sellers") {
        return {
          doc: () => ({
            collection: () => ({
              doc: () => ({
                get: async () => (
                  customerBotToken
                    ? { exists: true, data: () => ({ botToken: customerBotToken }) }
                    : { exists: false }
                ),
                set: async () => undefined, // dailyStats hisoblagichi uchun (bu testlar buni tekshirmaydi)
              }),
            }),
          }),
        };
      }
      if (name === "orders") {
        return {
          where: () => ({
            where: () => ({
              get: async () => ({
                forEach: (cb) => verifiedClientIds.forEach((id) => cb({ data: () => ({ clientId: id }) })),
              }),
            }),
          }),
        };
      }
      // MUHIM: `logNotification` (bildirishnoma jurnali) `.add(...)`
      // chaqiradi - "notificationLogs" kolleksiyasi uchun ham
      // qo'llab-quvvatlaymiz.
      return { doc: () => ({ get: async () => ({ exists: false }) }), add: async () => ({}) };
    },
  };
}

function loadNotificationsModule({ customerBotToken, verifiedClientIds, sendResult } = {}) {
  jest.resetModules();

  const mockDb = buildMockDb({ customerBotToken, verifiedClientIds });
  const sendTelegramMessageMock = jest.fn(async () => sendResult || { ok: true });

  jest.doMock("../lib/admin", () => ({
    admin: { firestore: () => mockDb, FieldValue: { serverTimestamp: () => "MOCK_TS" } },
    BOT_TOKEN: { value: () => "platform-shared-token" },
    GEMINI_API_KEY: { value: () => "mock" },
    db: mockDb,
  }));
  jest.doMock("../lib/helpers", () => ({
    sendTelegramMessage: sendTelegramMessageMock,
    sanitizeFirestoreData: (d) => d,
  }));
  jest.doMock("../lib/rateLimit", () => ({
    checkRateLimit: jest.fn(async () => undefined),
  }));

  const notifications = require("../notifications");
  return { notifications, sendTelegramMessageMock };
}

describe("sendCrmNotification — bot tokeni tanlash mantig'i", () => {
  test("sotuvchi shaxsiy bot ulagan bo'lsa HAM, xabar HAR DOIM platforma tokeni orqali yuboriladi (mijoz shaxsiy botni ishga tushirmagan bo'lishi mumkin)", async () => {
    const { notifications, sendTelegramMessageMock } = loadNotificationsModule({
      customerBotToken: "sellers-own-bot-token",
      verifiedClientIds: ["client-1"],
    });

    await notifications._testables.handleSendCrmNotification({
      auth: { uid: "seller-1" },
      data: {
        sellerId: "seller-1",
        targetClientIds: ["client-1"],
        title: "Aksiya",
        message: "15% chegirma",
      },
    });

    expect(sendTelegramMessageMock).toHaveBeenCalledTimes(1);
    // MUHIM: shaxsiy bot ulangan BO'LSA HAM, token HAR DOIM
    // platformaniki bo'lishi kerak - mijoz shaxsiy botni HECH QACHON
    // ishga tushirmagan bo'lishi mumkin (deep-link tuzatishidan
    // keyin, u ODATDA shunday).
    expect(sendTelegramMessageMock.mock.calls[0][0]).toBe("platform-shared-token");
  });

  test("sotuvchida shaxsiy bot bo'lmasa ham, xuddi shunday platforma tokeni ishlatiladi", async () => {
    const { notifications, sendTelegramMessageMock } = loadNotificationsModule({
      customerBotToken: null,
      verifiedClientIds: ["client-1"],
    });

    await notifications._testables.handleSendCrmNotification({
      auth: { uid: "seller-1" },
      data: {
        sellerId: "seller-1",
        targetClientIds: ["client-1"],
        title: "Aksiya",
        message: "15% chegirma",
      },
    });

    expect(sendTelegramMessageMock.mock.calls[0][0]).toBe("platform-shared-token");
  });

  test("tasdiqlanmagan (buyurtma tarixida yo'q) mijozlarga xabar yuborilmaydi", async () => {
    const { notifications, sendTelegramMessageMock } = loadNotificationsModule({
      customerBotToken: null,
      verifiedClientIds: ["client-real"], // faqat shu ID haqiqiy buyurtmaga ega
    });

    const result = await notifications._testables.handleSendCrmNotification({
      auth: { uid: "seller-1" },
      data: {
        sellerId: "seller-1",
        targetClientIds: ["client-real", "client-fake"],
        title: "Aksiya",
        message: "15% chegirma",
      },
    });

    expect(sendTelegramMessageMock).toHaveBeenCalledTimes(1);
    expect(result.clientsTotal).toBe(1);
  });

  test("tizimga kirmagan foydalanuvchi so'rovini rad etadi", async () => {
    const { notifications } = loadNotificationsModule({});
    await expect(
      notifications._testables.handleSendCrmNotification({ auth: null, data: {} })
    ).rejects.toMatchObject({ code: "unauthenticated" });
  });

  test("boshqa sotuvchi nomidan xabar yuborishga urinishni rad etadi", async () => {
    const { notifications } = loadNotificationsModule({});
    await expect(
      notifications._testables.handleSendCrmNotification({
        auth: { uid: "seller-1" },
        data: { sellerId: "seller-2", targetClientIds: ["x"], title: "a", message: "b" },
      })
    ).rejects.toMatchObject({ code: "permission-denied" });
  });
});
