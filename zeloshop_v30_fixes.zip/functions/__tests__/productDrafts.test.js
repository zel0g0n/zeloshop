/**
 * `productDrafts.js`dagi SOF funksiyalar uchun testlar.
 *
 * ASOSIY MAQSAD: `parseDraftResponse` - Gemini matn javobini
 * ishonchli ajratib olishi SHART, chunki bu, mahsulot tavsifi VA
 * kategoriyasi to'g'ri saqlanishining yagona kafolati.
 */

function loadModule() {
  jest.resetModules();
  jest.doMock("../lib/admin", () => ({
    admin: { firestore: { FieldValue: { serverTimestamp: () => "MOCK_TS" } } },
    db: {},
    BOT_TOKEN: { value: () => "mock-bot-token" },
    GEMINI_API_KEY: { value: () => "mock-gemini-key" },
  }));
  jest.doMock("../lib/helpers", () => ({ sendTelegramMessage: jest.fn() }));
  jest.doMock("@google/genai", () => ({ GoogleGenAI: jest.fn() }));
  return require("../productDrafts");
}

describe("parseDraftResponse", () => {
  test("standart formatdagi javobni to'g'ri ajratadi", () => {
    const { _testables } = loadModule();
    const raw = "TAVSIF: Yumshoq va nam beruvchi krem, teringizga g'amxo'rlik qiladi.\nKATEGORIYA: Skincare";
    const result = _testables.parseDraftResponse(raw);
    expect(result.description).toBe("Yumshoq va nam beruvchi krem, teringizga g'amxo'rlik qiladi.");
    expect(result.category).toBe("Skincare");
  });

  test("tavsifda bir necha qator bo'lsa ham to'g'ri ajratadi", () => {
    const { _testables } = loadModule();
    const raw = "TAVSIF: Birinchi qator.\nIkkinchi qator davomi.\nKATEGORIYA: Makeup";
    const result = _testables.parseDraftResponse(raw);
    expect(result.description).toBe("Birinchi qator.\nIkkinchi qator davomi.");
    expect(result.category).toBe("Makeup");
  });

  test("KATEGORIYA qatori umuman bo'lmasa, category null bo'ladi (xato bermaydi)", () => {
    const { _testables } = loadModule();
    const raw = "TAVSIF: Faqat tavsif, kategoriyasiz.";
    const result = _testables.parseDraftResponse(raw);
    expect(result.description).toBe("Faqat tavsif, kategoriyasiz.");
    expect(result.category).toBeNull();
  });

  test("format UMUMAN mos kelmasa (Gemini kutilmagan javob bersa), butun matnni tavsif sifatida qabul qiladi", () => {
    const { _testables } = loadModule();
    const raw = "Bu yerda hech qanday belgilangan format yo'q, oddiy matn.";
    const result = _testables.parseDraftResponse(raw);
    expect(result.description).toBe(raw);
    expect(result.category).toBeNull();
  });

  test("NOM qatorini to'g'ri ajratadi (mahsulot nomi AI tomonidan yaratiladi)", () => {
    const { _testables } = loadModule();
    const raw = "NOM: Qora rangli teri krem, 50ml\nTAVSIF: Yumshoq krem.\nKATEGORIYA: Skincare";
    const result = _testables.parseDraftResponse(raw);
    expect(result.name).toBe("Qora rangli teri krem, 50ml");
    expect(result.description).toBe("Yumshoq krem.");
    expect(result.category).toBe("Skincare");
  });

  test("NOM qatori bo'lmasa, name null bo'ladi (xato bermaydi)", () => {
    const { _testables } = loadModule();
    const raw = "TAVSIF: Faqat tavsif.\nKATEGORIYA: Makeup";
    const result = _testables.parseDraftResponse(raw);
    expect(result.name).toBeNull();
  });
});

describe("buildDraftPrompt", () => {
  test("sotuvchi izohini promptga to'g'ri kiritadi", () => {
    const { _testables } = loadModule();
    const prompt = _testables.buildDraftPrompt("qora rangli krem, 50ml", true);
    expect(prompt).toContain("qora rangli krem, 50ml");
    expect(prompt).toContain("TAVSIF:");
    expect(prompt).toContain("KATEGORIYA:");
    expect(prompt).toContain("NOM:");
  });

  test("izoh BO'SH bo'lsa ham (faqat rasm), xato bermaydi va rasmga tayanishni SO'RAYDI", () => {
    const { _testables } = loadModule();
    const prompt = _testables.buildDraftPrompt("", true);
    expect(prompt).toContain("FAQAT rasmga qarab");
  });

  test("narx haqida HECH QANDAY so'rov YO'Q (AI narx taklif qilmasligi kerak)", () => {
    const { _testables } = loadModule();
    const prompt = _testables.buildDraftPrompt("test mahsulot", false);
    expect(prompt.toLowerCase()).not.toContain("narx");
  });
});
