/**
 * `orderRollups.js` — buyurtma "delivered" holatiga o'tganda/
 * chiqarilganda ishga tushadigan trigger, va bir martalik migratsiya
 * (`backfillSellerRollups`) uchun testlar. Sof hisoblash mantig'i
 * (`lib/rollups.js`) alohida, `rollups.test.js`da sinaladi - bu
 * yerda FAQAT Firestore bilan bog'liq "yig'ish/yozish" mantig'i
 * (mock db orqali) tekshiriladi.
 */

function makeIncrementRecorder() {
  return (amount) => ({ __op: "increment", amount });
}

/**
 * Kunlik yig'ma yozuvga (`orderRollups/{date}`) qilingan `.set()`
 * chaqiruvlarini eslab qoladigan, va tannarx/mahsulot qidiruvlarini
 * ta'minlaydigan minimal, lekin izchil mock Firestore.
 */
function buildMockDb({
  orderCostsData = {}, // orderId -> {items: [...]}
  productCostPrices = {}, // productId -> costPrice
  existingCustomer = null, // customer rollup doc mavjud holati
} = {}) {
  const dailyRollupWrites = []; // [{sellerId, dateKey, data}]
  const customerWrites = []; // [{sellerId, clientId, data|deleted}]
  const ordersCreatedWrites = [];

  const sellersCollection = (sellerId) => ({
    collection: (subName) => {
      if (subName === "orderCosts") {
        return {
          doc: (orderId) => ({
            get: async () => (orderCostsData[orderId]
              ? { exists: true, data: () => orderCostsData[orderId] }
              : { exists: false }),
          }),
        };
      }
      if (subName === "orderRollups") {
        return {
          doc: (dateKey) => ({
            set: async (data, opts) => {
              const isIncrementCall = data.revenue !== undefined || data.cogs !== undefined || data.deliveredCount !== undefined;
              if (isIncrementCall) {
                dailyRollupWrites.push({ sellerId, dateKey, data, opts });
              } else {
                ordersCreatedWrites.push({ sellerId, dateKey, data, opts });
              }
            },
          }),
        };
      }
      if (subName === "customers") {
        return {
          doc: (clientId) => ({ __sellerId: sellerId, __clientId: clientId }),
        };
      }
      return { doc: () => ({ get: async () => ({ exists: false }) }) };
    },
  });

  const db = {
    collection: (name) => {
      if (name === "sellers") {
        return { doc: (sellerId) => sellersCollection(sellerId) };
      }
      if (name === "products") {
        return {
          doc: (id) => ({
            get: async () => (productCostPrices[id] !== undefined
              ? { exists: true, data: () => ({ costPrice: productCostPrices[id] }) }
              : { exists: false }),
          }),
        };
      }
      return { doc: () => ({ get: async () => ({ exists: false }) }) };
    },
    runTransaction: async (callback) => {
      const tx = {
        get: async (ref) => (existingCustomer
          ? { exists: true, data: () => existingCustomer }
          : { exists: false }),
        set: (ref, data) => customerWrites.push({ sellerId: ref.__sellerId, clientId: ref.__clientId, data }),
        delete: (ref) => customerWrites.push({ sellerId: ref.__sellerId, clientId: ref.__clientId, deleted: true }),
      };
      return callback(tx);
    },
    __dailyRollupWrites: dailyRollupWrites,
    __customerWrites: customerWrites,
    __ordersCreatedWrites: ordersCreatedWrites,
  };

  return db;
}

function loadModule(db) {
  jest.resetModules();
  jest.doMock("../lib/admin", () => ({
    admin: {
      firestore: {
        FieldValue: {
          increment: makeIncrementRecorder(),
          serverTimestamp: () => "MOCK_TS",
        },
      },
    },
    db,
  }));
  jest.doMock("../lib/rateLimit", () => ({ checkRateLimit: jest.fn(async () => undefined) }));
  return require("../orderRollups");
}

const makeOrderData = (overrides = {}) => ({
  sellerId: "seller-1",
  clientId: "client-1",
  totalAmount: 100_000,
  status: "delivered",
  orders: [{ id: "p1", quantity: 2 }],
  customer: { fullName: "Ali", phone: "+998901112233" },
  createdAt: { toMillis: () => new Date("2026-01-01T12:00:00+05:00").getTime() },
  ...overrides,
});

function makeEvent({ before, after, orderId = "order-1" }) {
  return {
    params: { orderId },
    data: {
      before: before ? { exists: true, data: () => before } : { exists: false },
      after: after ? { exists: true, data: () => after } : { exists: false },
    },
  };
}

describe("handleOrderRollupWrite", () => {
  test("buyurtma YANGI yaratilganda (before yo'q) - kunlik 'yaratilgan buyurtmalar' sonini oshiradi", async () => {
    const db = buildMockDb();
    const { _testables } = loadModule(db);
    const order = makeOrderData({ status: "new" });
    await _testables.handleOrderRollupWrite(makeEvent({ before: null, after: order }));

    expect(db.__ordersCreatedWrites).toHaveLength(1);
    expect(db.__ordersCreatedWrites[0].dateKey).toBe("2026-01-01");
    // Status hali "delivered" emas - rollup summasiga (revenue/cogs) tegilmaydi.
    expect(db.__dailyRollupWrites).toHaveLength(0);
  });

  test("status 'delivered'ga o'tganda - kunlik daromad/tannarxni SURATGA OLINGAN qiymatdan to'g'ri oshiradi", async () => {
    const db = buildMockDb({ orderCostsData: { "order-1": { items: [{ id: "p1", quantity: 2, costPrice: 15_000 }] } } });
    const { _testables } = loadModule(db);
    const before = makeOrderData({ status: "pending" });
    const after = makeOrderData({ status: "delivered" });
    await _testables.handleOrderRollupWrite(makeEvent({ before, after }));

    expect(db.__dailyRollupWrites).toHaveLength(1);
    const write = db.__dailyRollupWrites[0];
    expect(write.dateKey).toBe("2026-01-01");
    expect(write.data.revenue).toEqual({ __op: "increment", amount: 100_000 });
    expect(write.data.cogs).toEqual({ __op: "increment", amount: 30_000 }); // 2 * 15,000
    expect(write.data.deliveredCount).toEqual({ __op: "increment", amount: 1 });
  });

  test("costPrice SURATGA OLINMAGAN (eski buyurtma) - JORIY mahsulot tannarxidan foydalanadi", async () => {
    const db = buildMockDb({ productCostPrices: { p1: 8_000 } }); // orderCosts hujjati YO'Q
    const { _testables } = loadModule(db);
    const before = makeOrderData({ status: "pending" });
    const after = makeOrderData({ status: "delivered" });
    await _testables.handleOrderRollupWrite(makeEvent({ before, after }));

    const write = db.__dailyRollupWrites[0];
    expect(write.data.cogs).toEqual({ __op: "increment", amount: 16_000 }); // 2 * 8,000
  });

  test("'delivered'dan CHIQARILGANDA (bekor qilish) - SALBIY delta yuboradi", async () => {
    const db = buildMockDb({ orderCostsData: { "order-1": { items: [{ id: "p1", quantity: 2, costPrice: 15_000 }] } } });
    const { _testables } = loadModule(db);
    const before = makeOrderData({ status: "delivered" });
    const after = makeOrderData({ status: "cancel" });
    await _testables.handleOrderRollupWrite(makeEvent({ before, after }));

    const write = db.__dailyRollupWrites[0];
    expect(write.data.revenue).toEqual({ __op: "increment", amount: -100_000 });
    expect(write.data.deliveredCount).toEqual({ __op: "increment", amount: -1 });
  });

  test("status O'ZGARMAGAN yozuv (masalan faqat boshqa maydon) - rollup'ga TEGMAYDI", async () => {
    const db = buildMockDb();
    const { _testables } = loadModule(db);
    const before = makeOrderData({ status: "delivered" });
    const after = makeOrderData({ status: "delivered" }); // hali ham delivered
    await _testables.handleOrderRollupWrite(makeEvent({ before, after }));

    expect(db.__dailyRollupWrites).toHaveLength(0);
  });

  test("mijoz yig'ma yozuvini (customers/{clientId}) ham TRANZAKSIYA ichida yangilaydi", async () => {
    const db = buildMockDb({ orderCostsData: { "order-1": { items: [{ id: "p1", quantity: 2, costPrice: 15_000 }] } } });
    const { _testables } = loadModule(db);
    const before = makeOrderData({ status: "pending" });
    const after = makeOrderData({ status: "delivered" });
    await _testables.handleOrderRollupWrite(makeEvent({ before, after }));

    expect(db.__customerWrites).toHaveLength(1);
    expect(db.__customerWrites[0].clientId).toBe("client-1");
    expect(db.__customerWrites[0].data.ltv).toBe(100_000);
    expect(db.__customerWrites[0].data.orderCount).toBe(1);
  });
});

describe("handleBackfillSellerRollups", () => {
  function buildBackfillMockDb({ orders = [], products = {} } = {}) {
    const dailyBatchWrites = [];
    const customerBatchWrites = [];
    const sellerUpdates = [];

    const ordersQuery = {
      orderBy: () => ordersQuery,
      limit: () => ordersQuery,
      startAfter: () => ({ ...ordersQuery, get: async () => ({ empty: true, docs: [] }) }),
      get: async () => ({
        empty: orders.length === 0,
        docs: orders.map((o, i) => ({ id: `order-${i}`, data: () => o })),
      }),
    };

    return {
      collection: (name) => {
        if (name === "products") {
          return {
            where: () => ({
              get: async () => ({
                forEach: (cb) => Object.entries(products).forEach(([id, costPrice]) => cb({ id, data: () => ({ costPrice }) })),
              }),
            }),
          };
        }
        if (name === "orders") {
          return { where: () => ordersQuery };
        }
        if (name === "sellers") {
          return {
            doc: (sellerId) => ({
              set: async (data) => sellerUpdates.push({ sellerId, data }),
              collection: (subName) => ({
                doc: (docId) => ({ __sub: subName, __sellerId: sellerId, __docId: docId }),
              }),
            }),
          };
        }
        return { doc: () => ({ get: async () => ({ exists: false }) }) };
      },
      batch: () => {
        const writes = [];
        return {
          set: (ref, data) => writes.push({ ref, data }),
          commit: async () => {
            writes.forEach((w) => {
              if (w.ref.__sub === "orderRollups") dailyBatchWrites.push(w);
              if (w.ref.__sub === "customers") customerBatchWrites.push(w);
            });
          },
        };
      },
      __dailyBatchWrites: dailyBatchWrites,
      __customerBatchWrites: customerBatchWrites,
      __sellerUpdates: sellerUpdates,
    };
  }

  test("faqat 'delivered' buyurtmalarni daromad/tannarxga qo'shadi, boshqa holatlarni FAQAT faoliyat sanog'iga", async () => {
    const orders = [
      makeOrderData({ status: "delivered", totalAmount: 100_000, orders: [{ id: "p1", quantity: 1 }] }),
      makeOrderData({ status: "pending", totalAmount: 500_000 }),
    ];
    const db = buildBackfillMockDb({ orders, products: { p1: 10_000 } });
    jest.resetModules();
    jest.doMock("../lib/admin", () => ({
      admin: { firestore: { FieldValue: { increment: makeIncrementRecorder(), serverTimestamp: () => "MOCK_TS" } } },
      db,
    }));
    jest.doMock("../lib/rateLimit", () => ({ checkRateLimit: jest.fn(async () => undefined) }));
    const { _testables } = require("../orderRollups");

    const result = await _testables.handleBackfillSellerRollups({ auth: { uid: "seller-1" }, data: { sellerId: "seller-1" } });

    expect(result.ordersProcessed).toBe(2);
    expect(db.__dailyBatchWrites).toHaveLength(1); // ikkalasi ham bir kunga tegishli
    const dayWrite = db.__dailyBatchWrites[0].data;
    expect(dayWrite.revenue).toBe(100_000); // faqat delivered
    expect(dayWrite.cogs).toBe(10_000);
    expect(dayWrite.deliveredCount).toBe(1);
    expect(dayWrite.ordersCreatedCount).toBe(2); // barcha holat
    // Migratsiya yakunida sotuvchi hujjatiga bayroq yoziladi:
    expect(db.__sellerUpdates).toHaveLength(1);
    expect(db.__sellerUpdates[0].sellerId).toBe("seller-1");
  });

  test("o'z do'koni bo'lmagan sotuvchi uchun ishga tushirishga URINISHNI rad etadi", async () => {
    const db = buildBackfillMockDb({ orders: [] });
    jest.resetModules();
    jest.doMock("../lib/admin", () => ({
      admin: { firestore: { FieldValue: { increment: makeIncrementRecorder(), serverTimestamp: () => "MOCK_TS" } } },
      db,
    }));
    jest.doMock("../lib/rateLimit", () => ({ checkRateLimit: jest.fn(async () => undefined) }));
    const { _testables } = require("../orderRollups");

    await expect(
      _testables.handleBackfillSellerRollups({ auth: { uid: "seller-1" }, data: { sellerId: "seller-2" } })
    ).rejects.toThrow();
  });
});
