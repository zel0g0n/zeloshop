/**
 * `orders.js` (createOrder) uchun testlar.
 *
 * Bu — pul bilan bog'liq eng muhim funksiya: mijoz yuborgan narx/
 * chegirmaga ISHONMASDAN, HAQIQIY Firestore ma'lumotidan qayta
 * hisoblashini tekshiradi. Haqiqiy Firestore'ga ulanmaydi — Firestore
 * TRANSACTION'ning o'zi soddalashtirilgan holda taqlid qilinadi.
 */

// MUHIM: `lib/sentry.js`ni soxtalashtiramiz (batafsil izoh:
// `aiCeo.test.js`).
jest.mock("../lib/sentry", () => ({
  withSentry: (fn) => fn,
  SENTRY_DSN: { value: () => null },
  Sentry: { captureException: jest.fn() },
  initSentry: jest.fn(),
}));

/**
 * Yo'l (path) asosidagi soddalashtirilgan Firestore taqlidchisi.
 * `firestore.collection(a).doc(b).collection(c).doc(d)` kabi
 * zanjirlarni, va Transaction'ning get/set/update amallarini
 * qo'llab-quvvatlaydi.
 */
function buildMockFirestore({ products = {}, sellerData = null, coupons = {}, clientData = null, orderCounterValue = null } = {}) {
  const setCalls = [];
  const updateCalls = [];
  const deleteCalls = [];
  let autoIdCounter = 0;

  function lookup(path) {
    // path masalan: ["products", "prod1"] yoki ["sellers", "s1", "coupons", "SALE10"]
    if (path[0] === "products" && path.length === 2) {
      const p = products[path[1]];
      return p ? { exists: true, id: path[1], data: () => p } : { exists: false, id: path[1] };
    }
    if (path[0] === "sellers" && path.length === 2) {
      return sellerData
        ? { exists: true, id: path[1], data: () => sellerData }
        : { exists: false, id: path[1] };
    }
    if (path[0] === "sellers" && path[2] === "coupons" && path.length === 4) {
      const c = coupons[path[3]];
      return c ? { exists: true, id: path[3], data: () => c } : { exists: false, id: path[3] };
    }
    // Referal mukofoti xabarini yuborishda bot token'ini tanlash uchun
    // so'raladi - testlarda har doim "custom bot yo'q" (umumiy BOT_TOKEN
    // ishlatiladi) holatini taqlid qilamiz.
    if (path[0] === "sellers" && path[2] === "private" && path[3] === "customerBot") {
      return { exists: false };
    }
    // Referal dasturi uchun - mijoz "kimdan taklif qilingan"ligini shu
    // yerdan bilib oladi.
    if (path[0] === "clients" && path.length === 2) {
      return clientData ? { exists: true, id: path[1], data: () => clientData } : { exists: false, id: path[1] };
    }
    // HAQIQIY, doimiy buyurtma tartib raqami uchun hisoblagich.
    if (path[0] === "sellers" && path[2] === "counters" && path[3] === "orders") {
      return orderCounterValue !== null
        ? { exists: true, data: () => ({ count: orderCounterValue }) }
        : { exists: false };
    }
    return { exists: false };
  }

  function makeDocRef(path) {
    return {
      __path: path,
      id: path[path.length - 1],
      collection: (name) => makeCollectionRef([...path, name]),
      get: async () => lookup(path),
    };
  }
  function makeCollectionRef(path) {
    return {
      doc: (id) => makeDocRef([...path, id || `auto-id-${autoIdCounter++}`]),
      // MUHIM: `logNotification` (bildirishnoma jurnali) endi
      // `.add(...)` chaqiradi - bu metod avval bu yerda YO'Q edi.
      // Haqiqiy hujjat yaratish shart emas (testlar buni
      // tekshirmaydi), faqat kuzatuv uchun ro'yxatga qo'shamiz.
      add: async (data) => {
        const ref = makeDocRef([...path, `auto-id-${autoIdCounter++}`]);
        setCalls.push({ path: ref.__path, data });
        return ref;
      },
    };
  }

  const firestore = {
    collection: (name) => makeCollectionRef([name]),
    runTransaction: async (callback) => {
      const transaction = {
        get: async (ref) => lookup(ref.__path),
        set: (ref, data) => setCalls.push({ path: ref.__path, data }),
        update: (ref, data) => updateCalls.push({ path: ref.__path, data }),
        // MUHIM: `orders.js` endi buyurtma yaratilganda "tashlab
        // ketilgan savat" hujjatini `transaction.delete(...)` orqali
        // o'chiradi - bu metod avval bu yerda YO'Q edi, shuning
        // uchun HAR BIR test "transaction.delete is not a function"
        // xatosi bilan buzilardi. Haqiqiy Firestore'da mavjud
        // bo'lmagan hujjatni o'chirish xavfsiz (no-op) - bu yerda ham
        // xuddi shunday, faqat kuzatuv uchun ro'yxatga qo'shamiz.
        delete: (ref) => deleteCalls.push({ path: ref.__path }),
      };
      return callback(transaction);
    },
  };

  return { firestore, setCalls, updateCalls, deleteCalls };
}

function loadOrdersModule(firestore) {
  jest.resetModules();
  jest.doMock("../lib/admin", () => ({
    admin: {
      firestore: Object.assign(() => firestore, {
        FieldValue: { serverTimestamp: () => "SERVER_TIMESTAMP", increment: (n) => ({ __increment: n }) },
      }),
    },
    db: firestore,
    BOT_TOKEN: { value: () => "mock" },
    GEMINI_API_KEY: { value: () => "mock" },
  }));
  const sendTelegramMessage = jest.fn().mockResolvedValue(undefined);
  jest.doMock("../lib/helpers", () => ({ sendTelegramMessage }));
  const ordersModule = require("../orders");
  return { ...ordersModule, __mocks: { sendTelegramMessage } };
}

const baseCustomerData = { fullName: "Test Mijoz", phone: "+998901234567" };
const baseRequest = (overrides = {}) => ({
  auth: { uid: "client-1" },
  data: {
    sellerId: "seller-1",
    customerData: baseCustomerData,
    items: [{ productId: "prod-1", quantity: 2 }],
    ...overrides,
  },
});

describe("createOrder", () => {
  test("HAQIQIY mahsulot narxidan hisoblaydi — mijoz narx yubormaydi va yuborsa ham e'tiborga olinmaydi", async () => {
    const { firestore } = buildMockFirestore({
      products: { "prod-1": { sellerId: "seller-1", name: "Krem", price: 50000, stock: 10 } },
      sellerData: { storeName: "Do'kon" },
    });
    const { _testables } = loadOrdersModule(firestore);

    const result = await _testables.handleCreateOrder(baseRequest());

    // 2 dona * 50,000 = 100,000 — mijoz boshqa narx "yuborgan" bo'lsa ham,
    // bu yerda HAQIQIY Firestore narxidan hisoblanadi (chunki mijoz
    // umuman narx yubormaydi — faqat ID va sonni).
    expect(result.totalAmount).toBe(100000);
    expect(result.subtotal).toBe(100000);
  });

  // REGRESSIYA TESTI (real P&L uchun yangi funksiya): har bir
  // buyurtma qatorining TANNARXI endi ALOHIDA, faqat sotuvchi o'qiy
  // oladigan `sellers/{id}/orderCosts/{orderId}` hujjatiga
  // yoziladi - `orders/{orderId}`ning O'ZIGA EMAS (xaridor buni
  // o'qiy olmasligi kerak, batafsil izoh: `orders.js`).
  test("tannarx (costPrice) suratini ALOHIDA, faqat sotuvchi o'qiydigan hujjatga yozadi - mijozga ko'rinadigan buyurtma qatoriga EMAS", async () => {
    const { firestore, setCalls } = buildMockFirestore({
      products: { "prod-1": { sellerId: "seller-1", name: "Krem", price: 50000, costPrice: 20000, stock: 10 } },
      sellerData: { storeName: "Do'kon" },
    });
    const { _testables } = loadOrdersModule(firestore);

    const result = await _testables.handleCreateOrder(baseRequest());

    const orderWrite = setCalls.find((c) => c.path.join("/") === `orders/${result.orderId}`);
    expect(orderWrite).toBeDefined();
    // Mijozga ham ko'rinadigan hujjatda costPrice UMUMAN bo'lmasligi kerak:
    expect(orderWrite.data.orders[0].costPrice).toBeUndefined();

    const costWrite = setCalls.find((c) => c.path.join("/") === `sellers/seller-1/orderCosts/${result.orderId}`);
    expect(costWrite).toBeDefined();
    expect(costWrite.data.items).toEqual([{ id: "prod-1", costPrice: 20000, quantity: 2 }]);
  });

  test("hisoblagich hali mavjud bo'lmasa (birinchi buyurtma) - orderNumber 1 bo'ladi", async () => {
    const { firestore } = buildMockFirestore({
      products: { "prod-1": { sellerId: "seller-1", name: "Krem", price: 50000, stock: 10 } },
      sellerData: { storeName: "Do'kon" },
      orderCounterValue: null, // hisoblagich hali yaratilmagan
    });
    const { _testables } = loadOrdersModule(firestore);

    const result = await _testables.handleCreateOrder(baseRequest());

    expect(result.orderNumber).toBe(1);
  });

  test("hisoblagich mavjud bo'lsa (masalan 41 ta buyurtma bo'lgan) - keyingi buyurtma 42-raqamni oladi", async () => {
    const { firestore, setCalls } = buildMockFirestore({
      products: { "prod-1": { sellerId: "seller-1", name: "Krem", price: 50000, stock: 10 } },
      sellerData: { storeName: "Do'kon" },
      orderCounterValue: 41,
    });
    const { _testables } = loadOrdersModule(firestore);

    const result = await _testables.handleCreateOrder(baseRequest());

    expect(result.orderNumber).toBe(42);

    // MUHIM: hisoblagichning O'ZI ham 42ga YANGILANGANINI tasdiqlaymiz -
    // aks holda keyingi buyurtma xato raqam olardi.
    const counterUpdate = setCalls.find((c) => c.path.join("/") === "sellers/seller-1/counters/orders");
    expect(counterUpdate).toBeDefined();
    expect(counterUpdate.data.count).toBe(42);
  });

  test("orderNumber - 150 talik yuklash chegarasidan MUSTAQIL, sahifalashga bog'liq emas (haqiqiy, doimiy raqam)", async () => {
    // Bu test shuni tasdiqlaydi: hisoblagich 150dan HAM KATTA
    // qiymatdan boshlansa ham (masalan do'konda 500 ta buyurtma
    // bo'lsa), tizim to'g'ri ishlashda davom etadi - chunki raqam
    // HAR DOIM Firestore hujjatining o'zida saqlanadi, hech qanday
    // ro'yxat uzunligiga BOG'LIQ EMAS.
    const { firestore } = buildMockFirestore({
      products: { "prod-1": { sellerId: "seller-1", name: "Krem", price: 50000, stock: 10 } },
      sellerData: { storeName: "Do'kon" },
      orderCounterValue: 500,
    });
    const { _testables } = loadOrdersModule(firestore);

    const result = await _testables.handleCreateOrder(baseRequest());

    expect(result.orderNumber).toBe(501);
  });

  test("yetkazib berish: mijoz sotuvchi bilan BIR XIL hududda bo'lsa, 'sameCity' bosqichi narxi qo'llaniladi", async () => {
    const { firestore } = buildMockFirestore({
      products: { "prod-1": { sellerId: "seller-1", name: "Krem", price: 50000, stock: 10 } },
      sellerData: {
        storeName: "Do'kon",
        region: "Xorazm",
        deliveryTiers: {
          sameCity: { price: 15000, days: "days1_2" },
          otherRegions: { price: 40000, days: "days3_5" },
        },
      },
    });
    const { _testables } = loadOrdersModule(firestore);

    const result = await _testables.handleCreateOrder(baseRequest({ customerRegion: "Xorazm" }));

    expect(result.deliveryZone.tier).toBe("sameCity");
    expect(result.deliveryZone.price).toBe(15000);
    expect(result.totalAmount).toBe(100000 + 15000);
  });

  test("yetkazib berish: mijoz BOSHQA viloyatda bo'lsa, 'otherRegions' bosqichi narxi qo'llaniladi", async () => {
    const { firestore } = buildMockFirestore({
      products: { "prod-1": { sellerId: "seller-1", name: "Krem", price: 50000, stock: 10 } },
      sellerData: {
        storeName: "Do'kon",
        region: "Xorazm",
        deliveryTiers: {
          sameCity: { price: 15000, days: "days1_2" },
          otherRegions: { price: 40000, days: "days3_5" },
        },
      },
    });
    const { _testables } = loadOrdersModule(firestore);

    const result = await _testables.handleCreateOrder(baseRequest({ customerRegion: "Andijon" }));

    expect(result.deliveryZone.tier).toBe("otherRegions");
    expect(result.deliveryZone.price).toBe(40000);
  });

  test("yetkazib berish: Toshkent shahri (sotuvchi) + Toshkent viloyati (mijoz) - 'sameRegionDistricts' bosqichi", async () => {
    const { firestore } = buildMockFirestore({
      products: { "prod-1": { sellerId: "seller-1", name: "Krem", price: 50000, stock: 10 } },
      sellerData: {
        storeName: "Do'kon",
        region: "Toshkent shahri",
        deliveryTiers: {
          sameCity: { price: 10000, days: "days1_2" },
          sameRegionDistricts: { price: 20000, days: "days2_3" },
          otherRegions: { price: 40000, days: "days3_5" },
        },
      },
    });
    const { _testables } = loadOrdersModule(firestore);

    const result = await _testables.handleCreateOrder(baseRequest({ customerRegion: "Toshkent viloyati" }));

    expect(result.deliveryZone.tier).toBe("sameRegionDistricts");
    expect(result.deliveryZone.price).toBe(20000);
  });

  test("yetkazib berish: MIJOZ hech qanday narx yubormasa ham (faqat hudud), SERVER haqiqiy narxni O'ZI hisoblaydi - mijoz narx yubormaydi/yubora olmaydi", async () => {
    // Bu test - eng MUHIM xavfsizlik tekshiruvi: mijoz so'rovida
    // narx UMUMAN yo'q (faqat hudud nomi bor) - server buni HECH
    // QACHON ishonib qabul qilmaydi, har doim sotuvchining haqiqiy
    // sozlamasidan QAYTA hisoblaydi.
    const { firestore } = buildMockFirestore({
      products: { "prod-1": { sellerId: "seller-1", name: "Krem", price: 50000, stock: 10 } },
      sellerData: {
        storeName: "Do'kon",
        region: "Xorazm",
        deliveryTiers: { sameCity: { price: 99999, days: "days1_2" } },
      },
    });
    const { _testables } = loadOrdersModule(firestore);
    const request = baseRequest({ customerRegion: "Xorazm" });
    // Mijoz so'rovida (haqiqiy ilovada bo'lmasligi kerak bo'lgan)
    // narx maydoni bo'lsa ham, SERVER buni E'TIBORGA OLMAYDI.
    request.data.deliveryFee = 1;

    const result = await _testables.handleCreateOrder(request);

    expect(result.deliveryZone.price).toBe(99999);
  });

  test("sotuvchi hech qanday hudud belgilamagan (region yo'q) bo'lsa, yetkazib berish narxi 0 bo'ladi, xato bermaydi", async () => {
    const { firestore } = buildMockFirestore({
      products: { "prod-1": { sellerId: "seller-1", name: "Krem", price: 50000, stock: 10 } },
      sellerData: { storeName: "Do'kon" }, // region yo'q
    });
    const { _testables } = loadOrdersModule(firestore);

    const result = await _testables.handleCreateOrder(baseRequest({ customerRegion: "Xorazm" }));

    expect(result.deliveryZone).toBeNull();
    expect(result.totalAmount).toBe(100000);
  });

  test("ombor qoldig'ini KAMAYTIRADI va 'sotilganlar' sonini BIR VAQTDA oshiradi", async () => {
    const { firestore, updateCalls } = buildMockFirestore({
      products: { "prod-1": { sellerId: "seller-1", name: "Krem", price: 50000, stock: 10 } },
      sellerData: { storeName: "Do'kon" },
    });
    const { _testables } = loadOrdersModule(firestore);

    await _testables.handleCreateOrder(baseRequest());

    // baseRequest() 2 dona buyurtma qiladi — ombor 10dan 8ga kamayishi,
    // "sotilganlar" esa 2ga OSHISHI kerak (avval bu SODIR BO'LMAS edi).
    const productUpdate = updateCalls.find((c) => c.path[0] === "products");
    expect(productUpdate.data.stock).toBe(8);
    expect(productUpdate.data.sold).toEqual({ __increment: 2 });
  });

  test("buyurtma yaratilganda, mos savat hujjatini o'chirishga urinadi (tashlab ketilgan savat eslatmasi qayta ishga tushmasligi uchun)", async () => {
    const { firestore, deleteCalls } = buildMockFirestore({
      products: { "prod-1": { sellerId: "seller-1", name: "Krem", price: 50000, stock: 10 } },
      sellerData: { storeName: "Do'kon" },
    });
    const { _testables } = loadOrdersModule(firestore);

    await _testables.handleCreateOrder(baseRequest());

    // baseRequest() clientId="client-1", sellerId="seller-1" bilan
    // ishlaydi - savat hujjati ID'si shu ikkisidan tuziladi.
    const cartDelete = deleteCalls.find((c) => c.path.join("/") === "carts/seller-1_client-1");
    expect(cartDelete).toBeDefined();
  });

  test("chegirma narxi (discountPrice) mavjud bo'lsa, o'shani ishlatishi kerak", async () => {
    const { firestore } = buildMockFirestore({
      products: { "prod-1": { sellerId: "seller-1", name: "Krem", price: 50000, discountPrice: 40000, stock: 10 } },
      sellerData: {},
    });
    const { _testables } = loadOrdersModule(firestore);

    const result = await _testables.handleCreateOrder(baseRequest());

    expect(result.totalAmount).toBe(80000); // 2 * 40,000
  });

  test("ombor yetarli bo'lmasa, 'failed-precondition' xatosi bilan rad etishi kerak", async () => {
    const { firestore } = buildMockFirestore({
      products: { "prod-1": { sellerId: "seller-1", name: "Krem", price: 50000, stock: 1 } }, // faqat 1 ta bor
      sellerData: {},
    });
    const { _testables } = loadOrdersModule(firestore);

    await expect(_testables.handleCreateOrder(baseRequest())).rejects.toMatchObject({
      code: "failed-precondition",
    });
  });

  test("boshqa do'konning mahsuloti savatga tushib qolsa, rad etishi kerak", async () => {
    const { firestore } = buildMockFirestore({
      products: { "prod-1": { sellerId: "BOSHQA-DOKON", name: "Krem", price: 50000, stock: 10 } },
      sellerData: {},
    });
    const { _testables } = loadOrdersModule(firestore);

    await expect(_testables.handleCreateOrder(baseRequest())).rejects.toMatchObject({
      code: "invalid-argument",
    });
  });

  test("promokod HAQIQIY qoidalar bo'yicha tekshiriladi — noto'g'ri kod rad etilishi kerak", async () => {
    const { firestore } = buildMockFirestore({
      products: { "prod-1": { sellerId: "seller-1", name: "Krem", price: 50000, stock: 10 } },
      sellerData: {},
      coupons: {},
    });
    const { _testables } = loadOrdersModule(firestore);

    await expect(
      _testables.handleCreateOrder(baseRequest({ couponCode: "YOQKOD" }))
    ).rejects.toMatchObject({ code: "not-found" });
  });

  test("haqiqiy, faol promokod — to'g'ri chegirmani qo'llashi kerak", async () => {
    const { firestore } = buildMockFirestore({
      products: { "prod-1": { sellerId: "seller-1", name: "Krem", price: 50000, stock: 10 } },
      sellerData: {},
      coupons: { SALE10: { isActive: true, discountType: "percent", discountValue: 10, usedCount: 0 } },
    });
    const { _testables } = loadOrdersModule(firestore);

    const result = await _testables.handleCreateOrder(baseRequest({ couponCode: "sale10" })); // kichik harf bilan ham ishlashi kerak

    expect(result.discountAmount).toBe(10000); // 100,000ning 10%i
    expect(result.totalAmount).toBe(90000);
  });

  test("tizimga kirmagan foydalanuvchi rad etilishi kerak", async () => {
    const { firestore } = buildMockFirestore({});
    const { _testables } = loadOrdersModule(firestore);

    await expect(
      _testables.handleCreateOrder({ auth: null, data: {} })
    ).rejects.toMatchObject({ code: "unauthenticated" });
  });

  test("referal sharti bajarilganda - mukofot promokodi yaratiladi VA taklif qiluvchiga Telegram xabari yuboriladi", async () => {
    const { firestore } = buildMockFirestore({
      products: { "prod-1": { sellerId: "seller-1", name: "Krem", price: 50000, stock: 10 } },
      sellerData: { storeName: "Zelo" }, // referralProgramEnabled ko'rsatilmagan -> standart bo'yicha YOQILGAN
      clientData: { referredBy: "referrer-1", referredForSellerId: "seller-1" },
    });
    const { _testables, __mocks } = loadOrdersModule(firestore);

    const result = await _testables.handleCreateOrder(baseRequest()); // couponCode YO'Q - referal chegirmasi qo'llanishi kerak

    expect(result.referralDiscount).toMatchObject({ referrerId: "referrer-1" });
    expect(result.referralRewardCouponCode).toMatch(/^REF-/);

    // ENG MUHIM TEKSHIRUV: xabar aynan TAKLIF QILUVCHIGA (referrer-1),
    // BUYURTMA BERGAN mijozga (client-1) EMAS, yuborilgan bo'lishi kerak.
    expect(__mocks.sendTelegramMessage).toHaveBeenCalledTimes(1);
    const [, chatId, text] = __mocks.sendTelegramMessage.mock.calls[0];
    expect(chatId).toBe("referrer-1");
    expect(text).toContain(result.referralRewardCouponCode);
  });

  test("referal sharti bajarilmasa (referredBy yo'q) - hech qanday xabar yuborilmaydi", async () => {
    const { firestore } = buildMockFirestore({
      products: { "prod-1": { sellerId: "seller-1", name: "Krem", price: 50000, stock: 10 } },
      sellerData: {},
      clientData: null, // referal orqali kelmagan oddiy mijoz
    });
    const { _testables, __mocks } = loadOrdersModule(firestore);

    await _testables.handleCreateOrder(baseRequest());

    expect(__mocks.sendTelegramMessage).not.toHaveBeenCalled();
  });
});
