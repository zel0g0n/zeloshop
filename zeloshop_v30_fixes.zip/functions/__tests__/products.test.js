/**
 * `products.js`dagi `generateSocialPost` uchun testlar.
 *
 * ASOSIY MAQSAD: bu — PREMIUM (AI CEO) funksiya, shuning uchun
 * `aiCeoEnabled !== true` bo'lgan sotuvchilar uchun Gemini so'rovi
 * HECH QACHON yuborilmasligini (xarajat nazorati) tasdiqlash - bu,
 * server tomonidagi eng muhim xavfsizlik/xarajat chegarasi.
 */

function buildMockDb({ sellerData = null } = {}) {
  return {
    collection: (name) => {
      if (name === "sellers") {
        return {
          doc: () => ({
            get: async () => (sellerData ? { exists: true, data: () => sellerData } : { exists: false }),
          }),
        };
      }
      return { doc: () => ({ get: async () => ({ exists: false }) }) };
    },
    // `checkRateLimit` ichkarida shu orqali ishlaydi - testlarda
    // hech qachon chegaraga tegmasligi uchun har doim "yangi oyna"
    // sifatida ishlov beramiz.
    runTransaction: async (callback) => callback({ get: async () => ({ exists: false }), set: () => {} }),
  };
}

function loadModule(db, generateContentMock) {
  jest.resetModules();
  jest.doMock("../lib/admin", () => ({
    db,
    GEMINI_API_KEY: { value: () => "mock-gemini-key" },
  }));
  jest.doMock("@google/genai", () => ({
    GoogleGenAI: jest.fn().mockImplementation(() => ({
      models: { generateContent: generateContentMock },
    })),
  }));
  return require("../products");
}

const baseRequest = (overrides = {}) => ({
  auth: { uid: "seller-1" },
  data: { productName: "Test krem", platform: "instagram", ...overrides },
});

describe("generateSocialPost", () => {
  test("tizimga kirmagan foydalanuvchi rad etiladi", async () => {
    const genContent = jest.fn();
    const { _testables } = loadModule(buildMockDb(), genContent);
    await expect(_testables.handleGenerateSocialPost({ auth: null, data: {} })).rejects.toThrow();
    expect(genContent).not.toHaveBeenCalled();
  });

  test("aiCeoEnabled=false bo'lgan sotuvchi rad etiladi, Gemini UMUMAN chaqirilmaydi", async () => {
    const genContent = jest.fn();
    const db = buildMockDb({ sellerData: { aiCeoEnabled: false } });
    const { _testables } = loadModule(db, genContent);

    await expect(_testables.handleGenerateSocialPost(baseRequest())).rejects.toMatchObject({ code: "permission-denied" });
    expect(genContent).not.toHaveBeenCalled();
  });

  test("aiCeoEnabled maydoni umuman yo'q (aniqlanmagan) sotuvchi ham rad etiladi", async () => {
    const genContent = jest.fn();
    const db = buildMockDb({ sellerData: { storeName: "Do'kon" } }); // aiCeoEnabled yo'q
    const { _testables } = loadModule(db, genContent);

    await expect(_testables.handleGenerateSocialPost(baseRequest())).rejects.toMatchObject({ code: "permission-denied" });
    expect(genContent).not.toHaveBeenCalled();
  });

  test("sotuvchi hujjati umuman topilmasa ham rad etiladi", async () => {
    const genContent = jest.fn();
    const db = buildMockDb({ sellerData: null });
    const { _testables } = loadModule(db, genContent);

    await expect(_testables.handleGenerateSocialPost(baseRequest())).rejects.toMatchObject({ code: "permission-denied" });
  });

  test("aiCeoEnabled=true bo'lgan sotuvchi uchun Gemini chaqiriladi va post matni qaytariladi", async () => {
    const genContent = jest.fn().mockResolvedValue({ text: "Ajoyib krem! #toshkent #onlayndokon" });
    const db = buildMockDb({ sellerData: { aiCeoEnabled: true } });
    const { _testables } = loadModule(db, genContent);

    const result = await _testables.handleGenerateSocialPost(baseRequest());

    expect(genContent).toHaveBeenCalledTimes(1);
    expect(result.postText).toBe("Ajoyib krem! #toshkent #onlayndokon");
  });

  test("mahsulot nomi bo'lmasa, premium bo'lsa ham rad etiladi", async () => {
    const genContent = jest.fn();
    const db = buildMockDb({ sellerData: { aiCeoEnabled: true } });
    const { _testables } = loadModule(db, genContent);

    await expect(_testables.handleGenerateSocialPost(baseRequest({ productName: "" }))).rejects.toMatchObject({ code: "invalid-argument" });
    expect(genContent).not.toHaveBeenCalled();
  });
});
