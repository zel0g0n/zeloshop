const { onSchedule } = require("firebase-functions/v2/scheduler");
const { admin, db, BOT_TOKEN } = require("./lib/admin");
const { sendTelegramMessage } = require("./lib/helpers");
const { incrementDailyStat, logNotification } = require("./lib/dailyStats");

/**
 * "TASHLAB KETILGAN SAVAT" ESLATMASI.
 *
 * MARKETING MAQSADI: xaridor mahsulotlarni savatga qo'shib, lekin
 * buyurtma bermay ketsa - bu, e-commerce'da eng oson qaytarib
 * bo'ladigan yo'qotilgan sotuv hisoblanadi (statistik jihatdan,
 * o'rtacha 10-15% qaytariladi). Bu funksiya shuni avtomatlashtiradi.
 *
 * ISHLASH TARTIBI: har 30 daqiqada, "faol" (status="active") va
 * SO'NGGI 2 SOATDAN BERI o'zgarmagan savatlarni qidiradi, ularning
 * egalariga Telegram orqali eslatma yuboradi (ixtiyoriy - bir martalik
 * "qaytarish" chegirmasi bilan birga), va holatni "reminded" ga
 * o'zgartiradi - SHU SAVAT uchun ikkinchi marta eslatma YUBORILMAYDI
 * (agar mijoz qaytib savatni yana o'zgartirmasa - bu holda
 * `syncCart.js` uni yana "active"ga qaytaradi, va jarayon TABIIY
 * ravishda qayta boshlanadi).
 *
 * FIREBASE XARAJATI: bitta so'rov (`.where("status","==","active")
 * .where("updatedAt","<=",cutoff)`) - natijada qaytgan hujjatlar soni
 * qancha bo'lishidan qat'i nazar, bu BITTA so'rov. Har bir mos
 * kelgan savat uchun (odatda kam sonli) bitta Telegram xabari va
 * bitta Firestore yozuvi - barchasi chegaralangan, nazorat ostida.
 */
const CART_ABANDON_HOURS = 2;
const formatMoney = (n) => `${Math.round(n).toLocaleString()} so'm`;

function generateRecoveryCouponCode() {
  return `QAYT-${Math.random().toString(36).slice(2, 8).toUpperCase()}`;
}

exports.sendAbandonedCartReminders = onSchedule(
  { schedule: "every 30 minutes", region: "asia-south1", secrets: [BOT_TOKEN] },
  async () => {
    const cutoff = admin.firestore.Timestamp.fromMillis(Date.now() - CART_ABANDON_HOURS * 60 * 60 * 1000);

    const cartsSnap = await db.collection("carts")
      .where("status", "==", "active")
      .where("updatedAt", "<=", cutoff)
      .get();

    if (cartsSnap.empty) return;

    // Bitta so'rovda BIR NECHTA turli sotuvchining savatlari
    // bo'lishi mumkin - har bir sotuvchi uchun bot tokeni/sozlamalarni
    // bir marta o'qib, keshlaymiz (bitta yugurishda bir xil
    // sotuvchini bir necha marta so'ramasligimiz uchun).
    const sellerCache = new Map();

    for (const cartDoc of cartsSnap.docs) {
      const cart = cartDoc.data();
      if (!cart.sellerId || !cart.clientId || !Array.isArray(cart.items) || cart.items.length === 0) continue;

      try {
        if (!sellerCache.has(cart.sellerId)) {
          const sellerSnap = await db.collection("sellers").doc(cart.sellerId).get();
          // MUHIM, JIDDIY TUZATISH (regressiya): mijozlarga xabar HAR
          // DOIM platformaning o'z boti orqali yuboriladi - shaxsiy
          // bot orqali EMAS (`shareLink.js` tuzatishidan keyin, mijoz
          // deyarli hech qachon shaxsiy botni ishga tushirmaydi -
          // batafsil izoh: `notifications.js`).
          sellerCache.set(cart.sellerId, {
            seller: sellerSnap.exists ? sellerSnap.data() : {},
            token: BOT_TOKEN.value(),
          });
        }
        const { seller, token } = sellerCache.get(cart.sellerId);

        // Sotuvchi bu funksiyani ATAYLAB o'chirib qo'ygan bo'lishi
        // mumkin (masalan, mijozlarni ortiqcha xabar bilan
        // charchatishni xohlamasa).
        if (seller.cartReminderEnabled === false) continue;

        const itemsList = cart.items.slice(0, 5).map((i) => `• ${i.name} x${i.quantity}`).join("\n");
        const moreCount = cart.items.length > 5 ? cart.items.length - 5 : 0;
        const total = cart.items.reduce((sum, i) => sum + (Number(i.price) || 0) * (Number(i.quantity) || 1), 0);

        let text = `Savatingizda mahsulotlar kutmoqda!\n\n${itemsList}`;
        if (moreCount > 0) text += `\n... va yana ${moreCount} ta mahsulot`;
        text += `\n\nJami: ${formatMoney(total)}`;

        // Ixtiyoriy: sotuvchi "qaytarish chegirmasi"ni yoqqan bo'lsa,
        // bir martalik promokod yaratamiz - referal dasturidagi bilan
        // BIR XIL, sinovdan o'tgan naqsh.
        const recoveryPercent = Number(seller.cartReminderDiscountPercent) || 0;
        if (recoveryPercent > 0) {
          const couponCode = generateRecoveryCouponCode();
          await db.collection("sellers").doc(cart.sellerId).collection("coupons").doc(couponCode).set({
            code: couponCode,
            discountType: "percent",
            discountValue: recoveryPercent,
            expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(), // 24 soat amal qiladi - shoshilinchlik yaratadi
            usageLimit: 1,
            usedCount: 0,
            isActive: true,
            isCartRecoveryReward: true,
            rewardForClientId: cart.clientId,
            createdAt: admin.firestore.FieldValue.serverTimestamp(),
            createdAtMs: Date.now(),
          });
          text += `\n\nBuyurtmangizni ${recoveryPercent}% chegirma bilan yakunlang!\nPromokod: ${couponCode} (24 soat amal qiladi)`;
        }

        await sendTelegramMessage(token, cart.clientId, text);
        await incrementDailyStat(cart.sellerId, "cartRemindersSent");
        await logNotification({
          sellerId: cart.sellerId, clientId: cart.clientId, type: "cartReminder",
          title: "Savat eslatmasi", message: text,
        });

        await cartDoc.ref.update({
          status: "reminded",
          reminderSentAt: admin.firestore.FieldValue.serverTimestamp(),
        });
      } catch (err) {
        console.error(`Tashlab ketilgan savat eslatmasi xatosi (${cartDoc.id}):`, err);
      }
    }
  }
);
