const { onSchedule } = require("firebase-functions/v2/scheduler");
const { admin, db, BOT_TOKEN, GEMINI_API_KEY } = require("./lib/admin");
const { sendTelegramMessage } = require("./lib/helpers");
const { incrementDailyStat, logNotification } = require("./lib/dailyStats");
// AI CEO — TIER-1 "ISHONCH ZINAPOYASI": `craftWinBackMessage`/
// `craftFavoriteReminderMessage` shu yerda, avtonom (sotuvchi tugma
// bosmasdan) eslatma matnlarini yaxshilash uchun qayta ishlatiladi.
// Batafsil izoh - pastda, tegishli funksiyalar ichida.
const { craftWinBackMessage, craftFavoriteReminderMessage } = require("./aiCeo");
// AI CEO — 7-BOSQICH ("natija kuzatuvi va o'rganish", batafsil izoh:
// `aiCeoLearning.js`): HAR BIR avtonom xabar yuborilgach `recordAiCeoOutcome`
// chaqiriladi (kim, qanday xabar oldi - keyinroq "xarid qildimi"
// tekshirish uchun), va HAR BIR AI-yozuv oldidan `getRecentAiPerformance`
// o'qiladi (AI'ning O'ZI oldingi natijasidan xabardor bo'lib yozishi
// uchun).
const { recordAiCeoOutcome, getRecentAiPerformance } = require("./aiCeoLearning");
// AI CEO — 8-BOSQICH ("avtonom harakatlar doirasini kengaytirish",
// batafsil izoh: `aiCeoAutoDiscount.js`): FAQAT `sendRepurchaseReminders`
// ichida, va FAQAT sotuvchi ALOHIDA yoqib, natija ISBOTLANGANDA
// ishlaydigan, HAQIQIY bir martalik chegirma kodi yaratuvchi.
const { maybeIssueAutoWinBackDiscount } = require("./aiCeoAutoDiscount");

/**
 * XARIDORNI QAYTARISH BILDIRISHNOMALARI — mijoz tomonida so'ralgan,
 * lekin oldin QURILMAGAN ikkita "tizim bildirishnomasi":
 *   1. "Like bosilgan mahsulotga eslatma" (sevimlilar)
 *   2. "Qayta sotib olishga taklif" (avval xarid qilingan mahsulot)
 *
 * Ikkalasi ham `carts.js`dagi "tashlab ketilgan savat" eslatmasi
 * bilan BIR XIL, allaqachon tekshirilgan naqshda qurilgan.
 */

// AI CEO — sevimlilar mahsuloti sarlavhasidan MATNGA kirituvchi qisqa
// nomlar yig'ish uchun cheklov (Gemini promptini ixcham saqlash uchun).
const MAX_FAVORITE_ITEM_NAMES_FOR_AI = 5;

const FAVORITE_REMINDER_DAYS = 3;
const REPURCHASE_REMINDER_DAYS = 30;
const formatMoney = (n) => `${Math.round(n).toLocaleString()} so'm`;

/**
 * 1) SEVIMLILAR ESLATMASI — mahsulotni "like" bosib, lekin
 * FAVORITE_REMINDER_DAYS kun ichida sotib olmagan xaridorga eslatma
 * yuboradi. Har bir sevimlilar hujjati uchun FAQAT BIR MARTA
 * (status="reminded"ga o'tkaziladi) - agar xaridor keyinroq
 * ro'yxatni yana o'zgartirsa, `syncFavorites.js` uni "active"ga
 * qaytaradi va jarayon tabiiy ravishda qayta boshlanadi.
 *
 * AI CEO — TIER-1 "ISHONCH ZINAPOYASI" (KENGAYTIRISH): xuddi pastdagi
 * `sendRepurchaseReminders` uchun qilingani kabi, FAQAT sotuvchi buni
 * ALOHIDA, ochiq-oydin yoqqan bo'lsa (`aiCeoAutoFavoriteEnabled ===
 * true`, standart holatda O'CHIQ), matnni AI CEO Gemini orqali
 * shaxsiylashtirib yozadi. Gemini xato bersa - JIM QOLIB, oddiy
 * shablonga qaytamiz, chunki eslatma YUBORILISHI AI'ning ishlashiga
 * BOG'LIQ bo'lmasligi kerak.
 */
exports.sendFavoriteReminders = onSchedule(
  { schedule: "0 12 * * *", timeZone: "Asia/Tashkent", region: "asia-south1", secrets: [BOT_TOKEN, GEMINI_API_KEY] },
  async () => {
    const cutoff = admin.firestore.Timestamp.fromMillis(Date.now() - FAVORITE_REMINDER_DAYS * 24 * 60 * 60 * 1000);

    // XAVFSIZLIK CHEGARASI (haqiqiy, o'z-o'zini qayta tekshiruv orqali
    // topilgan bo'shliq - `productDrafts.js`dagi bilan BIR XIL sinf
    // xato): bu YERGA `.limit()` qo'yilmagan bo'lsa, bir kunda juda
    // ko'p sevimlilar "eskirsa" (masalan aksiya kuni ko'p mahsulot
    // like bosilsa), funksiya ULARNING BARCHASINI, CHEKLOVSIZ qayta
    // ishlar edi - nazoratsiz Telegram xabar oqimi. Qolganlari
    // ertangi yugurishda qayta ishlanadi.
    const MAX_FAVORITES_PER_RUN = 200;

    const favSnap = await db.collection("favorites")
      .where("updatedAt", "<=", cutoff)
      .limit(MAX_FAVORITES_PER_RUN)
      .get();

    if (favSnap.empty) return;

    const sellerCache = new Map();

    for (const favDoc of favSnap.docs) {
      const fav = favDoc.data();
      // MUHIM: `status` maydoni bo'lmagan (hali eslatma yuborilmagan)
      // yoki ATAYLAB "active" bo'lgan hujjatlargina qayta ishlanadi -
      // "reminded" holatidagilar chetlab o'tiladi.
      if (fav.status === "reminded") continue;
      if (!fav.sellerId || !fav.clientId || !Array.isArray(fav.items) || fav.items.length === 0) continue;

      try {
        if (!sellerCache.has(fav.sellerId)) {
          // MUHIM, JIDDIY TUZATISH (regressiya): mijozlarga xabar HAR
          // DOIM platformaning o'z boti orqali yuboriladi (batafsil
          // izoh: `notifications.js`).
          const sellerSnap = await db.collection("sellers").doc(fav.sellerId).get();
          const seller = sellerSnap.exists ? sellerSnap.data() : {};
          // YANGI (7-BOSQICH): FAQAT AI-yozuv YOQILGAN bo'lsa o'qiladi
          // (ARZON - bitta o'qish, sotuvchi boshiga BIR MARTA, butun
          // ishga tushirish davomida keshlangan holda).
          const recentPerformance = seller.aiCeoEnabled === true && seller.aiCeoAutoFavoriteEnabled === true
            ? await getRecentAiPerformance(fav.sellerId, "favorite")
            : null;
          sellerCache.set(fav.sellerId, { seller, token: BOT_TOKEN.value(), recentPerformance });
        }
        const { seller, token, recentPerformance } = sellerCache.get(fav.sellerId);

        // Sotuvchi bu bildirishnomani o'chirib qo'ygan bo'lishi mumkin.
        if (seller.favoriteReminderEnabled === false) continue;

        const itemsList = fav.items.slice(0, 5).map((i) => `• ${i.name} — ${formatMoney(i.price)}`).join("\n");
        const moreCount = fav.items.length > 5 ? fav.items.length - 5 : 0;

        let text = `Sevimlilaringizda mahsulotlar sizni kutmoqda!\n\n${itemsList}`;
        if (moreCount > 0) text += `\n... va yana ${moreCount} ta mahsulot`;
        text += `\n\nHali ham qiziqasizmi? Ular tugab qolishi mumkin!`;
        let aiGenerated = false;

        if (seller.aiCeoEnabled === true && seller.aiCeoAutoFavoriteEnabled === true) {
          try {
            const itemNames = fav.items.slice(0, MAX_FAVORITE_ITEM_NAMES_FOR_AI).map((i) => i.name);
            const aiText = await craftFavoriteReminderMessage({ itemNames, storeName: seller.storeName, recentPerformance });
            if (aiText) {
              text = aiText;
              aiGenerated = true;
            }
          } catch (aiErr) {
            // MUHIM: AI xato bersa jim qolamiz, oddiy shablon bilan
            // davom etamiz - eslatma yuborilishi HECH QACHON AI
            // xatosiga bog'liq bo'lmasligi kerak.
            console.error(`AI sevimlilar eslatmasi yaratib bo'lmadi (${favDoc.id}), oddiy shablon ishlatiladi:`, aiErr);
          }
        }

        await sendTelegramMessage(token, fav.clientId, text);
        await incrementDailyStat(fav.sellerId, "favoriteRemindersSent");
        if (aiGenerated) {
          await incrementDailyStat(fav.sellerId, "aiCeoAutoFavoriteSent");
        }
        await logNotification({
          sellerId: fav.sellerId, clientId: fav.clientId, type: "favoriteReminder",
          title: "Sevimlilar eslatmasi", message: text,
        });
        // YANGI (7-BOSQICH): AI CEO premium sotuvchilar uchun (AI-yozuv
        // yoqilgan-yoqilmaganidan qat'i nazar - shu orqali AI vs oddiy
        // shablon natijasi KEYINCHALIK solishtiriladi), bu xabarning
        // haqiqiy natijasi ("mijoz keyinroq xarid qildimi") kuzatuvga
        // olinadi.
        if (seller.aiCeoEnabled === true) {
          await recordAiCeoOutcome({ sellerId: fav.sellerId, type: "favorite", clientId: fav.clientId, aiGenerated });
        }

        await favDoc.ref.update({
          status: "reminded",
          reminderSentAt: admin.firestore.FieldValue.serverTimestamp(),
        });
      } catch (err) {
        console.error(`Sevimlilar eslatmasi xatosi (${favDoc.id}):`, err);
      }
    }
  }
);

/**
 * 2) QAYTA SOTIB OLISHGA TAKLIF — yetkazib berilgan buyurtmadan
 * REPURCHASE_REMINDER_DAYS kun o'tgach, xaridorga "yana buyurtma
 * berishni xohlaysizmi" degan taklif yuboradi.
 *
 * MUHIM DIZAYN QARORI (xarajat va aniqlik muvozanati): FAQAT
 * O'SHA KUNI ANIQ 30 kunga to'lgan buyurtmalar (kichik, kunlik
 * "oyna") tekshiriladi - shu orqali funksiya HAR KUNI faqat
 * cheklangan sonli buyurtmani ko'radi, butun tarixni QAYTA-QAYTA
 * skanerlamaydi. Har bir buyurtma uchun, xaridor O'SHA VAQTDAN
 * BERI qayta buyurtma BERMAGANINI aniq tekshiramiz - aks holda,
 * allaqachon qaytgan mijozga keraksiz, noqulay eslatma yuborilishi
 * mumkin edi.
 *
 * AI CEO — TIER-1 "ISHONCH ZINAPOYASI" (avvalgi suhbatda
 * kelishilgan model): bu funksiya ALLAQACHON, hech kimning tugma
 * bosishisiz, avtomatik ishlaydi - ya'ni haqiqiy "avtonom harakat"
 * allaqachon mavjud, faqat matni STATIK shablon edi. Endi, FAQAT
 * sotuvchi buni ALOHIDA, ochiq-oydin yoqqan bo'lsa
 * (`aiCeoAutoWinBackEnabled === true`, standart holatda O'CHIQ -
 * bu ataylab OPT-IN, OPT-OUT EMAS), matnni AI CEO Gemini orqali
 * yaxshilab yozadi - bu, ENG XAVFSIZ va QAYTARILADIGAN harakat
 * turi uchun (oddiy, bosimsiz "sizni sog'indik" eslatmasi, moliyaviy
 * va'da yo'q) TO'LIQ AVTONOM ijro degani. Gemini xato bersa
 * (tarmoq, kvota va h.k.) - JIM QOLIB, oddiy shablonga qaytamiz,
 * chunki eslatma YUBORILISHI AI'ning ishlashiga BOG'LIQ
 * bo'lmasligi kerak. Har bir AI-yozilgan xabar
 * `aiCeoAutoWinBackSent` hisoblagichida qayd etiladi - sotuvchi
 * buni kunlik hisobotda ("AI CEO bugun N ta amalni avtomatik
 * bajardi") KO'RA oladi - oldindan tasdiqlash EMAS, lekin TO'LIQ
 * SHAFFOFLIK.
 *
 * AI CEO — 8-BOSQICH (KENGAYTIRILGAN doira, batafsil izoh:
 * `aiCeoAutoDiscount.js`): xuddi shu funksiya ichida, FAQAT sotuvchi
 * BUTUNLAY ALOHIDA `aiCeoAutoDiscountEnabled`ni yoqqan bo'lsa VA
 * 3-fazada (`aiCeoLearning.js`) yig'ilgan HAQIQIY natija "AI matni
 * yetarlicha ishlamayapti"ni ISBOTLAGAN bo'lsa - matn xabariga
 * qo'shimcha, HAQIQIY (deterministik, Gemini ISHTIROKISIZ yaratilgan)
 * bir martalik chegirma promokodi ham qo'shiladi.
 */
exports.sendRepurchaseReminders = onSchedule(
  { schedule: "0 13 * * *", timeZone: "Asia/Tashkent", region: "asia-south1", secrets: [BOT_TOKEN, GEMINI_API_KEY] },
  async () => {
    const windowEnd = Date.now() - REPURCHASE_REMINDER_DAYS * 24 * 60 * 60 * 1000;
    const windowStart = windowEnd - 24 * 60 * 60 * 1000; // bitta kunlik oyna

    // XAVFSIZLIK CHEGARASI - yuqoridagi bilan bir xil sabab.
    const MAX_ORDERS_PER_RUN = 200;

    const ordersSnap = await db.collection("orders")
      .where("status", "==", "delivered")
      .where("createdAt", ">=", admin.firestore.Timestamp.fromMillis(windowStart))
      .where("createdAt", "<", admin.firestore.Timestamp.fromMillis(windowEnd))
      .limit(MAX_ORDERS_PER_RUN)
      .get();

    if (ordersSnap.empty) return;

    const sellerCache = new Map();

    for (const orderDoc of ordersSnap.docs) {
      const order = orderDoc.data();
      if (order.repurchaseReminderSent) continue;
      if (!order.sellerId || !order.clientId || !Array.isArray(order.orders) || order.orders.length === 0) continue;

      try {
        // MIJOZ O'SHA BUYURTMADAN KEYIN QAYTA BUYURTMA BERGANMI -
        // agar berilgan bo'lsa, eslatma yuborishning hojati yo'q.
        const newerOrdersSnap = await db.collection("orders")
          .where("sellerId", "==", order.sellerId)
          .where("clientId", "==", order.clientId)
          .where("createdAt", ">", order.createdAt)
          .limit(1)
          .get();
        if (!newerOrdersSnap.empty) {
          await orderDoc.ref.update({ repurchaseReminderSent: true }); // qayta tekshirmaslik uchun belgilaymiz
          continue;
        }

        if (!sellerCache.has(order.sellerId)) {
          // MUHIM, JIDDIY TUZATISH (regressiya): mijozlarga xabar HAR
          // DOIM platformaning o'z boti orqali yuboriladi (batafsil
          // izoh: `notifications.js`).
          const sellerSnap = await db.collection("sellers").doc(order.sellerId).get();
          const seller = sellerSnap.exists ? sellerSnap.data() : {};
          // YANGI (7-BOSQICH): FAQAT AI-yozuv YOQILGAN bo'lsa o'qiladi
          // (ARZON - bitta o'qish, sotuvchi boshiga BIR MARTA, butun
          // ishga tushirish davomida keshlangan holda).
          const recentPerformance = seller.aiCeoEnabled === true && seller.aiCeoAutoWinBackEnabled === true
            ? await getRecentAiPerformance(order.sellerId, "winback")
            : null;
          // YANGI (8-BOSQICH): shu ishga tushirish davomida, shu
          // sotuvchi uchun ALLAQACHON berilgan avtomatik chegirmalar
          // sonini kuzatib boradi (`discountState` - MUTABLE obyekt,
          // shu orqali keshda o'zgartirib borish mumkin) -
          // `MAX_AUTO_DISCOUNTS_PER_SELLER_PER_RUN` xavfsizlik
          // chegarasi uchun ZARUR.
          sellerCache.set(order.sellerId, { seller, token: BOT_TOKEN.value(), recentPerformance, discountState: { issuedCount: 0 } });
        }
        const { seller, token, recentPerformance, discountState } = sellerCache.get(order.sellerId);

        if (seller.repurchaseReminderEnabled === false) continue;

        const itemsList = order.orders.slice(0, 5).map((i) => `• ${i.name} x${i.quantity}`).join("\n");
        let text = `Bir oy oldin buyurtma bergan mahsulotlaringiz tugab qolgandirmi?\n\n${itemsList}\n\nYana buyurtma berish uchun do'konimizga tashrif buyuring!`;
        let aiGenerated = false;

        if (seller.aiCeoEnabled === true && seller.aiCeoAutoWinBackEnabled === true) {
          try {
            const aiText = await craftWinBackMessage({
              customerName: order.customer?.fullName,
              daysSinceLastOrder: REPURCHASE_REMINDER_DAYS,
              lastProductName: order.orders[0]?.name,
              storeName: seller.storeName,
              recentPerformance,
            });
            if (aiText) {
              text = aiText;
              aiGenerated = true;
            }
          } catch (aiErr) {
            // MUHIM: AI xato bersa jim qolamiz, oddiy shablon bilan
            // davom etamiz - eslatma yuborilishi HECH QACHON AI
            // xatosiga bog'liq bo'lmasligi kerak.
            console.error(`AI qaytarish xabari yaratib bo'lmadi (buyurtma ${orderDoc.id}), oddiy shablon ishlatiladi:`, aiErr);
          }
        }

        // YANGI (8-BOSQICH): matn TAYYOR bo'lgach, lekin YUBORILISHDAN
        // OLDIN - agar shart-sharoit MUVOFIQ bo'lsa (opt-in, ISBOTLANGAN
        // past konversiya, xavfsizlik chegarasi ichida), HAQIQIY,
        // deterministik chegirma kodi yaratiladi va xabar oxiriga
        // QO'SHIMCHA qator sifatida qo'shiladi. Chegirma yaratib
        // bo'lmasa (yoki shart-sharoit mos kelmasa) - `text` O'ZGARMAY
        // qoladi, xabar baribir yuboriladi (batafsil izoh:
        // `aiCeoAutoDiscount.js`).
        let discountIssued = false;
        if (seller.aiCeoEnabled === true) {
          const discountResult = await maybeIssueAutoWinBackDiscount({
            sellerId: order.sellerId,
            clientId: order.clientId,
            seller,
            recentPerformance,
            issuedCountThisRun: discountState.issuedCount,
          });
          if (discountResult.issued) {
            discountIssued = true;
            discountState.issuedCount += 1;
            text += `\n\nMaxsus taklif: ${discountResult.discountPercent}% chegirma bilan qaytib keling!\nPromokod: ${discountResult.code} (7 kun amal qiladi)`;
          }
        }

        await sendTelegramMessage(token, order.clientId, text);
        await incrementDailyStat(order.sellerId, "repurchaseRemindersSent");
        if (aiGenerated) {
          await incrementDailyStat(order.sellerId, "aiCeoAutoWinBackSent");
        }
        if (discountIssued) {
          await incrementDailyStat(order.sellerId, "aiCeoAutoDiscountsIssued");
        }
        await logNotification({
          sellerId: order.sellerId, clientId: order.clientId, type: "repurchaseReminder",
          title: "Qayta sotib olish taklifi", message: text,
        });
        // YANGI (7-BOSQICH): AI CEO premium sotuvchilar uchun (AI-yozuv
        // yoqilgan-yoqilmaganidan qat'i nazar), bu xabarning haqiqiy
        // natijasi ("mijoz keyinroq xarid qildimi") kuzatuvga olinadi.
        if (seller.aiCeoEnabled === true) {
          await recordAiCeoOutcome({ sellerId: order.sellerId, type: "winback", clientId: order.clientId, aiGenerated, discountIssued });
        }

        await orderDoc.ref.update({
          repurchaseReminderSent: true,
          repurchaseReminderSentAt: admin.firestore.FieldValue.serverTimestamp(),
        });
      } catch (err) {
        console.error(`Qayta sotib olish eslatmasi xatosi (${orderDoc.id}):`, err);
      }
    }
  }
);
