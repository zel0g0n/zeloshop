const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { admin, db, BOT_TOKEN } = require("./lib/admin");
const { checkRateLimit } = require("./lib/rateLimit");
const { sendTelegramMessage } = require("./lib/helpers");
const { resolveDeliveryTier } = require("./lib/deliveryTiers");
const { logNotification } = require("./lib/dailyStats");
const { withSentry, SENTRY_DSN } = require("./lib/sentry");

/**
 * XAVFSIZ BUYURTMA YARATISH — asosiy mantiq.
 *
 * Mijoz faqat mahsulot ID'lari va sonini yuboradi. Narxlar, promokod
 * haqiqiyligi va chegirma — barchasi shu yerda, Firestore TRANSACTION
 * ichida, HAQIQIY (server tomonidagi) ma'lumotdan qayta hisoblanadi.
 * Bonusda: ombor qoldig'i avtomatik kamayadi, va promokod ishlatilish
 * soni bir vaqtning o'zida (parallel) ikkita mijoz tomonidan limitdan
 * oshib ketishining oldi olinadi.
 *
 * Ichki mantiq alohida funksiyaga ajratilgan — shunda uni `onCall`
 * o'rovisiz, to'g'ridan-to'g'ri sinov (test) fayllaridan chaqirish
 * mumkin.
 */
async function handleCreateOrder(request) {
  if (!request.auth) {
    throw new HttpsError("unauthenticated", "Tizimga kirgan bo'lishingiz kerak.");
  }

  // SO'ROVLARNI CHEGARALASH: bir mijoz 5 daqiqada 10 tadan ortiq
  // buyurtma yarata olmaydi — bu, oddiy xaridor uchun yetarlicha
  // keng, lekin omborni avtomatik "bo'shatib qo'yish" yoki tizimni
  // spam bilan bosib yuborishning oldini oladi.
  await checkRateLimit(`createOrder:${request.auth.uid}`, 10, 300);

  const { sellerId, customerData, items, couponCode, customerRegion } = request.data || {};
  const clientId = request.auth.uid; // HECH QACHON mijoz o'zi yubormaydi — sessiyadan olinadi.

  if (!sellerId) throw new HttpsError("invalid-argument", "Sotuvchi ko'rsatilmagan.");
  if (!Array.isArray(items) || items.length === 0) {
    throw new HttpsError("invalid-argument", "Savat bo'sh.");
  }
  if (!customerData?.fullName?.trim() || !customerData?.phone?.trim()) {
    throw new HttpsError("invalid-argument", "Mijoz ma'lumotlari to'liq emas.");
  }

  const firestore = admin.firestore();

  try {
    const result = await firestore.runTransaction(async (transaction) => {
      // 1) Har bir mahsulotni HAQIQIY Firestore'dan o'qiymiz (mijoz
      // yuborgan narx/nom/rasmga ISHONMAYMIZ).
      const productRefs = items.map((item) => firestore.collection("products").doc(item.productId));
      const sellerRef = firestore.collection("sellers").doc(sellerId);
      // MUHIM (referal dasturi uchun): mijoz hujjatini ham shu
      // TRANZAKSIYA ichida o'qiymiz - shu orqali "referal chegirmasi
      // ishlatilganmi" tekshiruvi VA "ishlatildi" deb belgilash BITTA
      // ATOMIK amalning bir qismi bo'ladi (poyga holati - race
      // condition - butunlay yo'q bo'ladi, hatto mijoz bir vaqtning
      // o'zida ikkita buyurtma yuborishga urinsa ham).
      const clientRef = firestore.collection("clients").doc(clientId);
      // MUHIM QO'SHIMCHA: HAQIQIY, DOIMIY buyurtma tartib raqami
      // uchun - `sellers/{id}/counters/orders` hujjatida saqlanadigan
      // ATOMIK hisoblagich. OLDIN sotuvchi panelida "tartib raqami"
      // shunchaki YUKLAB OLINGAN ro'yxatning massiv ICHIDAGI o'rni
      // asosida HISOBLANARDI (`orders.length - index`) - bu, agar
      // do'konda 150 tadan ko'p buyurtma bo'lsa (yuklash chegarasi),
      // HAQIQIY umumiy tartib raqamini KO'RSATMAS edi. Endi - har bir
      // buyurtma YARATILGAN PAYTIDA, o'zining ANIQ, o'zgarmas tartib
      // raqamini oladi va shu YERDA, hujjatning O'ZIDA saqlanadi -
      // hisoblash keyinchalik SHART EMAS, va yuklash chegarasidan
      // MUSTAQIL, har doim TO'G'RI.
      const orderCounterRef = firestore.collection("sellers").doc(sellerId).collection("counters").doc("orders");
      const [productSnaps, sellerSnap, clientSnap, orderCounterSnap] = await Promise.all([
        Promise.all(productRefs.map((ref) => transaction.get(ref))),
        transaction.get(sellerRef),
        transaction.get(clientRef),
        transaction.get(orderCounterRef),
      ]);
      const orderNumber = (orderCounterSnap.exists ? Number(orderCounterSnap.data().count) || 0 : 0) + 1;

      const orderItems = [];
      let subtotal = 0;

      for (let i = 0; i < items.length; i++) {
        const snap = productSnaps[i];
        const requestedQty = Number(items[i].quantity) || 0;

        if (!snap.exists) {
          throw new HttpsError("not-found", `Mahsulot topilmadi (${items[i].productId}).`);
        }
        const product = snap.data();

        if (product.sellerId !== sellerId) {
          throw new HttpsError("invalid-argument", "Savatda boshqa do'konning mahsuloti bor.");
        }
        if (requestedQty <= 0) {
          throw new HttpsError("invalid-argument", "Mahsulot soni noto'g'ri.");
        }
        if (Number(product.stock) < requestedQty) {
          throw new HttpsError("failed-precondition", `"${product.name}" omborda yetarli emas (qoldiq: ${product.stock}).`);
        }

        const hasDiscount = product.discountPrice && Number(product.discountPrice) > 0 && Number(product.discountPrice) < Number(product.price);
        const unitPrice = hasDiscount ? Number(product.discountPrice) : Number(product.price) || 0;

        orderItems.push({
          id: productRefs[i].id,
          name: product.name,
          image: product.image || (product.images && product.images[0]) || null,
          price: unitPrice,
          quantity: requestedQty,
        });
        subtotal += unitPrice * requestedQty;
      }

      // MUHIM, YANGI (real P&L uchun zarur): har bir qatorning
      // TANNARXINI ham shu tranzaksiya ichida, HOZIRGI mahsulot
      // hujjatidan "suratga olamiz" - lekin ATAYLAB `orderItems`
      // (mijozga ham ko'rinadigan, `orders/{id}` hujjatining o'zi)
      // ICHIGA EMAS, balki ALOHIDA, faqat sotuvchi o'qiy oladigan
      // `sellers/{id}/orderCosts/{orderId}` hujjatiga yozamiz.
      // SABAB: `orders/{orderId}` hujjatini XARIDOR HAM o'qiy oladi
      // (`firestore.rules`) - agar tannarx O'SHA yerda saqlansa,
      // xaridor sotuvchining ulgurji narxini (marja qanchaligini)
      // ko'rib qolardi. Bu yig'ma yozuv esa, buyurtma "delivered"ga
      // o'tganda `orderRollups.js` trigger'i orqali P&L/Dashboard
      // hisob-kitoblarida ishlatiladi - shu orqali, sotuvchi KEYINROQ
      // mahsulot tannarxini o'zgartirsa ham, O'TGAN davr foydasi
      // ORQAGA QARAB O'ZGARMAYDI (haqiqiy buxgalteriya talabi).
      const costSnapshotItems = orderItems.map((item, i) => ({
        id: item.id,
        costPrice: Number(productSnaps[i].data().costPrice) || 0,
        quantity: item.quantity,
      }));

      const seller = sellerSnap.exists ? sellerSnap.data() : {};
      const client = clientSnap.exists ? clientSnap.data() : {};

      // 2) Promokodni — agar berilgan bo'lsa — HAQIQIY qoidalar
      // bo'yicha qayta tekshiramiz (mijoz "discountAmount"iga
      // ishonmaymiz).
      let appliedCoupon = null;
      let discountAmount = 0;
      let couponRef = null;

      if (couponCode) {
        const normalizedCode = String(couponCode).trim().toUpperCase();
        couponRef = firestore.collection("sellers").doc(sellerId).collection("coupons").doc(normalizedCode);
        const couponSnap = await transaction.get(couponRef);

        if (!couponSnap.exists) {
          throw new HttpsError("not-found", "Bunday promokod topilmadi.");
        }
        const coupon = couponSnap.data();

        if (!coupon.isActive) {
          throw new HttpsError("failed-precondition", "Bu promokod faol emas.");
        }
        if (coupon.expiresAt && new Date(coupon.expiresAt).getTime() < Date.now()) {
          throw new HttpsError("failed-precondition", "Bu promokodning muddati tugagan.");
        }
        if (coupon.usageLimit && coupon.usedCount >= coupon.usageLimit) {
          throw new HttpsError("failed-precondition", "Bu promokodning ishlatish limiti tugagan.");
        }

        discountAmount = coupon.discountType === "percent"
          ? Math.round((subtotal * coupon.discountValue) / 100)
          : Math.min(coupon.discountValue, subtotal);

        appliedCoupon = { code: normalizedCode, discountAmount };
      }

      // 2.5) REFERAL DASTURI: agar bu mijoz do'sti orqali TAKLIF
      // qilingan bo'lsa, aynan SHU sotuvchi uchun, va bu chegirmani
      // HALI ishlatmagan bo'lsa - birinchi buyurtmasiga avtomatik
      // chegirma qo'llanadi. ATAYLAB promokod bilan bir vaqtda
      // QO'LLANMAYDI (faqat couponCode berilmagan holatda ishlaydi) -
      // ikki chegirmani bir-biriga qo'shib, suiiste'mol qilishning
      // (masalan sun'iy hisoblar yaratib, ikkalasini ham olishning)
      // oldini olish uchun.
      //
      // ATOMIKLIK: "referralDiscountUsed" belgisi shu YAGONA
      // tranzaksiya ICHIDA o'qiladi VA yoziladi - shuning uchun mijoz
      // bir vaqtning o'zida ikkita buyurtma yuborishga urinsa ham,
      // chegirma FAQAT bittasiga tegishi kafolatlanadi.
      let referralApplied = null;
      let referralRewardCouponCode = null;
      const referralEligible =
        !couponCode &&
        client.referredBy &&
        client.referredForSellerId === sellerId &&
        !client.referralDiscountUsed &&
        seller.referralProgramEnabled !== false; // standart bo'yicha YOQILGAN, faqat aniq false bo'lsa o'chadi

      if (referralEligible) {
        const percent = Number(seller.referralDiscountPercent) > 0 ? Number(seller.referralDiscountPercent) : 10;
        discountAmount = Math.round((subtotal * percent) / 100);
        referralApplied = { referrerId: client.referredBy, discountPercent: percent, discountAmount };
      }

      const amountAfterDiscount = Math.max(0, subtotal - discountAmount);

      // 3) Yetkazib berish narxini HAQIQIY sotuvchi sozlamasidan
      // hisoblaymiz (mijoz hech qanday narx yubormaydi — faqat o'z
      // hududini).
      //
      // MUHIM, TO'LIQ QAYTA QURISH: OLDIN mijoz sotuvchi TUZGAN 5 ta
      // qattiq mintaqadan birining KALITINI (`deliveryZoneKey`)
      // yuborardi. Endi mijoz FAQAT o'z hududini yuboradi
      // (`customerRegion`) - SERVER esa buni sotuvchining o'z hududi
      // (`seller.region`) bilan SOLISHTIRIB, qaysi narx bosqichi
      // (Shahar/Tumanlar/Boshqa viloyat) qo'llanilishini O'ZI
      // hisoblab chiqadi (`resolveDeliveryTier` - `lib/deliveryTiers.js`,
      // frontenddagi bilan BIR XIL mantiq).
      let deliveryZone = null;
      let deliveryFee = 0;

      const deliveryTierKey = resolveDeliveryTier(seller.region, customerRegion);
      const tierConfig = deliveryTierKey ? seller.deliveryTiers?.[deliveryTierKey] : null;

      if (tierConfig && Number(tierConfig.price) > 0) {
        const isFreeDelivery = seller.freeDeliveryEnabled &&
          seller.freeDeliveryThreshold &&
          amountAfterDiscount >= Number(seller.freeDeliveryThreshold);

        deliveryFee = isFreeDelivery ? 0 : (Number(tierConfig.price) || 0);
        deliveryZone = {
          tier: deliveryTierKey,
          customerRegion: customerRegion || null,
          price: deliveryFee,
          days: tierConfig.days || null,
          isFree: isFreeDelivery,
        };
      }

      const totalAmount = amountAfterDiscount + deliveryFee;

      // 4) Ombor qoldig'ini kamaytiramiz VA "sotilganlar" sonini
      // oshiramiz (HAR BIR mahsulot uchun, BIR XIL yozuvda — ikkalasi
      // ham HAR DOIM birga, izchil o'zgarishi uchun).
      //
      // MUHIM TUZATISH: oldin bu yerda faqat `stock` kamaytirilardi —
      // "necha marta sotilgan" (`sold`) hech qachon oshirilmasdi,
      // shuning uchun mahsulot kartochkasida "0 sotildi" doim
      // ko'rinaverar edi, garchi ombor haqiqatan kamayib borsa ham.
      productRefs.forEach((ref, i) => {
        const newStock = Number(productSnaps[i].data().stock) - orderItems[i].quantity;
        transaction.update(ref, {
          stock: Math.max(0, newStock),
          sold: admin.firestore.FieldValue.increment(orderItems[i].quantity),
        });
      });

      // 5) Promokod ishlatilish sonini oshiramiz (agar bo'lsa).
      if (couponRef) {
        transaction.update(couponRef, { usedCount: admin.firestore.FieldValue.increment(1) });
      }

      // 5.5) REFERAL MUKOFOTI: agar yuqorida referal chegirmasi
      // qo'llangan bo'lsa - (a) mijozda "ishlatildi" belgisini
      // qo'yamiz (bir xil chegirma ikkinchi marta berilmasligi
      // uchun), (b) TAKLIF QILGAN kishiga, keyingi xaridi uchun
      // ishlatadigan yangi promokod yaratamiz. Barchasi shu BITTA
      // tranzaksiya doirasida - yoki hammasi muvaffaqiyatli bo'ladi,
      // yoki hech biri (Firestore transaction kafolati).
      if (referralApplied) {
        transaction.update(clientRef, { referralDiscountUsed: true });

        referralRewardCouponCode = `REF-${Math.random().toString(36).slice(2, 8).toUpperCase()}`;
        const rewardCouponRef = firestore.collection("sellers").doc(sellerId).collection("coupons").doc(referralRewardCouponCode);
        transaction.set(rewardCouponRef, {
          code: referralRewardCouponCode,
          discountType: "percent",
          discountValue: referralApplied.discountPercent,
          expiresAt: null,
          usageLimit: 1,
          usedCount: 0,
          isActive: true,
          isReferralReward: true,
          rewardForClientId: referralApplied.referrerId,
          createdAt: admin.firestore.FieldValue.serverTimestamp(),
          createdAtMs: Date.now(),
        });

        // Kuzatuv/statistika uchun - sotuvchi panelida "kim kimni
        // taklif qildi" ko'rinishi mumkin bo'lsin.
        const referralRecordRef = firestore.collection("sellers").doc(sellerId).collection("referrals").doc(clientId);
        transaction.set(referralRecordRef, {
          referrerId: referralApplied.referrerId,
          refereeId: clientId,
          rewardCouponCode: referralRewardCouponCode,
          refereeDiscountAmount: referralApplied.discountAmount,
          createdAt: admin.firestore.FieldValue.serverTimestamp(),
        });
      }

      // 5.7) "TASHLAB KETILGAN SAVAT" ESLATMASI uchun saqlangan
      // savat hujjatini o'chiramiz - buyurtma MUVAFFAQIYATLI
      // yaratilganda, bu savat endi "tashlab ketilgan" emas, shuning
      // uchun keyingi eslatma tekshiruvida (`functions/carts.js`)
      // ko'rib chiqilmasligi kerak. Hujjat mavjud bo'lmasa ham xato
      // bermaydi (Firestore transaction.delete xavfsiz no-op).
      const cartRef = firestore.collection("carts").doc(`${sellerId}_${clientId}`);
      transaction.delete(cartRef);

      // 6) Buyurtmani yaratamiz.
      const orderRef = firestore.collection("orders").doc();
      transaction.set(orderRef, {
        sellerId,
        clientId,
        orderNumber,
        customer: {
          fullName: customerData.fullName.trim(),
          phone: customerData.phone.trim(),
          address: customerData.address || "",
          location: customerData.location || null,
          paymentTypes: Array.isArray(customerData.paymentTypes) ? customerData.paymentTypes : [],
        },
        orders: orderItems,
        status: "new",
        subtotal,
        appliedCoupon,
        referralDiscount: referralApplied ? { discountPercent: referralApplied.discountPercent, discountAmount: referralApplied.discountAmount } : null,
        deliveryZone,
        totalAmount,
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
      });

      // Tannarx suratini (yuqoridagi izohga qarang) - ALOHIDA, faqat
      // sotuvchiga ko'rinadigan hujjatga, xuddi shu orderRef.id bilan
      // yozamiz (`orderRollups.js` trigger'i buyurtma "delivered"ga
      // o'tganda shu hujjatni qidiradi).
      const orderCostRef = firestore.collection("sellers").doc(sellerId).collection("orderCosts").doc(orderRef.id);
      transaction.set(orderCostRef, {
        items: costSnapshotItems,
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
      });

      // Hisoblagichni SHU TRANZAKSIYA ichida, ATOMIK ravishda
      // yangilaymiz - shu orqali, hatto ikkita mijoz bir vaqtning
      // o'zida buyurtma bersa ham, ikkitasi HECH QACHON bir xil
      // tartib raqamini OLMAYDI (Firestore tranzaksiyasi buni
      // kafolatlaydi - to'qnashuv bo'lsa, biri avtomatik qayta
      // urinadi).
      transaction.set(orderCounterRef, { count: orderNumber }, { merge: true });

      return { orderId: orderRef.id, orderNumber, subtotal, discountAmount, deliveryZone, totalAmount, appliedCoupon, referralDiscount: referralApplied, referralRewardCouponCode };
    });

    // MUHIM: referal mukofoti haqidagi Telegram xabari ATAYLAB
    // TRANZAKSIYADAN TASHQARIDA yuboriladi. Agar buni tranzaksiya
    // ICHIDA qilganimizda, Firestore tranzaksiya to'qnashuv (contention)
    // tufayli QAYTA URINISH qilishi mumkin edi - bu esa, HAR BIR qayta
    // urinishda xabar QAYTA-QAYTA yuborilishiga olib kelardi. Bu yerda,
    // faqat tranzaksiya MUVAFFAQIYATLI yakunlangandan KEYIN, BIR MARTA
    // yuboriladi.
    if (result.referralDiscount && result.referralRewardCouponCode) {
      try {
        // MUHIM, JIDDIY TUZATISH (regressiya): mijozlarga xabar HAR
        // DOIM platformaning o'z boti orqali yuboriladi (batafsil
        // izoh: `notifications.js`).
        const token = BOT_TOKEN.value();
        const text = `Tabriklaymiz!\n\nSiz taklif qilgan do'stingiz birinchi xaridini amalga oshirdi.\n\nSizga ${result.referralDiscount.discountPercent}% chegirmali promokod berildi:\n${result.referralRewardCouponCode}\n\nKeyingi xaridingizda ishlating!`;
        await sendTelegramMessage(token, result.referralDiscount.referrerId, text);
        await logNotification({
          sellerId, clientId: result.referralDiscount.referrerId, type: "referralReward",
          title: "Referal mukofoti", message: text,
        });
      } catch (notifyErr) {
        // MUHIM: bu xabar YUBORILMASA HAM, buyurtmaning o'zi va
        // promokod ALLAQACHON muvaffaqiyatli yaratilgan - shuning
        // uchun bu yerdagi xatolik BUYURTMANI BEKOR QILMASLIGI kerak,
        // faqat logga yoziladi.
        console.error("Referal mukofoti haqida xabar yuborishda xatolik:", notifyErr);
      }
    }

    return result;
  } catch (err) {
    console.error("Xavfsiz buyurtma yaratishda xatolik:", err);
    if (err instanceof HttpsError) throw err;
    throw new HttpsError("internal", "Buyurtma yaratib bo'lmadi. Birozdan so'ng qayta urinib ko'ring.");
  }
}

exports.createOrder = onCall({ region: "asia-south1", secrets: [BOT_TOKEN, SENTRY_DSN] }, withSentry(handleCreateOrder));

// Sinov (test) fayllari uchun.
exports._testables = { handleCreateOrder };
