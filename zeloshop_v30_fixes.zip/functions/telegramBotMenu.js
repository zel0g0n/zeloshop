const crypto = require("crypto");
const { GoogleGenAI } = require("@google/genai");
const { admin, db, GEMINI_API_KEY } = require("./lib/admin");
const { checkRateLimit } = require("./lib/rateLimit");
const { buildDailyReport } = require("./aiCeo");
const { processDraft } = require("./productDrafts");

/**
 * TELEGRAM BOT "MENYU" - foydalanuvchi (sotuvchi) so'ragan: platforma
 * botida ("ZeloShop") ilgari FAQAT "Do'konni ochish" (BotFather'da
 * sotuvchi o'zi qo'lda sozlagan Menu tugmasi) mavjud edi - do'konni
 * OCHMASDAN turib bajarish mumkin bo'lgan amallar UMUMAN yo'q edi.
 * Bu fayl IKKITA yangi, Mini App'ni OCHISHNI TALAB QILMAYDIGAN amalni
 * qo'shadi, HAR IKKALASI HAM sotuvchiga doimiy ko'rinadigan Telegram
 * "reply keyboard" (xabar kiritish maydoni USTIDAGI tugmalar qatori,
 * `setChatMenuButton`dan FARQLI - u yerda faqat BITTA tugma bo'lishi
 * mumkin) orqali ishga tushiriladi:
 *
 *   1) "📊 AI CEO hisobotlari" - `AiCeoInfoPage.jsx`dagi BILAN BIR XIL,
 *      HAQIQIY kunlik hisobotni (`aiCeo.js`dagi `buildDailyReport`,
 *      QAYTA ISHLATILADI - yangi hisoblash yozilmaydi) darhol,
 *      Telegram xabari sifatida yuboradi.
 *
 *   2) "🤖 AI CEO bilan mahsulot qo'shish" - sotuvchi 4 tagacha rasm
 *      yuboradi ("✅ Tayyor" bilan yakunlaydi), so'ng AI CEO O'SHA
 *      rasmlar asosida mahsulot qoralamasini DARHOL tayyorlaydi
 *      (`productDrafts.js`dagi `processDraft` - "Tez qo'shish"
 *      oqimidagi SOATLIK partiya jarayoni bilan BIR XIL Gemini
 *      mantig'i, faqat NAVBATDA kutmasdan, DARHOL chaqiriladi).
 *      Tayyor bo'lgach, sotuvchiga bildirishnoma yuboriladi - qoralama
 *      xuddi ilova ichidan "Tez qo'shish" orqali kelgan qoralama kabi,
 *      Mahsulotlar → "Tasdiqlash kutilmoqda" bo'limida ko'rinadi (BIR
 *      XIL `sellers/{id}/productDrafts` kolleksiyasi, BIR XIL
 *      `ProductDraftReview.jsx` ekrani - yangi UI YOZILMAYDI).
 *
 * SUHBAT HOLATI (rasm yig'ish jarayonining "qayerdaligi") sessiya
 * hujjatida saqlanadi: `sellers/{sellerId}/private/aiCeoBotSession`
 * (mavjud "maxfiy" quyi kolleksiya naqshi - `firestore.rules`da
 * ALLAQACHON faqat egasi/admin o'qiy oladigan qilib himoyalangan,
 * yangi qoida SHART EMAS).
 *
 * XAVFSIZLIK: bu yerdagi HAR BIR funksiya `sellerId`ni Telegram
 * `message.from.id`dan oladi - bu, `telegramApproval.js`dagi
 * `callback_query.from.id` BILAN BIR XIL, Telegram serveri tomonidan
 * TASDIQLANGAN (soxtalashtirib bo'lmaydigan) qiymat.
 *
 * XARAJAT NAZORATI: (1) mahsulot qo'shish FAQAT `aiCeoEnabled===true`
 * sotuvchilar uchun; (2) bir kunda ENG KO'PI BILAN
 * `MAX_AI_PRODUCTS_PER_DAY` ta mahsulot (foydalanuvchi ATAYLAB
 * so'ragan cheklov) - `checkRateLimit` orqali, FAQAT haqiqatan
 * Gemini chaqirilishidan OLDIN (rasm yig'ish bosqichida EMAS - bekor
 * qilingan urinishlar chegaraga hisoblanmasligi uchun); (3) hisobot
 * tugmasi ham engil chegaralanadi (soatiga 20 marta) - suiiste'mol
 * qilinsa ham, Gemini FAQAT `aiActionPlan` qismida, kunlik keshlangan
 * holda chaqiriladi (`buildDailyReport`ning o'zidagi mavjud xarajat
 * nazorati).
 */

const MENU_REPORT_TEXT = "📊 AI CEO hisobotlari";
const MENU_ADD_PRODUCT_TEXT = "🤖 AI CEO bilan mahsulot qo'shish";
const FINISH_TEXT = "✅ Tayyor";
const CANCEL_TEXT = "❌ Bekor qilish";

const MAX_PHOTOS = 4;
const MAX_AI_PRODUCTS_PER_DAY = 4;
const AI_PRODUCT_WINDOW_SECONDS = 24 * 60 * 60;

/**
 * Asosiy menyu - HAR DOIM shu ikki tugma ko'rinadi (mavjud "Do'konni
 * ochish" Menu tugmasidan FARQLI joyda, xabar kiritish maydoni
 * USTIDA). SOF FUNKSIYA.
 */
function buildMainMenuKeyboard() {
  return {
    keyboard: [[{ text: MENU_REPORT_TEXT }], [{ text: MENU_ADD_PRODUCT_TEXT }]],
    resize_keyboard: true,
  };
}

/**
 * Rasm yig'ish bosqichidagi vaqtinchalik menyu. SOF FUNKSIYA.
 */
function buildPhotoCollectionKeyboard() {
  return { keyboard: [[{ text: FINISH_TEXT }, { text: CANCEL_TEXT }]], resize_keyboard: true };
}

/**
 * Telegram `message.photo` massividan (bir nechta o'lchamdagi nusxa)
 * ENG KATTASINI (eng yuqori sifat) tanlaydi. SOF FUNKSIYA.
 */
function pickLargestPhoto(photoSizes) {
  if (!Array.isArray(photoSizes) || photoSizes.length === 0) return null;
  return photoSizes.reduce((best, p) => ((p.width || 0) * (p.height || 0) > (best.width || 0) * (best.height || 0) ? p : best));
}

/**
 * `aiCeo.js`dagi `buildDailyReport()` natijasini Telegram xabari
 * matniga aylantiradi - `AiCeoInfoPage.jsx`dagi kartochkalar BILAN BIR
 * XIL ma'lumot, faqat matn ko'rinishida. SOF FUNKSIYA - to'g'ridan-
 * to'g'ri test qilinadi.
 */
function formatDailyReportForTelegram(report, storeName) {
  const f = report.financial;
  const changeText = f.revenueChangePercent === null
    ? "solishtirish uchun yetarli ma'lumot yo'q"
    : `${f.revenueChangePercent >= 0 ? "+" : ""}${f.revenueChangePercent.toFixed(0)}%`;

  const lines = [
    `🤖 *AI CEO — Kunlik hisobot*${storeName ? ` (${storeName})` : ""}`,
    "",
    "💰 *Moliya*",
    `Bugun: ${f.todayRevenue.toLocaleString()} so'm (${f.todayOrderCount} ta buyurtma, ${f.todayDeliveredCount} tasi yetkazilgan)`,
    `Kecha: ${f.yesterdayRevenue.toLocaleString()} so'm`,
    `O'zgarish: ${changeText}`,
  ];

  const { discountCandidates, promoteCandidates } = report.productRecommendations;
  if (discountCandidates.length > 0 || promoteCandidates.length > 0) {
    lines.push("", "🛍 *Mahsulot tavsiyalari*");
    if (discountCandidates.length > 0) lines.push(`Chegirma nomzodlari: ${discountCandidates.map((p) => p.name).join(", ")}`);
    if (promoteCandidates.length > 0) lines.push(`Eng ko'p sotilgan: ${promoteCandidates.map((p) => `${p.name} (${p.soldQty} dona)`).join(", ")}`);
  }

  if (report.productAdditions.addedTodayCount > 0) {
    lines.push("", `🆕 Bugun qo'shilgan: ${report.productAdditions.addedTodayCount} ta mahsulot (${report.productAdditions.salesFromNewProducts.toLocaleString()} so'm sotuv)`);
  }

  const crm = report.crmActivity;
  const totalCrmSent = crm.cartRemindersSent + crm.favoriteRemindersSent + crm.repurchaseRemindersSent + crm.crmMessagesSent;
  lines.push(
    "",
    "📣 *CRM faoliyati*",
    `Yuborilgan xabarlar: ${totalCrmSent} (konversiya: ${crm.convertedCount} ta xarid)`,
    `Faol mijozlar: ${crm.activeCustomers}, Nofaol: ${crm.inactiveCustomers}`,
  );
  if (crm.aiAutoActionsCount > 0) lines.push(`AI CEO avtomatik yuborgan xabarlar: ${crm.aiAutoActionsCount}`);
  if (crm.autoDiscountsIssuedCount > 0) lines.push(`AI CEO avtomatik chegirmalar: ${crm.autoDiscountsIssuedCount}`);

  const { vipCount, churnCount } = report.attentionNeeded;
  if (vipCount > 0 || churnCount > 0) {
    lines.push("", `⚠️ Diqqat talab qiladi: VIP ${vipCount} ta, uxlab qolgan ${churnCount} ta mijoz`);
  }

  if (report.aiActionPlan?.reasoning) {
    lines.push("", `_AI CEO tavsiyasi: ${report.aiActionPlan.reasoning}_`);
  }

  return lines.join("\n");
}

/**
 * Telegram `getFile` + fayl yuklab olish API'si orqali, rasm baytlarini
 * qaytaradi. Telegram fayl havolalari VAQTINCHALIK (odatda ~1 soat) -
 * shuning uchun DARHOL yuklab olib, o'zimizning Storage'imizga
 * ko'chirish SHART (`downloadUrl`ni to'g'ridan-to'g'ri saqlab
 * bo'lmaydi).
 */
async function downloadTelegramPhoto(token, fileId) {
  const fileRes = await fetch(`https://api.telegram.org/bot${token}/getFile?file_id=${fileId}`);
  const fileData = await fileRes.json();
  if (!fileData.ok) throw new Error(fileData.description || "Telegram fayl ma'lumotini olib bo'lmadi.");

  const downloadRes = await fetch(`https://api.telegram.org/file/bot${token}/${fileData.result.file_path}`);
  if (!downloadRes.ok) throw new Error("Telegram'dan rasmni yuklab olib bo'lmadi.");
  const buffer = Buffer.from(await downloadRes.arrayBuffer());
  return buffer;
}

/**
 * Rasm baytlarini Firebase Storage'ga (`products/{sellerId}/...` -
 * `storage.rules`dagi MAVJUD, mahsulot rasmlari uchun ochilgan yo'l
 * bilan BIR XIL) yozadi va client SDK bilan mos, ommaviy o'qiladigan
 * havola (`firebaseStorageDownloadTokens` orqali) qaytaradi - xuddi
 * mijoz ilova ICHIDAN rasm yuklaganda olinadigan havola shakli bilan
 * BIR XIL (shu orqali bu rasm keyinchalik oddiy mahsulot rasmi kabi,
 * hech qanday maxsus holatsiz ishlaydi).
 */
async function uploadPhotoToStorage(sellerId, buffer, index) {
  const bucket = admin.storage().bucket();
  const fileName = `products/${sellerId}/aiceo-bot-${Date.now()}-${index}.jpg`;
  const file = bucket.file(fileName);
  const downloadToken = crypto.randomUUID();

  await file.save(buffer, {
    metadata: { contentType: "image/jpeg", metadata: { firebaseStorageDownloadTokens: downloadToken } },
  });

  return `https://firebasestorage.googleapis.com/v0/b/${bucket.name}/o/${encodeURIComponent(fileName)}?alt=media&token=${downloadToken}`;
}

function sessionRef(sellerId) {
  return db.collection("sellers").doc(sellerId).collection("private").doc("aiCeoBotSession");
}

async function sendReply(token, chatId, text, keyboard) {
  await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      chat_id: chatId,
      text,
      parse_mode: "Markdown",
      reply_markup: keyboard,
    }),
  });
}

/**
 * "📊 AI CEO hisobotlari" tugmasi bosilganda.
 */
async function handleReportButton(token, sellerId, chatId) {
  const sellerSnap = await db.collection("sellers").doc(sellerId).get();
  if (!sellerSnap.exists || sellerSnap.data().aiCeoEnabled !== true) {
    await sendReply(token, chatId, "Bu funksiya faqat AI CEO premium mijozlari uchun mavjud.", buildMainMenuKeyboard());
    return;
  }

  try {
    await checkRateLimit(`aiCeoBotReport:${sellerId}`, 20, 3600);
  } catch (err) {
    await sendReply(token, chatId, err.message, buildMainMenuKeyboard());
    return;
  }

  try {
    const report = await buildDailyReport(sellerId, sellerSnap.data());
    const text = formatDailyReportForTelegram(report, sellerSnap.data().storeName);
    await sendReply(token, chatId, text, buildMainMenuKeyboard());
  } catch (err) {
    console.error(`Bot orqali kunlik hisobot xatosi (sotuvchi ${sellerId}):`, err);
    await sendReply(token, chatId, "Hisobotni tayyorlashda xatolik yuz berdi. Birozdan so'ng qayta urinib ko'ring.", buildMainMenuKeyboard());
  }
}

/**
 * "🤖 AI CEO bilan mahsulot qo'shish" tugmasi bosilganda - rasm
 * yig'ish sessiyasini boshlaydi. MUHIM: kunlik 4 tagacha cheklov BU
 * YERDA emas, FAQAT haqiqiy yakunlashda (`finalizeProductSession`)
 * tekshiriladi - shu orqali sotuvchi boshlab, bekor qilgan urinishlar
 * chegaraga HISOBLANMAYDI (Gemini haqiqatan chaqirilmaguncha).
 */
async function handleAddProductButton(token, sellerId, chatId) {
  const sellerSnap = await db.collection("sellers").doc(sellerId).get();
  if (!sellerSnap.exists || sellerSnap.data().aiCeoEnabled !== true) {
    await sendReply(token, chatId, "Bu funksiya faqat AI CEO premium mijozilari uchun mavjud.", buildMainMenuKeyboard());
    return;
  }

  await sessionRef(sellerId).set({
    mode: "awaiting_photos",
    photoUrls: [],
    startedAt: admin.firestore.FieldValue.serverTimestamp(),
  });

  await sendReply(
    token, chatId,
    `Mahsulot rasmlarini yuboring (${MAX_PHOTOS} tagacha). Tugatgach, "${FINISH_TEXT}" tugmasini bosing.`,
    buildPhotoCollectionKeyboard()
  );
}

/**
 * Rasm yig'ish jarayonida kelgan HAR BIR rasm uchun.
 */
async function handlePhotoMessage(token, sellerId, chatId, message) {
  const ref = sessionRef(sellerId);
  const snap = await ref.get();
  const session = snap.exists ? snap.data() : null;
  if (!session || session.mode !== "awaiting_photos") return; // sessiya YO'Q - jim e'tiborsiz qoldiramiz

  if ((session.photoUrls || []).length >= MAX_PHOTOS) {
    await sendReply(token, chatId, `Eng ko'pi bilan ${MAX_PHOTOS} ta rasm qabul qilinadi. "${FINISH_TEXT}" tugmasini bosing.`, buildPhotoCollectionKeyboard());
    return;
  }

  const largest = pickLargestPhoto(message.photo);
  if (!largest) return;

  try {
    const buffer = await downloadTelegramPhoto(token, largest.file_id);
    const url = await uploadPhotoToStorage(sellerId, buffer, (session.photoUrls || []).length);
    await ref.update({ photoUrls: admin.firestore.FieldValue.arrayUnion(url) });

    const newCount = (session.photoUrls || []).length + 1;
    if (newCount >= MAX_PHOTOS) {
      await sendReply(token, chatId, `Rasm qabul qilindi (${newCount}/${MAX_PHOTOS}). Endi AI CEO mahsulotni tayyorlashni boshlaydi...`);
      await finalizeProductSession(token, sellerId, chatId);
    } else {
      await sendReply(token, chatId, `Rasm qabul qilindi (${newCount}/${MAX_PHOTOS}). Yana rasm yuboring yoki "${FINISH_TEXT}" tugmasini bosing.`, buildPhotoCollectionKeyboard());
    }
  } catch (err) {
    console.error(`Bot orqali rasm qabul qilishda xatolik (sotuvchi ${sellerId}):`, err);
    await sendReply(token, chatId, "Rasmni qabul qilishda xatolik yuz berdi. Qaytadan yuborib ko'ring.", buildPhotoCollectionKeyboard());
  }
}

/**
 * "✅ Tayyor" bosilganda (yoki 4-rasmdan keyin AVTOMATIK) - YIG'ILGAN
 * rasmlar bilan qoralama yaratadi va DARHOL (soatlik navbatni
 * kutmasdan) `processDraft` orqali AI CEO'ga ishlov berdiradi.
 *
 * MUHIM, XARAJAT NAZORATI: kunlik 4 ta mahsulot chegarasi AYNAN shu
 * yerda, Gemini chaqirilishidan OLDIN tekshiriladi.
 */
async function finalizeProductSession(token, sellerId, chatId) {
  const ref = sessionRef(sellerId);
  const snap = await ref.get();
  const session = snap.exists ? snap.data() : null;
  const photoUrls = session?.photoUrls || [];

  if (photoUrls.length === 0) {
    await sendReply(token, chatId, "Hali birorta ham rasm yubormadingiz. Avval kamida bitta rasm yuboring.", buildPhotoCollectionKeyboard());
    return;
  }

  try {
    await checkRateLimit(`aiCeoBotProduct:${sellerId}`, MAX_AI_PRODUCTS_PER_DAY, AI_PRODUCT_WINDOW_SECONDS);
  } catch {
    await sendReply(
      token, chatId,
      `🚫 Kunlik chegara: AI CEO orqali bir kunda faqat ${MAX_AI_PRODUCTS_PER_DAY} tagacha mahsulot qo'shish mumkin. Ertaga qayta urinib ko'ring (yoki ilova ichidagi "Tez qo'shish" navbatidan foydalaning).`,
      buildMainMenuKeyboard()
    );
    await ref.delete();
    return;
  }

  await ref.delete(); // sessiya tugadi - keyingi urinish yangi sessiya bilan boshlanadi

  const draftRef = await db.collection("sellers").doc(sellerId).collection("productDrafts").add({
    imageUrls: photoUrls,
    rawHint: "",
    status: "queued",
    createdAt: admin.firestore.FieldValue.serverTimestamp(),
  });

  try {
    const ai = new GoogleGenAI({ apiKey: GEMINI_API_KEY.value() });
    await processDraft(ai, draftRef, { imageUrls: photoUrls, rawHint: "" });
    await sendReply(
      token, chatId,
      `✅ Mahsulot tayyor va tasdiqlashingizni kutmoqda!\n\nIlovani oching → Mahsulotlar → "Tasdiqlash kutilmoqda" bo'limi.`,
      buildMainMenuKeyboard()
    );
  } catch (err) {
    console.error(`Bot orqali mahsulot qoralamasini tayyorlashda xatolik (sotuvchi ${sellerId}):`, err);
    await draftRef.update({ status: "failed" }).catch(() => {});
    await sendReply(token, chatId, "AI CEO mahsulotni tayyorlay olmadi. Birozdan so'ng qayta urinib ko'ring.", buildMainMenuKeyboard());
  }
}

async function handleCancelButton(token, sellerId, chatId) {
  await sessionRef(sellerId).delete();
  await sendReply(token, chatId, "Bekor qilindi.", buildMainMenuKeyboard());
}

/**
 * Telegram webhook'ga kelgan `message` turidagi yangilanish uchun
 * ASOSIY yo'naltiruvchi - `telegramCallbackWebhook`dan chaqiriladi.
 * FAQAT haqiqiy sotuvchilardan (mavjud `sellers/{id}` hujjati bor)
 * kelgan xabarlarga javob beradi - boshqa har qanday xabar jim
 * e'tiborsiz qoldiriladi (masalan, kimdir botga tasodifan yozsa).
 */
async function handleTelegramMessage(token, message) {
  const sellerId = String(message?.from?.id || "");
  const chatId = message?.chat?.id;
  if (!sellerId || !chatId) return;

  if (message.photo) {
    await handlePhotoMessage(token, sellerId, chatId, message);
    return;
  }

  const text = (message.text || "").trim();
  if (!text) return;

  if (text === "/start") {
    const sellerSnap = await db.collection("sellers").doc(sellerId).get();
    if (!sellerSnap.exists) return; // faqat sotuvchilar - mijozlar bu bot bilan gaplashmaydi
    await sendReply(token, chatId, "Assalomu alaykum! Quyidagi tugmalardan birini tanlang.", buildMainMenuKeyboard());
    return;
  }

  if (text === MENU_REPORT_TEXT) {
    await handleReportButton(token, sellerId, chatId);
    return;
  }
  if (text === MENU_ADD_PRODUCT_TEXT) {
    await handleAddProductButton(token, sellerId, chatId);
    return;
  }
  if (text === FINISH_TEXT) {
    await finalizeProductSession(token, sellerId, chatId);
    return;
  }
  if (text === CANCEL_TEXT) {
    await handleCancelButton(token, sellerId, chatId);
    return;
  }
  // Boshqa erkin matn - sessiya rasm kutayotgan bo'lsa, eslatib qo'yamiz.
  const session = await sessionRef(sellerId).get();
  if (session.exists && session.data().mode === "awaiting_photos") {
    await sendReply(token, chatId, `Iltimos, rasm yuboring yoki "${FINISH_TEXT}"/"${CANCEL_TEXT}" tugmasini bosing.`, buildPhotoCollectionKeyboard());
  }
}

module.exports = {
  MENU_REPORT_TEXT, MENU_ADD_PRODUCT_TEXT, FINISH_TEXT, CANCEL_TEXT,
  MAX_PHOTOS, MAX_AI_PRODUCTS_PER_DAY,
  buildMainMenuKeyboard, buildPhotoCollectionKeyboard, pickLargestPhoto,
  formatDailyReportForTelegram, handleTelegramMessage,
  _testables: { downloadTelegramPhoto, uploadPhotoToStorage, finalizeProductSession, handleReportButton, handleAddProductButton, handlePhotoMessage, handleCancelButton },
};
