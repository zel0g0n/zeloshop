const { onSchedule } = require("firebase-functions/v2/scheduler");
const { admin, db } = require("./lib/admin");

/**
 * AI CEO — 7-BOSQICH: "NATIJA KUZATUVI VA O'RGANISH" (foydalanuvchi
 * tanlagan 4-bosqichli "avtonom agent" yo'l xaritasining 3-FAZASI;
 * 1-faza — v23'dagi `craftActionPlan` (`aiCeo.js`), 2-faza — v24'dagi
 * tool-calling arxitekturasi (`aiCeoAgent.js`)).
 *
 * MUHIM, ARXITEKTURAVIY MA'NOSI: 1/2-fazalargacha AI CEO faqat MATN
 * YOZAR yoki QAROR QABUL QILAR edi - lekin O'SHA matn/qarorning REAL
 * HAYOTDA qanday natija berganini HECH QACHON bilmasdi (yozib
 * yuborgach, "unutib" ketardi). Bu fayl - AI CEO'ning TIER-1 avtonom
 * xabarlari (`engagementReminders.js`dagi avtomatik qaytarish/
 * sevimlilar eslatmasi) uchun HAQIQIY natijani (mijoz keyinroq XARID
 * QILDIMI) KUZATIB boradi va shu natijani AI'ning O'ZIGA - keyingi
 * safar xuddi shu turdagi xabarni yozayotganda - QAYTARIB beradi
 * (`getRecentAiPerformance`, `aiCeo.js`dagi promptlarga qarang) - bu,
 * "o'z-o'zini yaxshilash" qatlami.
 *
 * NEGA ALOHIDA FAYL: bu - qayta ishlatiladigan, umumiy "o'rganish"
 * infratuzilmasi (kelajakda 4-faza HAM shu naqshni davom ettirishi
 * mumkin) - `aiCeo.js`ning matn yozish mantig'idan MUSTAQIL.
 *
 * XAVFSIZLIK/ISHONCHLILIK: bu modulning HECH BIR funksiyasi xato
 * TASHLAMAYDI (hammasi ICHKI try/catch bilan o'ralgan, jim log
 * yozadi) - natija kuzatuvi ASOSIY funksiyaning (eslatma yuborish)
 * ishlashiga HECH QACHON ta'sir qilmasligi kerak, xuddi
 * `lib/dailyStats.js`dagi `incrementDailyStat` kabi.
 *
 * MA'LUMOT SAQLASH: `sellers/{id}/aiCeoOutcomes/{outcomeId}` - HAR BIR
 * yuborilgan avtonom xabar uchun bitta hujjat (`type`, `clientId`,
 * `aiGenerated`, `sentAtMs`, `status`: "pending"/"converted"/
 * "not_converted"). `sellers/{id}/aiCeoLearning/summary` - shu
 * hujjatlardan YIG'ILGAN, TEZ o'qiladigan agregat hisoblagichlar
 * (`winbackAiSent`, `winbackAiConverted`, `winbackTemplateSent`,
 * `winbackTemplateConverted`, va xuddi shunday `favorite*` 4tasi) -
 * FAQAT flat (ichma-ich EMAS) maydonlar, Firestore nuqta-yo'l
 * (dot-path) murakkabligidan ATAYLAB qochish uchun.
 */

const DAY_MS = 24 * 60 * 60 * 1000;

// Xabar yuborilgandan keyin, mijoz "xarid qildimi" tekshiriladigan
// oyna - 7 kun (odatiy xarid qarori qabul qilish muddati uchun
// yetarli, lekin cheksiz emas - eski xabarlar abadiy "pending" bo'lib
// qolmasligi uchun).
const EVALUATION_WINDOW_DAYS = 7;

// Bir sotuvchi uchun, bir yugurishda ko'rib chiqiladigan maksimal
// "pending" hujjatlar soni - `engagementReminders.js`dagi
// `MAX_FAVORITES_PER_RUN`/`MAX_ORDERS_PER_RUN` bilan BIR XIL xavfsizlik
// chegarasi naqshi.
const MAX_PENDING_PER_SELLER_PER_RUN = 500;

// Kamida shuncha AI-yozgan xabar EVALUATSIYA qilinmaguncha (ya'ni
// haqiqiy natija ma'lum bo'lmaguncha), konversiya darajasi Gemini'ga
// KO'RSATILMAYDI - juda kichik namunada (masalan 1ta xabardan 0% yoki
// 100%) noto'g'ri, chalg'ituvchi xulosaga olib kelmasligi uchun.
const MIN_SAMPLE_SIZE = 5;

function learningSummaryRef(sellerId) {
  return db.collection("sellers").doc(sellerId).collection("aiCeoLearning").doc("summary");
}

function outcomesCollectionRef(sellerId) {
  return db.collection("sellers").doc(sellerId).collection("aiCeoOutcomes");
}

/**
 * SOF FUNKSIYA - agregat hisoblagich hujjatidagi FLAT maydon nomini
 * quradi (masalan "winbackAiSent", "favoriteTemplateConverted").
 */
function summaryFieldName(type, aiGenerated, suffix) {
  return `${type}${aiGenerated ? "Ai" : "Template"}${suffix}`;
}

/**
 * Har bir avtonom (Tier-1) xabar MUVAFFAQIYATLI YUBORILGANDA
 * chaqiriladi - "kim, qachon, qanday (AI yozganmi yoki oddiy
 * shablonmi) xabar oldi"ni alohida hujjat sifatida yozadi VA umumiy
 * "yuborildi" hisoblagichini oshiradi.
 *
 * @param {object} params
 * @param {string} params.sellerId
 * @param {"winback"|"favorite"} params.type
 * @param {string} params.clientId
 * @param {boolean} params.aiGenerated - matnni AI yozganmi (aks holda oddiy shablon)
 * @param {boolean} [params.discountIssued] - YANGI (8-BOSQICH — "avtonom
 *   harakatlar doirasini kengaytirish", batafsil izoh: `aiCeoAutoDiscount.js`):
 *   shu xabar bilan birga HAQIQIY, bir martalik chegirma kodi ham
 *   avtomatik yaratilib yuborilganmi. FAQAT audit/keyingi tahlil uchun
 *   saqlanadi - hozircha baholash (`evaluateSellerOutcomes`) yoki
 *   agregat hisoblagichlar mantig'iga TA'SIR QILMAYDI.
 */
async function recordAiCeoOutcome({ sellerId, type, clientId, aiGenerated, discountIssued = false }) {
  if (!sellerId || !clientId || !type) return;
  try {
    await outcomesCollectionRef(sellerId).add({
      type,
      clientId,
      aiGenerated: aiGenerated === true,
      discountIssued: discountIssued === true,
      status: "pending",
      sentAtMs: Date.now(),
    });
    await learningSummaryRef(sellerId).set(
      { [summaryFieldName(type, aiGenerated === true, "Sent")]: admin.firestore.FieldValue.increment(1) },
      { merge: true }
    );
  } catch (err) {
    console.error(`AI CEO natija kuzatuvini yozishda xatolik (${type}, sotuvchi ${sellerId}):`, err);
  }
}

/**
 * `craftWinBackMessage`/`craftFavoriteReminderMessage` chaqirilishidan
 * OLDIN o'qiladi - AI'ning O'ZI shu turdagi xabarlar bo'yicha O'TGAN,
 * HAQIQIY (evaluatsiya qilingan) natijasini biladi va shunga qarab
 * yozish uslubini moslashtirishi mumkin ("o'rganish" qatlami, batafsil
 * izoh - fayl boshida). Namuna hali YETARLI bo'lmasa (`MIN_SAMPLE_SIZE`
 * dan kam) yoki hujjat mavjud bo'lmasa - `null` qaytaradi, chaqiruvchi
 * tomon buni "ma'lumot yo'q" deb tushunadi va promptga hech narsa
 * qo'shmaydi (standart, ATAYLAB xavfsiz xatti-harakat).
 *
 * @param {string} sellerId
 * @param {"winback"|"favorite"} type
 */
async function getRecentAiPerformance(sellerId, type) {
  try {
    const snap = await learningSummaryRef(sellerId).get();
    if (!snap.exists) return null;
    const data = snap.data() || {};
    const sentCount = Number(data[summaryFieldName(type, true, "Sent")]) || 0;
    const convertedCount = Number(data[summaryFieldName(type, true, "Converted")]) || 0;
    if (sentCount < MIN_SAMPLE_SIZE) return null;
    return { sentCount, convertedCount, conversionRatePercent: Math.round((convertedCount / sentCount) * 100) };
  } catch (err) {
    console.error(`AI CEO oldingi natijasini o'qishda xatolik (${type}, sotuvchi ${sellerId}):`, err);
    return null;
  }
}

/**
 * SOF FUNKSIYA - `aiCeoLearning/summary` hujjatining XOM (flat)
 * maydonlarini, frontend'ga (VA `askAiCeo`ning yangi vositasiga)
 * qulay, INSON O'QIY OLADIGAN shaklga aylantiradi. `sentCount === 0`
 * bo'lgan turlar `null` qaytariladi - hali umuman xabar yuborilmagan
 * (yoki AI CEO endigina yoqilgan) sotuvchiga bo'sh/chalg'ituvchi "0%"
 * ko'rsatilmasligi uchun.
 */
function buildLearningSummaryForDisplay(rawData) {
  const data = rawData || {};
  const buildType = (type) => {
    const sentCount = Number(data[summaryFieldName(type, true, "Sent")]) || 0;
    if (sentCount === 0) return null;
    const convertedCount = Number(data[summaryFieldName(type, true, "Converted")]) || 0;
    return { sentCount, convertedCount, conversionRatePercent: Math.round((convertedCount / sentCount) * 100) };
  };
  return { winback: buildType("winback"), favorite: buildType("favorite") };
}

/**
 * Bitta sotuvchining "pending" (hali baholanmagan) natijalarini ko'rib
 * chiqadi - `EVALUATION_WINDOW_DAYS` kun to'lganlarni HAQIQIY buyurtma
 * tarixi bilan solishtirib, "konversiya bo'ldimi" hal qiladi.
 */
async function evaluateSellerOutcomes(sellerId) {
  const cutoffMs = Date.now() - EVALUATION_WINDOW_DAYS * DAY_MS;
  const pendingSnap = await outcomesCollectionRef(sellerId)
    .where("status", "==", "pending")
    .limit(MAX_PENDING_PER_SELLER_PER_RUN)
    .get();
  if (pendingSnap.empty) return;

  for (const outcomeDoc of pendingSnap.docs) {
    const outcome = outcomeDoc.data();
    // Hali baholash vaqti KELMAGAN (oyna to'lmagan) - keyingi
    // yugurishda qayta ko'rib chiqiladi.
    if (!outcome.sentAtMs || outcome.sentAtMs > cutoffMs) continue;

    try {
      // MIJOZ O'SHA XABARDAN KEYIN YANGI buyurtma berganmi -
      // `sendRepurchaseReminders`dagi "qayta buyurtma bergani"
      // tekshiruvi bilan BIR XIL naqsh.
      const newerOrderSnap = await db.collection("orders")
        .where("sellerId", "==", sellerId)
        .where("clientId", "==", outcome.clientId)
        .where("createdAt", ">", admin.firestore.Timestamp.fromMillis(outcome.sentAtMs))
        .limit(1)
        .get();
      const converted = !newerOrderSnap.empty;

      await outcomeDoc.ref.update({
        status: converted ? "converted" : "not_converted",
        evaluatedAtMs: Date.now(),
      });

      if (converted) {
        await learningSummaryRef(sellerId).set(
          { [summaryFieldName(outcome.type, outcome.aiGenerated === true, "Converted")]: admin.firestore.FieldValue.increment(1) },
          { merge: true }
        );
      }
    } catch (err) {
      console.error(`AI CEO natijasini baholashda xatolik (${outcomeDoc.id}, sotuvchi ${sellerId}):`, err);
    }
  }
}

exports.evaluateAiCeoOutcomes = onSchedule(
  // MUHIM: mavjud `sendFavoriteReminders`(12:00)/`sendRepurchaseReminders`
  // (13:00)dan OLDIN, ertalab ishlaydi - shu kuni yuboriladigan YANGI
  // xabarlar bilan "aralashib" ketmasligi uchun (garchi mantiqiy jihatdan
  // muammo bo'lmasa ham, vaqt jihatdan ajratish tushunarliroq).
  { schedule: "0 9 * * *", timeZone: "Asia/Tashkent", region: "asia-south1" },
  async () => {
    // 1-XARAJAT NAZORATI (kolleksiya darajasida): faqat
    // `aiCeoEnabled == true` bo'lgan sotuvchilarni ko'rib chiqamiz -
    // boshqa hech kim uchun HATTO BITTA `aiCeoOutcomes` hujjati ham
    // yaratilmagan (`recordAiCeoOutcome` shu bayroqqa qarab yozadi),
    // shuning uchun ularni tekshirishning ma'nosi yo'q.
    const eligibleSellersSnap = await db.collection("sellers").where("aiCeoEnabled", "==", true).get();
    if (eligibleSellersSnap.empty) return;

    for (const sellerDoc of eligibleSellersSnap.docs) {
      try {
        await evaluateSellerOutcomes(sellerDoc.id);
      } catch (err) {
        console.error(`AI CEO natija baholashda xatolik (sotuvchi ${sellerDoc.id}):`, err);
      }
    }
  }
);

exports.recordAiCeoOutcome = recordAiCeoOutcome;
exports.getRecentAiPerformance = getRecentAiPerformance;
exports.buildLearningSummaryForDisplay = buildLearningSummaryForDisplay;
exports.learningSummaryRef = learningSummaryRef;

exports._testables = {
  recordAiCeoOutcome,
  getRecentAiPerformance,
  buildLearningSummaryForDisplay,
  evaluateSellerOutcomes,
  summaryFieldName,
};
