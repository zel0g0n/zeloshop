const { onSchedule } = require("firebase-functions/v2/scheduler");
const { GoogleGenAI } = require("@google/genai");
const { admin, db, BOT_TOKEN, GEMINI_API_KEY } = require("./lib/admin");
const { sendTelegramMessage } = require("./lib/helpers");

/**
 * AI CEO — 2-BOSQICH: MAHSULOT QORALAMASINI TAYYORLASH.
 *
 * OQIM: sotuvchi kun davomida (`submitProductDraft` — TO'G'RIDAN-
 * TO'G'RI mijoz tomonidan Firestore'ga yoziladi, alohida Cloud
 * Function SHART EMAS, xuddi oddiy `addProduct` kabi) faqat RASM +
 * QISQA IZOH bilan "navbatga" mahsulot qo'shadi - to'liq forma
 * to'ldirmaydi. Kechqurun (bu funksiya) AI ularni qayta ishlaydi:
 * tavsif yozadi + kategoriya taklif qiladi. Sotuvchi ilovani
 * ochganda, tayyor qoralamalarni bir necha soniyada ko'rib chiqadi.
 *
 * MUHIM (halollik / xato ovlash): AI narxni TAKLIF QILMAYDI - faqat
 * rasm/nomdan narxni "taxmin qilish" ishonchsiz bo'lardi (haqiqiy
 * bozor ma'lumoti yo'q), bu yolg'on ma'lumot berish bilan teng.
 * Kategoriya ham FAQAT tavsiya sifatida beriladi - YAKUNIY tanlov
 * har doim sharhlash ekranidagi HAQIQIY, tasdiqlangan kategoriyalar
 * ro'yxatidan (`getCategoriesForNiche`) bo'ladi, AI matnidan emas -
 * shu orqali noto'g'ri/mavjud bo'lmagan kategoriya hech qachon
 * saqlanmaydi.
 *
 * XARAJAT NAZORATI: xuddi `aiCeo.js`dagi kabi - faqat
 * `aiCeoEnabled===true` sotuvchilar, faqat `status:"queued"`
 * qoralamalar mavjud bo'lsagina ko'rib chiqiladi.
 */

const MODEL = "gemini-3.5-flash-lite";

// MUHIM: bu ro'yxat frontenddagi `src/constants/productCategories.js`
// faylidagi `NICHE_CATEGORIES["Kosmetika"]`ning `value`lari bilan AYNAN
// BIR XIL bo'lishi SHART (xuddi `deliveryTiers.js` kabi - Cloud
// Functions frontend kodini import qila olmaydi, shuning uchun
// dublikat qilinadi). Platforma hozircha FAQAT kosmetika sohasi bilan
// ishga tushirilgani uchun (`FIXED_NICHE`, `CreateStoreScreen.jsx`),
// bu yerda ham qattiq shu ro'yxat ishlatiladi - agar kelajakda boshqa
// sohalar qo'shilsa, bu ham sotuvchining haqiqiy sohasiga qarab
// dinamik tanlanadigan bo'lishi kerak.
const KOSMETIKA_CATEGORIES = [
  "Yuz parvarishi",
  "Dekorativ kosmetika",
  "Soch parvarishi",
  "Tana parvarishi",
  "Parfyumeriya",
  "Tirnoq parvarishi",
  "Erkaklar uchun",
  "Asboblar va aksessuarlar",
];

function buildDraftPrompt(rawHint, hasImage, categoryNames = KOSMETIKA_CATEGORIES) {
  const hintLine = rawHint
    ? `Sotuvchi izohi: "${rawHint}"`
    : "Sotuvchi hech qanday izoh qoldirmagan - FAQAT rasmga qarab aniqla.";

  return `Sen — onlayn kosmetika/go'zallik do'koni uchun mahsulot ma'lumotini tayyorlovchi tajribali kontent yozuvchisisan.
${hasImage ? "Ilova qilingan RASM(LAR)ga qarab" : "Quyidagi izoh asosida"}, UCHTA narsani tayyorla:

${hintLine}

1. NOM: qisqa, aniq mahsulot nomi (masalan "Qora rangli teri krem, 50ml").

2. TAVSIF: O'ZBEK TILIDA, batafsil (4-6 gap, taxminan 80-150 so'z) mahsulot tavsifi. BU ODDIY REKLAMA GAPI EMAS - quyidagi UCH qismni albatta qamrab ol:
   a) Mahsulotning HAQIQIY xususiyatlari - tarkibi/materiali, hajmi/miqdori, ko'rinishi, rasm(lar)da haqiqatan ko'rinib turgan belgilar asosida.
   b) Foydalanish yo'riqnomasi - qanday va qachon qo'llash/ishlatish kerakligi haqida aniq, amaliy tavsiya.
   c) Foydaliligi - bu xususiyatlar xaridorga aniq qanday foyda/natija berishi (umumiy "ajoyib mahsulot" kabi bo'sh, "oldi-qochdi" gaplar EMAS - har bir da'vo aniq xususiyatga bog'langan bo'lishi kerak).

3. KATEGORIYA: albatta va FAQAT quyidagi ro'yxatdan BITTASINI, ro'yxatda yozilganidek AYNAN o'sha shaklda tanla (boshqa so'z qo'shma, tarjima qilma) - rasmda ko'rinib turgan mahsulot turiga ENG mos kelganini tanla:
${categoryNames.map((c) => `- ${c}`).join("\n")}

QOIDALAR:
- Aniq raqamli da'volar (masalan "99% samarali") ISHLATMA - buni tekshirib bo'lmaydi.
${hasImage ? "- TAVSIF va KATEGORIYA uchun rasm(lar)da haqiqatan ko'rinib turgan narsalarga tayan - o'zingdan to'qima." : ""}
- Javobni FAQAT quyidagi formatda ber, boshqa hech narsa yozma:
NOM: <mahsulot nomi>
TAVSIF: <tavsif matni>
KATEGORIYA: <ro'yxatdagi kategoriya nomi>`;
}

/**
 * Gemini javobini {name, description, category} ga ajratadi. SOF
 * FUNKSIYA - to'g'ridan-to'g'ri test qilinadi (Gemini matn formatini
 * har doim to'g'ri qaytarishiga 100% kafolat yo'q, shuning uchun bu
 * parser ISHONCHLI bo'lishi juda muhim).
 */
function parseDraftResponse(rawText) {
  const nameMatch = rawText.match(/NOM:\s*(.+?)(?=\nTAVSIF:|$)/s);
  const descMatch = rawText.match(/TAVSIF:\s*(.+?)(?=\nKATEGORIYA:|$)/s);
  const catMatch = rawText.match(/KATEGORIYA:\s*(.+?)$/s);
  return {
    name: nameMatch ? nameMatch[1].trim() : null,
    description: descMatch ? descMatch[1].trim() : rawText.trim(),
    category: catMatch ? catMatch[1].trim() : null,
  };
}

async function processDraft(ai, draftRef, draft) {
  // MUHIM: eski qoralamalar BITTA `imageUrl` (satr) bilan yozilgan,
  // yangilari esa `imageUrls` (4 tagacha rasm massivi,
  // `QuickAddAICard.jsx`dan) bilan yoziladi - ikkalasini ham
  // qo'llab-quvvatlaymiz.
  const imageUrls = Array.isArray(draft.imageUrls) && draft.imageUrls.length > 0
    ? draft.imageUrls
    : draft.imageUrl
    ? [draft.imageUrl]
    : [];

  // Rasm URL'laridan bevosita Gemini'ga base64 sifatida yuborish uchun,
  // avval ularni yuklab olishimiz kerak (Firebase Storage ochiq URL).
  // Bir nechta rasm bo'lsa, HAMMASI bitta so'rovda AI'ga yuboriladi -
  // shu orqali AI mahsulotni turli burchaklardan/qadoq tomonidan
  // ko'rib, aniqroq tavsif va kategoriya taklif qila oladi.
  const imageParts = [];
  for (const url of imageUrls) {
    try {
      const res = await fetch(url);
      const buffer = Buffer.from(await res.arrayBuffer());
      imageParts.push({ inlineData: { mimeType: res.headers.get("content-type") || "image/jpeg", data: buffer.toString("base64") } });
    } catch (err) {
      console.error("Qoralama rasmini yuklab olishda xatolik:", err);
    }
  }

  const textPrompt = buildDraftPrompt(draft.rawHint || "", imageParts.length > 0, KOSMETIKA_CATEGORIES);
  const contents = imageParts.length > 0
    ? [{ role: "user", parts: [{ text: textPrompt }, ...imageParts] }]
    : textPrompt;

  const response = await ai.models.generateContent({ model: MODEL, contents });
  const { name, description, category } = parseDraftResponse((response.text || "").trim());

  if (!description) throw new Error("AI bo'sh javob qaytardi.");

  await draftRef.update({
    status: "ready_for_review",
    aiName: name || draft.rawHint || null,
    aiDescription: description,
    aiCategory: category,
    processedAt: admin.firestore.FieldValue.serverTimestamp(),
  });
}

// MUHIM, YAKUNIY YAXSHILANISH: OLDIN bu funksiya FAQAT kuniga bir marta,
// QATTIQ BELGILANGAN 21:00da (Toshkent vaqti) ishga tushardi - BARCHA
// sotuvchilar uchun BIR XIL, o'zgartirib bo'lmaydigan vaqt edi.
// Foydalanuvchi buni "sotuvchi vaqtni o'zi belgilashi kerak" deb
// to'g'ri tanqid qildi. Endi funksiya HAR SOATDA ishga tushadi, lekin
// har bir sotuvchini FAQAT ular o'zlari TANLAGAN soatda (yangi
// `aiCeoDraftProcessHour` maydoni, standart holatda 21 - hech kim
// o'zgartirmagan bo'lsa, AVVALGI xatti-harakat bilan BIR XIL
// bo'lib qolaveradi) qayta ishlaydi.
exports.processProductDrafts = onSchedule(
  { schedule: "0 * * * *", timeZone: "Asia/Tashkent", region: "asia-south1", secrets: [BOT_TOKEN, GEMINI_API_KEY] },
  async () => {
    const currentHour = new Date().toLocaleString("en-US", { timeZone: "Asia/Tashkent", hour: "2-digit", hour12: false });
    const currentHourNum = parseInt(currentHour, 10) % 24; // "24" holatini "0"ga aylantirish uchun

    const eligibleSellersSnap = await db.collection("sellers").where("aiCeoEnabled", "==", true).get();
    if (eligibleSellersSnap.empty) return;

    const ai = new GoogleGenAI({ apiKey: GEMINI_API_KEY.value() });

    // XAVFSIZLIK CHEGARASI: bitta sotuvchi uchun, bitta yugurishda,
    // ENG KO'PI BILAN shuncha qoralama qayta ishlanadi. `submitProductDraft`
    // (mijoz tomonida, to'g'ridan-to'g'ri Firestore'ga yoziladi - Cloud
    // Function orqali EMAS, chunki u yerda ishonchsiz/moliyaviy ma'lumot
    // yo'q) hech qanday server-tomon cheklovga ega EMAS - agar biror
    // xato yoki takroriy bosish tufayli navbatga minglab qoralama
    // yig'ilib qolsa, bu YERDAGI chegara bo'lmasa, BARCHASI bitta
    // yugurishda qayta ishlanardi - ya'ni NAZORATSIZ, minglab Gemini
    // so'rovi va haqiqiy pul xarajati. Qolgan qoralamalar keyingi
    // kunlarga o'tkaziladi (status "queued" bo'lib qolaveradi).
    const MAX_DRAFTS_PER_SELLER_PER_RUN = 30;

    for (const sellerDoc of eligibleSellersSnap.docs) {
      const sellerId = sellerDoc.id;
      const sellerData = sellerDoc.data();
      const preferredHour = Number.isInteger(sellerData.aiCeoDraftProcessHour) ? sellerData.aiCeoDraftProcessHour : 21;

      // Sotuvchining TANLAGAN soati hozirgi soat bilan mos kelmasa,
      // shunchaki O'TKAZIB YUBORAMIZ - u KEYINGI mos soatda qayta
      // tekshiriladi (bu funksiya har soatda ishga tushadi).
      if (preferredHour !== currentHourNum) continue;

      try {
        const queuedSnap = await db.collection("sellers").doc(sellerId).collection("productDrafts")
          .where("status", "==", "queued")
          .limit(MAX_DRAFTS_PER_SELLER_PER_RUN)
          .get();

        if (queuedSnap.empty) continue;

        let processedCount = 0;
        for (const draftDoc of queuedSnap.docs) {
          try {
            await processDraft(ai, draftDoc.ref, draftDoc.data());
            processedCount += 1;
          } catch (err) {
            console.error(`Mahsulot qoralamasini qayta ishlashda xatolik (${sellerId}/${draftDoc.id}):`, err);
            await draftDoc.ref.update({ status: "failed" }).catch(() => {});
          }
        }

        if (processedCount > 0) {
          const customBotSnap = await db.collection("sellers").doc(sellerId).collection("private").doc("customerBot").get();
          const token = customBotSnap.exists && customBotSnap.data().botToken ? customBotSnap.data().botToken : BOT_TOKEN.value();
          const text = `AI CEO\n\n${processedCount} ta mahsulot tayyorlandi va tasdiqlashingizni kutmoqda!\n\nIlovani oching → Mahsulotlar → "Tasdiqlash kutilmoqda" bo'limi.`;
          await sendTelegramMessage(token, sellerId, text);
        }
      } catch (err) {
        console.error(`Sotuvchi ${sellerId} uchun qoralamalarni qayta ishlashda xatolik:`, err);
      }
    }
  }
);

// `processDraft` - QAYTA ISHLATISH uchun HAQIQIY (test uchun emas)
// eksport: `telegramBotMenu.js`dagi "AI CEO bilan mahsulot qo'shish"
// bot-suhbat oqimi BIR XIL Gemini prompt/tahlil mantig'idan
// foydalanadi, faqat SOATLIK navbat o'rniga DARHOL (sotuvchi botda
// rasm yuborgan zahoti) chaqiradi - ikki xil "kirish yo'li" (ilova
// ICHIDAN yoki bot CHATIDAN) bitta, ALLAQACHON tekshirilgan mantiqqa
// tayanadi (xuddi oddiy forma va AI qoralamasi bitta `addProduct()`ga
// tayangani kabi).
exports.processDraft = processDraft;
exports.KOSMETIKA_CATEGORIES = KOSMETIKA_CATEGORIES;

exports._testables = { buildDraftPrompt, parseDraftResponse };
