const { admin, db } = require("./lib/admin");

/**
 * AI CEO — 8-BOSQICH: "AVTONOM HARAKATLAR DOIRASINI KENGAYTIRISH"
 * (foydalanuvchi tanlagan 4-bosqichli "avtonom agent" yo'l xaritasining
 * SO'NGGI, 4-FAZASI; 1-faza — v23'dagi `craftActionPlan` (`aiCeo.js`),
 * 2-faza — v24'dagi tool-calling arxitekturasi (`aiCeoAgent.js`),
 * 3-faza — v25'dagi natija kuzatuvi/o'rganish (`aiCeoLearning.js`)).
 *
 * MUHIM, ARXITEKTURAVIY MA'NOSI: 1-3 fazalargacha AI CEO'ning avtonom
 * (Tier-1) harakatlari FAQAT matn yozish/yuborish edi - moliyaviy
 * oqibati YO'Q, to'liq qaytariladigan (bir marta noqulay xabar
 * yuborilsa ham, hech qanday HAQIQIY zarar yo'q). Foydalanuvchi
 * ATAYLAB so'ragan "doirani kengaytirish" endi HAQIQIY moliyaviy
 * oqibatga ega bo'lgan harakatga - mijozga AVTOMATIK, sotuvchi
 * tasdiqisiz, HAQIQIY chegirma promokod berish - o'tadi. Shuning
 * uchun bu YERDA "ishonch zinapoyasi" ANCHA QATTIQROQ:
 *
 *   1) OPT-IN, ALOHIDA: `aiCeoAutoDiscountEnabled === true` (standart
 *      holatda O'CHIQ) - bu, `aiCeoAutoWinBackEnabled`dan MUSTAQIL,
 *      QO'SHIMCHA yoqilishi kerak bo'lgan sozlama (sotuvchi "matnni AI
 *      yozsin" deganida AVTOMATIK "va pul chegirma bersin ham" degani
 *      EMAS).
 *   2) BOG'LIQLIK: FAQAT `aiCeoAutoWinBackEnabled === true` bo'lganda
 *      ishlaydi (bu - o'sha avtomatik "qaytarish" xabarining KUCHAY-
 *      TIRILGAN varianti, mustaqil funksiya EMAS).
 *   3) ISBOTLANGAN NATIJA ASOSIDA (foydalanuvchi ANIQ shu tarzda
 *      so'ragan talab): FAQAT 3-fazada (`aiCeoLearning.js`) yig'ilgan
 *      HAQIQIY, kamida `MIN_SAMPLE_SIZE` namunali konversiya darajasi
 *      MAVJUD bo'lsagina (`recentPerformance !== null`) VA bu daraja
 *      PAST (`AUTO_DISCOUNT_ELIGIBLE_MAX_CONVERSION_PERCENT`dan kam)
 *      bo'lsagina harakatga o'tadi - ya'ni "AI matni YETARLI darajada
 *      ISHLAMAYAPTI" ISBOTLANGANDAGINA, keyingi, KUCHLIROQ vosita
 *      (haqiqiy chegirma) qo'llaniladi. Agar matn ALLAQACHON yaxshi
 *      ishlayotgan bo'lsa (yuqori konversiya) - chegirma HECH QACHON
 *      berilmaydi, chunki bunga ehtiyoj ISBOTLANMAGAN.
 *   4) MOLIYAVIY XAVFNI CHEKLASH: FAQAT foiz (percent) turidagi
 *      chegirma (aniq summa - "fixed" - EMAS, chunki bu nazoratsiz
 *      moliyaviy ta'sir qilishi mumkin edi), qat'iy chegaralangan
 *      oralig'ida (`MIN_DISCOUNT_PERCENT`..`MAX_DISCOUNT_PERCENT`),
 *      BIR MARTALIK (`usageLimit: 1`), FAQAT o'sha bitta mijoz uchun
 *      (`rewardForClientId`), QISQA muddatli (`DISCOUNT_EXPIRY_DAYS`),
 *      va bitta ishga tushirishda, bitta sotuvchi uchun MAKSIMAL sonli
 *      (`MAX_AUTO_DISCOUNTS_PER_SELLER_PER_RUN`) - hatto kutilmagan xato
 *      bo'lsa ham, zarar CHEGARALANGAN qoladi.
 *   5) HECH QANDAY HALLUSINATSIYA XAVFI: `aiCeo.js`dagi CRM kampaniyasi
 *      izohida (`buildActionPlanPrompt` yaqinida) ALLAQACHON qat'iy
 *      belgilangan qoidaga to'liq mos - Gemini/AI HECH QACHON promokod
 *      matnini "o'ylab topmaydi". Bu yerda promokod HAQIQIY, DETERMINISTIK
 *      (oddiy dastur kodi) tomonidan, `carts.js`dagi "tashlab ketilgan
 *      savat" chegirmasi bilan BIR XIL, sinovdan o'tgan sxema bo'yicha
 *      yaratiladi - Gemini bu jarayonda UMUMAN ISHTIROK ETMAYDI (AI
 *      YOZGAN xabar matni - `aiCeo.js`dagi `craftWinBackMessage` - va
 *      chegirma qatori BUTUNLAY ALOHIDA, `engagementReminders.js`da
 *      birlashtiriladi).
 *   6) SHAFFOFLIK: har bir avtomatik yaratilgan promokod ODDIY,
 *      MAVJUD `sellers/{id}/coupons` kolleksiyasiga yoziladi - sotuvchi
 *      buni "Promokodlar" sahifasida (`MarketingCoupons.jsx`) MAXSUS
 *      belgi ("AI CEO qaytarish mukofoti") bilan, boshqa promokodlar
 *      kabi TO'LIQ ko'rib, xohlasa O'CHIRIB tashlashi mumkin - hech
 *      qanday "yashirin" harakat yo'q. Bundan tashqari, kunlik hisobotda
 *      (`aiCeo.js`dagi `crmActivity.autoDiscountsIssuedCount`) va "AI
 *      CEO'dan so'rang" vositasida (`aiCeoAgent.js`dagi
 *      `get_recent_auto_discounts`) ham ko'rinadi.
 *
 * XAVFSIZLIK/ISHONCHLILIK: `maybeIssueAutoWinBackDiscount` HECH QACHON
 * xato TASHLAMAYDI (ichki try/catch) - chegirma yaratib bo'lmasa,
 * ASOSIY xabar (matn) baribir yuboriladi, faqat chegirmasiz - xuddi
 * boshqa barcha "avtonom" funksiyalar kabi (`aiCeoLearning.js`,
 * `lib/dailyStats.js`).
 */

const DAY_MS = 24 * 60 * 60 * 1000;

// Sotuvchi tanlashi mumkin bo'lgan foiz oralig'i - ikkalasi ham
// "haddan tashqari" bo'lmasligi uchun qat'iy chegaralangan (juda kichik
// bo'lsa mijozni qiziqtirmaydi, juda katta bo'lsa moliyaviy xavfli).
const MIN_DISCOUNT_PERCENT = 5;
const MAX_DISCOUNT_PERCENT = 20;
const DEFAULT_DISCOUNT_PERCENT = 10;

// Promokod amal qilish muddati - `carts.js`dagi 24 soatlik "shoshilinchlik"
// dan FARQLI: bu yerda mijoz ALLAQACHON 30+ kundan beri xarid qilmagan
// (shoshilinch emas, "uxlab qolgan"), shuning uchun ko'proq vaqt beriladi.
const DISCOUNT_EXPIRY_DAYS = 7;

// MUHIM: `aiCeo.js`dagi `buildRecentPerformanceLine`dagi "past natija"
// chegarasi (15%) bilan ATAYLAB BIR XIL - "AI CEO o'z uslubini
// o'zgartirishi kerak" degan signal bilan "haqiqiy chegirmaga o'tish
// kerak" degan signal BIR XIL bo'sag'adan boshlanadi (ikkalasi ham
// "AI matni YETARLI emasligi ISBOTLANGAN" degani).
const AUTO_DISCOUNT_ELIGIBLE_MAX_CONVERSION_PERCENT = 15;

// Bitta ishga tushirishda (`sendRepurchaseReminders`), bitta sotuvchi
// uchun berilishi mumkin bo'lgan maksimal avtomatik chegirmalar soni -
// `engagementReminders.js`dagi `MAX_ORDERS_PER_RUN`/`MAX_FAVORITES_PER_RUN`
// bilan BIR XIL xavfsizlik chegarasi naqshi, lekin bu safar MOLIYAVIY
// ta'sirni cheklash uchun.
const MAX_AUTO_DISCOUNTS_PER_SELLER_PER_RUN = 15;

function clampInt(value, fallback, min, max) {
  const n = Number.isFinite(Number(value)) ? Math.round(Number(value)) : fallback;
  return Math.min(Math.max(n, min), max);
}

/**
 * `carts.js`dagi `generateRecoveryCouponCode`ga O'XSHASH, lekin ATAYLAB
 * BOSHQA prefiks bilan - sotuvchi "Promokodlar" ro'yxatida ikkala
 * avtomatik turni (savat qaytarish vs. AI CEO qaytarish) VIZUAL
 * ajratishi uchun.
 */
function generateWinBackDiscountCode() {
  return `SOGINDIK-${Math.random().toString(36).slice(2, 8).toUpperCase()}`;
}

/**
 * SOF FUNKSIYA - "hozir avtomatik chegirma berilishi kerakmi" degan
 * qarorni, HECH QANDAY Firestore yozuvisiz, mustaqil tekshirish/
 * sinash mumkin bo'lgan holda hisoblaydi (batafsil izoh - fayl
 * boshida, 1-4 bandlar).
 *
 * @param {object} params
 * @param {object} params.seller - sotuvchi hujjati (`aiCeoAutoDiscountEnabled`, `aiCeoAutoWinBackEnabled`)
 * @param {{sentCount:number, convertedCount:number, conversionRatePercent:number}|null} params.recentPerformance
 * @param {number} params.issuedCountThisRun - shu ishga tushirishda, shu sotuvchi uchun ALLAQACHON berilgan chegirmalar soni
 */
function shouldIssueAutoWinBackDiscount({ seller, recentPerformance, issuedCountThisRun }) {
  if (!seller || seller.aiCeoAutoDiscountEnabled !== true) return false;
  if (seller.aiCeoAutoWinBackEnabled !== true) return false;
  if (!recentPerformance) return false;
  if (recentPerformance.conversionRatePercent >= AUTO_DISCOUNT_ELIGIBLE_MAX_CONVERSION_PERCENT) return false;
  if ((issuedCountThisRun || 0) >= MAX_AUTO_DISCOUNTS_PER_SELLER_PER_RUN) return false;
  return true;
}

/**
 * Yuqoridagi qarorni tekshiradi va, agar MUVOFIQ bo'lsa, HAQIQIY,
 * bir martalik promokodni `sellers/{sellerId}/coupons`ga yozadi -
 * `carts.js`dagi tashlab ketilgan savat mukofoti bilan BIR XIL,
 * sinovdan o'tgan hujjat sxemasi (`isCartRecoveryReward`o'rniga
 * `isAiCeoWinBackReward`).
 *
 * HECH QACHON xato tashlamaydi - muvaffaqiyatsiz bo'lsa `{issued:false}`
 * qaytaradi, chaqiruvchi tomon (`engagementReminders.js`) chegirmasiz,
 * oddiy xabar bilan davom etadi.
 *
 * @returns {Promise<{issued:boolean, code?:string, discountPercent?:number, expiresAtMs?:number}>}
 */
async function maybeIssueAutoWinBackDiscount({ sellerId, clientId, seller, recentPerformance, issuedCountThisRun }) {
  if (!shouldIssueAutoWinBackDiscount({ seller, recentPerformance, issuedCountThisRun })) {
    return { issued: false };
  }
  try {
    const discountPercent = clampInt(seller.aiCeoAutoDiscountPercent, DEFAULT_DISCOUNT_PERCENT, MIN_DISCOUNT_PERCENT, MAX_DISCOUNT_PERCENT);
    const code = generateWinBackDiscountCode();
    const expiresAtMs = Date.now() + DISCOUNT_EXPIRY_DAYS * DAY_MS;
    await db.collection("sellers").doc(sellerId).collection("coupons").doc(code).set({
      code,
      discountType: "percent",
      discountValue: discountPercent,
      expiresAt: new Date(expiresAtMs).toISOString(),
      usageLimit: 1,
      usedCount: 0,
      isActive: true,
      isAiCeoWinBackReward: true,
      rewardForClientId: clientId,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      createdAtMs: Date.now(),
    });
    return { issued: true, code, discountPercent, expiresAtMs };
  } catch (err) {
    console.error(`AI CEO avtomatik chegirma yaratib bo'lmadi (sotuvchi ${sellerId}, mijoz ${clientId}):`, err);
    return { issued: false };
  }
}

exports.maybeIssueAutoWinBackDiscount = maybeIssueAutoWinBackDiscount;
exports.shouldIssueAutoWinBackDiscount = shouldIssueAutoWinBackDiscount;
exports.DISCOUNT_EXPIRY_DAYS = DISCOUNT_EXPIRY_DAYS;
exports.MIN_DISCOUNT_PERCENT = MIN_DISCOUNT_PERCENT;
exports.MAX_DISCOUNT_PERCENT = MAX_DISCOUNT_PERCENT;

exports._testables = {
  shouldIssueAutoWinBackDiscount,
  maybeIssueAutoWinBackDiscount,
  generateWinBackDiscountCode,
  clampInt,
  MIN_DISCOUNT_PERCENT,
  MAX_DISCOUNT_PERCENT,
  DEFAULT_DISCOUNT_PERCENT,
  DISCOUNT_EXPIRY_DAYS,
  AUTO_DISCOUNT_ELIGIBLE_MAX_CONVERSION_PERCENT,
  MAX_AUTO_DISCOUNTS_PER_SELLER_PER_RUN,
};
