const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { GoogleGenAI } = require("@google/genai");
const { db, GEMINI_API_KEY } = require("./lib/admin");
const { checkRateLimit } = require("./lib/rateLimit");

/**
 * Sotuvchi "Mahsulot qo'shish" formasida "AI bilan to'ldirish"
 * tugmasini bosganda chaqiriladi. Mahsulot nomi va kategoriyasi
 * (va, agar bo'lsa, rasmi) asosida, Gemini yordamida haqiqiy,
 * mahsulotga xos tavsif matnini yaratadi.
 */
exports.generateProductDescription = onCall(
  { secrets: [GEMINI_API_KEY], region: "asia-south1" },
  async (request) => {
    // Faqat tizimga kirgan (haqiqiy Telegram orqali tasdiqlangan)
    // foydalanuvchilar chaqira oladi — bu AI so'rovi pullik bo'lgani
    // uchun, tasodifiy/anonim suiiste'molning oldini olish uchun kerak.
    if (!request.auth) {
      throw new HttpsError("unauthenticated", "Bu funksiyani ishlatish uchun tizimga kirgan bo'lishingiz kerak.");
    }

    // SO'ROVLARNI CHEGARALASH: har bir AI so'rovi HAQIQIY pul
    // xarajatiga olib keladi — shuning uchun bir soatda 20 tadan
    // ortiq so'rov yuborilishiga yo'l qo'yilmaydi.
    await checkRateLimit(`generateProductDescription:${request.auth.uid}`, 20, 3600);

    const { productName, category, imageBase64, imageMimeType } = request.data || {};
    const name = (productName || "").trim();

    if (!name) {
      throw new HttpsError("invalid-argument", "Mahsulot nomi ko'rsatilishi shart.");
    }

    try {
      const ai = new GoogleGenAI({ apiKey: GEMINI_API_KEY.value() });

      // Agar sotuvchi rasm yuklagan bo'lsa, o'sha rasm ham AI'ga
      // yuboriladi (Gemini multimodal — matn VA rasmni birga tahlil
      // qila oladi) — natijada tavsif haqiqiy mahsulotning ko'rinishiga
      // (rangi, shakli, turi) asoslanadi, faqat nomga emas.
      const hasImage = Boolean(imageBase64 && imageMimeType);

      const textPrompt = `Sen — onlayn do'kon uchun mahsulot tavsifi yozuvchi yordamchisan.
${hasImage ? "Ilova qilingan RASMga qarab va" : "Quyidagi"} mahsulot nomi/kategoriyasi asosida, O'ZBEK TILIDA, jozibali, ishonchli va qisqa (2-3 gap, 40-60 so'z) tavsif yoz.

Mahsulot nomi: ${name}
${category ? `Kategoriya: ${category}` : ""}

Qoidalar:
- Faqat tavsif matnini yoz, boshqa hech narsa (sarlavha, izoh, tirnoq belgisi) qo'shma.
${hasImage ? "- Rasmda haqiqatan ko'rinib turgan narsalar (rang, shakl, material) haqida yoz." : ""}
- Aniq raqamli da'volar (masalan "99% samarali", sertifikat nomlari) ISHLATMA — bular haqiqiy bo'lmasligi mumkin.
- Tabiiy, sotuvga undaydigan, lekin ishonchli ohangda yoz.`;

      const contents = hasImage
        ? [
            {
              role: "user",
              parts: [
                { text: textPrompt },
                { inlineData: { mimeType: imageMimeType, data: imageBase64 } },
              ],
            },
          ]
        : textPrompt;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash-lite",
        contents,
      });

      const description = (response.text || "").trim();
      if (!description) {
        throw new Error("AI bo'sh javob qaytardi.");
      }

      return { description };
    } catch (err) {
      console.error("AI tavsif yaratishda xatolik:", err);
      throw new HttpsError("internal", "Tavsif yaratib bo'lmadi. Birozdan so'ng qayta urinib ko'ring.");
    }
  }
);

/**
 * AI CEO — 3-BOSQICH: IJTIMOIY TARMOQ POSTI GENERATORI.
 *
 * MUHIM: bu — AVTOMATIK JOYLASH EMAS (Instagram/TikTok'ga to'g'ridan-
 * to'g'ri joylash uchun Meta/TikTok Business API'lari rasmiy
 * tasdiqlash jarayonidan (haftalar/oylar) o'tishi kerak - bu
 * BUTUNLAY ALOHIDA, kelajakdagi loyiha). Bu yerda faqat TAYYOR MATN
 * yaratiladi - sotuvchi uni nusxalab, o'zi joylaydi.
 *
 * PREMIUM: `generateProductDescription`dan farqli, bu funksiya
 * FAQAT `aiCeoEnabled===true` sotuvchilar uchun ishlaydi - AI CEO
 * dasturining bir qismi sifatida joylashtirilgan.
 *
 * EMOJI HAQIDA ESLATMA: loyihaning O'Z INTERFEYSIDA emoji ISHLATILMAYDI
 * (faqat lucide-react ikonkalar) - lekin BU YERDA, AI YARATGAN
 * Instagram/TikTok POST MATNIDA, emoji ATAYLAB ta'qiqlanmagan - chunki
 * bu, haqiqiy ijtimoiy tarmoq postlarining TABIIY, kutilgan uslubi
 * (haqiqiy SMM mutaxassis ham shunday yozadi). Bu - ilova UI'si bilan
 * ijtimoiy tarmoq uchun MO'LJALLANGAN KONTENT o'rtasidagi ataylab
 * qilingan farq, ikkalasi bir xil qoidaga bo'ysunmaydi.
 */
async function handleGenerateSocialPost(request) {
  if (!request.auth) {
    throw new HttpsError("unauthenticated", "Bu funksiyani ishlatish uchun tizimga kirgan bo'lishingiz kerak.");
  }

  await checkRateLimit(`generateSocialPost:${request.auth.uid}`, 20, 3600);

  // PREMIUM TEKSHIRUVI - `aiCeoEnabled` bo'lmasa, Gemini so'rovi
  // UMUMAN qilinmaydi (xarajatni oldindan chegaralash).
  const sellerSnap = await db.collection("sellers").doc(request.auth.uid).get();
  if (!sellerSnap.exists || sellerSnap.data().aiCeoEnabled !== true) {
    throw new HttpsError("permission-denied", "Bu funksiya faqat AI CEO premium mijozlari uchun mavjud.");
  }

  const { productName, description, price, platform, imageBase64, imageMimeType } = request.data || {};
  const name = (productName || "").trim();
  if (!name) {
    throw new HttpsError("invalid-argument", "Mahsulot nomi ko'rsatilishi shart.");
  }

  const platformStyle = platform === "tiktok"
    ? "TikTok uchun - qisqa, energik, tez o'qiladigan, yoshlarga xos ohangda"
    : "Instagram uchun - chiroyli, hikoya uslubidagi, biroz uzunroq bo'lishi mumkin";

  try {
    const ai = new GoogleGenAI({ apiKey: GEMINI_API_KEY.value() });
    const hasImage = Boolean(imageBase64 && imageMimeType);

    const textPrompt = `Sen — tajribali SMM (ijtimoiy tarmoqlar marketingi) mutaxassisisan, kichik onlayn do'konlar uchun ishlaysan.

${hasImage ? "Ilova qilingan RASMga qarab va" : "Quyidagi"} mahsulot ma'lumoti asosida, ${platformStyle}, TAYYOR POST MATNINI yoz.

Mahsulot nomi: ${name}
${description ? `Tavsif: ${description}` : ""}
${price ? `Narx: ${Number(price).toLocaleString()} so'm` : ""}

QOIDALAR:
- O'ZBEK TILIDA yoz.
- Tabiiy, samimiy Instagram/TikTok uslubida - mos joylarda emoji ISHLATISHING MUMKIN (bu yerda ilovaning o'zidagi qoidalar emas, ijtimoiy tarmoq postining tabiiy uslubi qo'llaniladi).
- Postning oxirida 5-8 ta tegishli, O'ZBEKISTON bozoriga mos HASHTAG qo'sh (masalan #toshkent #onlayndokon kabi).
- Aniq raqamli da'volar (masalan "99% samarali") ISHLATMA.
- Faqat POST MATNINI yoz - boshqa hech narsa (izoh, sarlavha) qo'shma.`;

    const contents = hasImage
      ? [{ role: "user", parts: [{ text: textPrompt }, { inlineData: { mimeType: imageMimeType, data: imageBase64 } }] }]
      : textPrompt;

    const response = await ai.models.generateContent({ model: "gemini-3.5-flash-lite", contents });
    const postText = (response.text || "").trim();
    if (!postText) throw new Error("AI bo'sh javob qaytardi.");

    return { postText };
  } catch (err) {
    console.error("Ijtimoiy tarmoq posti yaratishda xatolik:", err);
    throw new HttpsError("internal", "Post matnini yaratib bo'lmadi. Birozdan so'ng qayta urinib ko'ring.");
  }
}

exports.generateSocialPost = onCall({ secrets: [GEMINI_API_KEY], region: "asia-south1" }, handleGenerateSocialPost);

exports._testables = { handleGenerateSocialPost };
