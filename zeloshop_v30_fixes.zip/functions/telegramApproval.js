const { onSchedule } = require("firebase-functions/v2/scheduler");
const { onRequest, onCall, HttpsError } = require("firebase-functions/v2/https");
const { admin, db, BOT_TOKEN, GEMINI_API_KEY, TELEGRAM_WEBHOOK_SECRET } = require("./lib/admin");
const { sendTelegramMessage, answerCallbackQuery, editTelegramMessageText } = require("./lib/helpers");
const { todayDocId, trackCrmMessageRecipients, logNotification } = require("./lib/dailyStats");
const { collectAttentionSegmentClientIds, craftCrmCampaign } = require("./aiCeo");
const { handleTelegramMessage } = require("./telegramBotMenu");

/**
 * AI CEO — 3-QISM: TELEGRAM ORQALI "1-TUGMALI TASDIQLASH".
 *
 * MUHIM, ARXITEKTURA QARORI (foydalanuvchi ATAYLAB so'ragan, avvalgi
 * suhbatda kelishilgan "ishonch zinapoyasi" modelining YANGI shakli):
 * sotuvchi Mini App'ni UMUMAN OCHMASDAN, to'g'ridan-to'g'ri o'z
 * Telegram chatida AI CEO tayyorlagan (VIP yoki "uxlab qolgan"
 * mijozlar uchun) TO'LIQ TAYYOR kampaniya matnini ko'radi, va bitta
 * tugma bosib ("✅ Tasdiqlash va yuborish") uni HAQIQATAN yuboradi -
 * yoki "❌ Bekor qilish" bosib rad etadi. Bu — Tier-2 ("AI tayyorlaydi,
 * sotuvchi bir marta tasdiqlaydi") darajasining ENG QULAY, Mini
 * App'ni ochishni UMUMAN talab qilmaydigan shakli.
 *
 * NEGA `onRequest` (kodning boshqa hamma joyida FAQAT `onCall`
 * ishlatiladi - loyihaning o'rnatilgan konventsiyasi): Telegram Bot
 * API "webhook" mexanizmi HAQIQIY, xom HTTP so'rovini talab qiladi
 * (Firebase'ning o'z `onCall` protokoli EMAS - Telegram serverlari
 * buni bilmaydi) - bu YAGONA, texnik jihatdan MUQARRAR sabab bilan
 * `onRequest`dan foydalanadigan yagona joy. CORS xavfsizligi bu
 * yerda TAVSIYA ETILMAYDI (Telegram - brauzer emas, server-serverga
 * so'rov) - o'rniga, XAVFSIZLIK boshqa yo'l bilan ta'minlanadi: HAR
 * BIR so'rov `X-Telegram-Bot-Api-Secret-Token` sarlavhasi orqali
 * tekshiriladi (`registerTelegramWebhook` orqali Telegram'ga
 * ro'yxatdan o'tkazilgan maxfiy token bilan solishtiriladi) - shu
 * TOKENNI bilmagan hech kim bu manzilga soxta so'rov yubora olmaydi.
 *
 * XAVFSIZLIK, IKKINCHI QATLAM (sellerId'ni ISHONCH bilan aniqlash):
 * Telegram callback_query'dagi `from.id` — TUGMANI HAQIQATAN
 * bosgan foydalanuvchining, Telegram serveri tomonidan tasdiqlangan
 * ID'si (soxtalashtirib bo'lmaydi, xuddi HAR QANDAY Telegram
 * botidagi kabi). Bizning tizimda sotuvchining O'Z Telegram ID'si =
 * `sellerId` (butun kodning o'rnatilgan konventsiyasi, `notifications.js`
 * va boshqa joylarda ko'p marta ishlatilgan) - shuning uchun
 * `callback_query.from.id` to'g'ridan-to'g'ri, QO'SHIMCHA tekshiruvsiz,
 * ISHONCHLI sellerId sifatida ishlatiladi.
 *
 * NIMA UCHUN FAQAT CRM SEGMENT KAMPANIYASI (chegirma/aksiya EMAS):
 * bu — XAVFSIZ, QAYTARILADIGAN harakat turi (bitta Telegram xabari -
 * moliyaviy majburiyat yo'q), Tier-1/Tier-2 mezonlariga TO'LIQ mos.
 * Mahsulot narxini o'zgartirish (chegirma) esa HAQIQIY moliyaviy
 * ta'sirga ega va QAYTARILISHI ANIQ EMAS - shuning uchun bu funksiya
 * doirasidan ATAYLAB CHETLASHTIRILGAN (Mini App ichidagi "Bugungi
 * rejalar" markazida, alohida, sotuvchi TO'LIQ nazorat qiladigan
 * shaklda qoladi).
 *
 * QO'SHIMCHA CHEKLOV: bu funksiya FAQAT platformaning umumiy boti
 * (`BOT_TOKEN`) orqali ishlaydi - agar sotuvchi shaxsiy bot ulagan
 * bo'lsa ham, webhook FAQAT BITTA (umumiy) botga ro'yxatdan
 * o'tkazilgan bo'lishi mumkin (Telegram cheklovi), shuning uchun bu
 * ATAYLAB, ONGLI ravishda shunday qoldirilgan.
 */

// Bir kunda BIR SELLER uchun nechta pending action yaratilishi
// mumkinligini cheklaymiz emas (atigi 2 ta segment - vip/churn) -
// lekin BARCHA premium+yoqilgan sotuvchilar bo'yicha XARAJATni
// nazorat qilish uchun umumiy sotuvchi sonini CHEKLASH kerak emas,
// chunki quyida QAT'IY ikki bosqichli filtr (`aiCeoEnabled` VA
// `aiCeoTelegramApprovalEnabled`, ikkalasi ham standart holatda
// O'CHIQ) bilan boshlanadi.
const SEGMENT_TITLES = {
  vip: "VIP mijozlar",
  churn: "uxlab qolgan mijozlar",
};

/**
 * SOF FUNKSIYA - bitta segment uchun Telegram xabari matnini va
 * inline tugmalar qatorini tuzadi. To'g'ridan-to'g'ri test qilinadi.
 */
function buildApprovalMessage({ segment, segmentCount, title, message, reasoning, dateId }) {
  const text = `🤖 *AI CEO tavsiyasi*\n\n${SEGMENT_TITLES[segment] || segment} (${segmentCount} ta) uchun tayyor kampaniya:\n\n*${title}*\n${message}${reasoning ? `\n\n_Nega bu taktika: ${reasoning}_` : ""}`;
  const inlineKeyboard = [[
    { text: "✅ Tasdiqlash va yuborish", callback_data: `a:${segment}:${dateId}` },
    { text: "❌ Bekor qilish", callback_data: `x:${segment}:${dateId}` },
  ]];
  return { text, inlineKeyboard };
}

/**
 * Bitta sotuvchi uchun: mavjud "diqqat talab qiladi" segmentlaridan
 * (VIP/uxlab qolgan) har biri uchun AI CEO orqali TAYYOR kampaniya
 * matni yaratadi, kutilayotgan harakat sifatida Firestore'ga yozadi,
 * va Telegram'ga interaktiv tugmali xabar yuboradi.
 *
 * XARAJAT NAZORATI: 2-BOSQICHLI filtr (aiCeoEnabled VA
 * aiCeoTelegramApprovalEnabled, ikkalasi ham standart O'CHIQ) -
 * boshqa HAMMA sotuvchi uchun bu funksiya HECH NARSA qilmaydi va
 * HECH QANDAY Gemini/Firestore so'rovi qilinmaydi.
 */
async function processSellerApprovalDigest(sellerDoc) {
  const seller = sellerDoc.data();
  const sellerId = sellerDoc.id;

  if (seller.aiCeoEnabled !== true) return;
  if (seller.aiCeoTelegramApprovalEnabled !== true) return;

  const customersSnap = await db.collection("sellers").doc(sellerId).collection("customers").get();
  const customers = customersSnap.docs.map((d) => ({ id: d.id, ...d.data() }));
  const { vipClientIds, churnClientIds } = collectAttentionSegmentClientIds(customers, Date.now());

  const dateId = todayDocId();
  const token = BOT_TOKEN.value();
  const segments = [
    { key: "vip", ids: vipClientIds },
    { key: "churn", ids: churnClientIds },
  ];

  for (const { key, ids } of segments) {
    if (ids.length === 0) continue;
    try {
      const draft = await craftCrmCampaign(key, ids.length, seller.storeName, null);
      const actionId = `crm_${key}_${dateId}`;

      await db.collection("sellers").doc(sellerId).collection("aiCeoPendingActions").doc(actionId).set({
        type: "crmCampaign",
        segment: key,
        title: draft.title,
        message: draft.message,
        targetClientIds: ids,
        status: "pending",
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
      });

      const { text, inlineKeyboard } = buildApprovalMessage({
        segment: key, segmentCount: ids.length, title: draft.title, message: draft.message,
        reasoning: draft.reasoning, dateId,
      });
      await sendTelegramMessage(token, sellerId, text, { inlineKeyboard });
    } catch (err) {
      console.error(`AI CEO Telegram tasdiqlash xabari xatosi (sotuvchi ${sellerId}, segment ${key}):`, err);
    }
  }
}

exports.sendAiCeoApprovalDigest = onSchedule(
  { schedule: "30 20 * * *", timeZone: "Asia/Tashkent", region: "asia-south1", secrets: [BOT_TOKEN, GEMINI_API_KEY] },
  async () => {
    // 1-XARAJAT NAZORATI (kolleksiya darajasida): faqat
    // `aiCeoEnabled == true` sotuvchilarni so'raymiz - qolganlar
    // uchun HATTO BITTA hujjat ham o'qilmaydi. Ichkarida yana
    // `aiCeoTelegramApprovalEnabled` bo'yicha 2-filtr bor.
    const eligibleSellersSnap = await db.collection("sellers").where("aiCeoEnabled", "==", true).get();
    if (eligibleSellersSnap.empty) return;

    for (const sellerDoc of eligibleSellersSnap.docs) {
      try {
        await processSellerApprovalDigest(sellerDoc);
      } catch (err) {
        console.error(`AI CEO Telegram tasdiqlash raqami xatosi (sotuvchi ${sellerDoc.id}):`, err);
      }
    }
  }
);

/**
 * SOF FUNKSIYA - Telegram'dan kelgan `callback_data`ni ("a:vip:2026-08-23"
 * yoki "x:churn:2026-08-23") ajratadi. Noto'g'ri formatda bo'lsa
 * `null` qaytaradi.
 */
function parseCallbackData(data) {
  if (!data || typeof data !== "string") return null;
  const parts = data.split(":");
  if (parts.length !== 3) return null;
  const [action, segment, dateId] = parts;
  if (action !== "a" && action !== "x") return null;
  if (segment !== "vip" && segment !== "churn") return null;
  return { approve: action === "a", segment, dateId, actionId: `crm_${segment}_${dateId}` };
}

/**
 * Tasdiqlangan CRM kampaniyasini HAQIQATAN yuboradi. `notifications.js`dagi
 * `handleSendCrmNotification`ning "yuborish" qismi bilan BIR XIL
 * mantiq, lekin QAYTA YOZILGAN — bu yerda `targetClientIds` sotuvchi
 * ilovadan yuborgan (ISHONCHSIZ) qiymat EMAS, biz o'zimiz, server
 * tomonida, `sellers/{id}/customers` yig'ma kolleksiyasidan
 * hisoblagan (ALLAQACHON ishonchli) ro'yxat — shuning uchun qo'shimcha
 * "buyurtma tarixida bormi" tekshiruvi bu yerda ORTIQCHA.
 */
async function executeCrmCampaignSend({ sellerId, targetClientIds, title, message }) {
  const token = BOT_TOKEN.value();
  const text = `*${title}*\n\n${message}`;
  const results = await Promise.all(targetClientIds.map((id) => sendTelegramMessage(token, id, text)));
  const successfulIds = targetClientIds.filter((id, i) => results[i]?.ok);

  await trackCrmMessageRecipients(sellerId, successfulIds);
  await Promise.all(successfulIds.map((id) => logNotification({
    sellerId, clientId: id, type: "crmBroadcast", title, message, delivered: true,
  })));

  return { sent: successfulIds.length, total: targetClientIds.length };
}

/**
 * Telegram webhook — IKKI turdagi yangilanishni qabul qiladi:
 * `callback_query` (inline tugma bosilishi - CRM tasdiqlash oqimi,
 * pastda o'zgarishsiz) VA (YANGI) `message` (oddiy xabar/rasm - bot
 * "menyu" tugmalari va rasm yig'ish oqimi, `telegramBotMenu.js`ga
 * DELEGATSIYA qilinadi). Boshqa BARCHA yangilanish turlari ATAYLAB
 * e'tiborsiz qoldiriladi (200 bilan, chunki Telegram muvaffaqiyatsiz
 * javobni QAYTA-QAYTA urinishga harakat qiladi — buni oldini olish
 * uchun har doim 200 qaytaramiz).
 *
 * MUHIM: `message` turi endi ham kelishi uchun, webhook
 * `allowed_updates`ga "message" QO'SHILGAN holda QAYTA ro'yxatdan
 * o'tkazilishi kerak (`registerTelegramWebhook`ni yana bir marta
 * chaqirish - eski, "message"siz ro'yxatga olingan webhook'lar uchun
 * Telegram bu yangilanish turini UMUMAN yubormaydi).
 */
exports.telegramCallbackWebhook = onRequest(
  { region: "asia-south1", secrets: [BOT_TOKEN, TELEGRAM_WEBHOOK_SECRET, GEMINI_API_KEY] },
  async (req, res) => {
    // XAVFSIZLIK: bu YAGONA `onRequest` (kodning qolgan qismi faqat
    // `onCall` ishlatadi) — shuning uchun manba tekshiruvi BU YERDA,
    // qo'lda amalga oshirilishi SHART.
    const providedSecret = req.get("X-Telegram-Bot-Api-Secret-Token");
    if (providedSecret !== TELEGRAM_WEBHOOK_SECRET.value()) {
      res.status(401).send("unauthorized");
      return;
    }

    const message = req.body?.message;
    if (message) {
      try {
        await handleTelegramMessage(BOT_TOKEN.value(), message);
      } catch (err) {
        console.error("Telegram xabarini (bot menyusi) qayta ishlashda xatolik:", err);
      }
      res.status(200).send("ok");
      return;
    }

    const callbackQuery = req.body?.callback_query;
    if (!callbackQuery) {
      // Boshqa yangilanish turi - e'tiborsiz qoldiramiz, lekin
      // Telegram qayta urinmasligi uchun 200.
      res.status(200).send("ok");
      return;
    }

    try {
      const sellerId = String(callbackQuery.from?.id || "");
      const chatId = callbackQuery.message?.chat?.id;
      const messageId = callbackQuery.message?.message_id;
      const parsed = parseCallbackData(callbackQuery.data);
      const token = BOT_TOKEN.value();

      if (!sellerId || !parsed) {
        await answerCallbackQuery(token, callbackQuery.id, "Noma'lum amal.");
        res.status(200).send("ok");
        return;
      }

      const actionRef = db.collection("sellers").doc(sellerId).collection("aiCeoPendingActions").doc(parsed.actionId);
      const actionSnap = await actionRef.get();

      if (!actionSnap.exists || actionSnap.data().status !== "pending") {
        await answerCallbackQuery(token, callbackQuery.id, "Bu tavsiya endi amal qilmaydi.");
        res.status(200).send("ok");
        return;
      }

      const action = actionSnap.data();

      if (parsed.approve) {
        const { sent, total } = await executeCrmCampaignSend({
          sellerId, targetClientIds: action.targetClientIds || [], title: action.title, message: action.message,
        });
        await actionRef.update({ status: "executed", executedAt: admin.firestore.FieldValue.serverTimestamp() });
        await answerCallbackQuery(token, callbackQuery.id, `✅ Yuborildi: ${sent}/${total}`);
        if (chatId && messageId) {
          await editTelegramMessageText(token, chatId, messageId, `✅ *Yuborildi* — ${sent}/${total} ta mijozga\n\n*${action.title}*\n${action.message}`);
        }
      } else {
        await actionRef.update({ status: "rejected", rejectedAt: admin.firestore.FieldValue.serverTimestamp() });
        await answerCallbackQuery(token, callbackQuery.id, "❌ Bekor qilindi.");
        if (chatId && messageId) {
          await editTelegramMessageText(token, chatId, messageId, `❌ *Bekor qilindi*\n\n*${action.title}*\n${action.message}`);
        }
      }

      res.status(200).send("ok");
    } catch (err) {
      console.error("Telegram callback_query qayta ishlashda xatolik:", err);
      // MUHIM: xato bo'lsa ham 200 qaytaramiz - Telegram'ning
      // cheksiz qayta urinishiga yo'l qo'ymaslik uchun (xato allaqachon
      // logga yozildi, keyinroq diagnostika qilinadi).
      res.status(200).send("ok");
    }
  }
);

/**
 * BIR MARTALIK SOZLASH: Telegram'ga "har bir inline tugma bosilganda,
 * shu manzilga xabar yubor" deb aytadigan `setWebhook` chaqiruvi.
 * FAQAT platforma administratorlari chaqira oladi (`admins`
 * kolleksiyasi orqali tekshiriladi, xuddi `contactAdmin`dagi kabi
 * naqsh). Deploy qilingandan KEYIN, bir marta chaqirilishi kerak
 * (funksiya URL manzili faqat DEPLOY QILINGANDAN keyin ma'lum
 * bo'lgani uchun, bu ishni deploy vaqtida AVTOMATIK qilib bo'lmaydi).
 */
async function handleRegisterTelegramWebhook(request) {
  if (!request.auth) {
    throw new HttpsError("unauthenticated", "Tizimga kirgan bo'lishingiz kerak.");
  }
  const adminSnap = await db.collection("admins").doc(request.auth.uid).get();
  if (!adminSnap.exists) {
    throw new HttpsError("permission-denied", "Bu amal faqat administratorlar uchun.");
  }

  const projectId = process.env.GCLOUD_PROJECT || process.env.GCP_PROJECT;
  if (!projectId) {
    throw new HttpsError("internal", "Loyiha ID'sini aniqlab bo'lmadi.");
  }
  const webhookUrl = `https://asia-south1-${projectId}.cloudfunctions.net/telegramCallbackWebhook`;

  const res = await fetch(`https://api.telegram.org/bot${BOT_TOKEN.value()}/setWebhook`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      url: webhookUrl,
      secret_token: TELEGRAM_WEBHOOK_SECRET.value(),
      // MUHIM, YANGI: "message" qo'shildi - bot "menyu" tugmalari
      // (`telegramBotMenu.js`) va rasm yig'ish oqimi ISHLASHI uchun,
      // Telegram oddiy xabar/rasm yangilanishlarini HAM webhook'ga
      // yuborishi SHART. Bu funksiya ALDIN "message"siz chaqirilgan
      // bo'lsa, QAYTA chaqirilishi kerak (eski ro'yxatga olish
      // "message" turini butunlay tashlab yuborardi).
      allowed_updates: ["callback_query", "message"],
    }),
  });
  const data = await res.json();
  if (!data.ok) {
    throw new HttpsError("internal", `Telegram webhook o'rnatilmadi: ${data.description || "noma'lum sabab"}`);
  }
  return { ok: true, webhookUrl };
}

exports.registerTelegramWebhook = onCall(
  { region: "asia-south1", secrets: [BOT_TOKEN, TELEGRAM_WEBHOOK_SECRET] },
  handleRegisterTelegramWebhook
);

exports._testables = {
  buildApprovalMessage, processSellerApprovalDigest, parseCallbackData,
  executeCrmCampaignSend, handleRegisterTelegramWebhook,
};
