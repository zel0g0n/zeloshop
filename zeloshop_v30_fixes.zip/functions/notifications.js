const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { onDocumentCreated, onDocumentUpdated } = require("firebase-functions/v2/firestore");
const { onSchedule } = require("firebase-functions/v2/scheduler");
const { admin, BOT_TOKEN } = require("./lib/admin");
const { sendTelegramMessage } = require("./lib/helpers");
const { checkRateLimit } = require("./lib/rateLimit");
const { incrementDailyStat, trackCrmMessageRecipients, logNotification } = require("./lib/dailyStats");

/**
 * CRM Hub'dagi "Yuborish" tugmasi chaqiradigan funksiya — HAQIQIY
 * Telegram xabarini yuboradi. `targetClientIds` — server tomonida
 * ushbu sotuvchining HAQIQIY buyurtma tarixiga qarshi tekshiriladi
 * (botni ixtiyoriy Telegram ID'larga spam yuborish vositasi sifatida
 * suiiste'mol qilinishining oldini olish uchun).
 *
 * Ichki mantiq alohida funksiyaga ajratilgan — shunda uni `onCall`
 * o'rovisiz, to'g'ridan-to'g'ri sinov (test) fayllaridan chaqirish
 * mumkin.
 */
async function handleSendCrmNotification(request) {
  if (!request.auth) {
    throw new HttpsError("unauthenticated", "Tizimga kirgan bo'lishingiz kerak.");
  }

  // SO'ROVLARNI CHEGARALASH: bir soatda 10 tadan ortiq ommaviy
  // xabar yuborilishiga yo'l qo'yilmaydi — bu, Telegram'ning o'z
  // spam-qarshi cheklovlariga (bot bloklanishi xavfi) tushib
  // qolishning oldini oladi.
  await checkRateLimit(`sendCrmNotification:${request.auth.uid}`, 10, 3600);

  const { sellerId, targetClientIds, title, message, bannerImageUrl, buttonText, buttonUrl, couponCode } = request.data || {};

  if (request.auth.uid !== String(sellerId)) {
    throw new HttpsError("permission-denied", "Faqat o'z do'koningiz nomidan xabar yubora olasiz.");
  }
  if (!title?.trim() || !message?.trim()) {
    throw new HttpsError("invalid-argument", "Sarlavha va matn kiritilishi shart.");
  }
  if (!Array.isArray(targetClientIds) || targetClientIds.length === 0) {
    throw new HttpsError("invalid-argument", "Tanlangan auditoriyada mijoz topilmadi.");
  }

  const firestore = admin.firestore();

  // MUHIM TUZATISH: agar sotuvchi O'Z (faqat xaridorlar uchun)
  // MUHIM, JIDDIY TUZATISH (o'z-o'zini qayta tekshiruv orqali
  // topilgan REGRESSIYA): bu yerda OLDIN, agar sotuvchi shaxsiy bot
  // ulagan bo'lsa, xabar O'SHA bot orqali yuborilardi - lekin
  // `shareLink.js`dagi "bot not found" tuzatishidan KEYIN (bu
  // suhbatning oldingi bosqichi), BARCHA ulashiladigan havolalar
  // (do'kon, referal, mahsulot) ENDI DOIM platformaning O'Z boti
  // orqali ochiladi - demak, mijoz DEYARLI HECH QACHON sotuvchining
  // shaxsiy botini ishga tushirmaydi! Natijada, bu yerda shaxsiy bot
  // tokenidan foydalanishga urinish, aksincha, xabar HECH QACHON
  // yetib bormasligiga sabab bo'lardi ("chat not found" - Telegram
  // foydalanuvchi ALOHIDA o'sha botga "start" bosmagan bo'lsa, xabar
  // yuborishga ruxsat bermaydi). Endi - mijozlarga xabar HAR DOIM
  // platformaning o'z boti orqali yuboriladi (buni mijoz HAQIQATAN
  // ishga tushirgan).
  const token = BOT_TOKEN.value();

  let text = `*${title.trim()}*\n\n${message.trim()}`;
  if (couponCode) {
    text += `\n\nPromokod: \`${couponCode}\``;
  }

  // OLDIN: `targetClientIds` frontend'dan kelgan ro'yxatga
  // ko'r-ko'rona ishonilardi. Endi har bir ID ushbu sotuvchining
  // HAQIQIY buyurtma tarixida borligi tekshiriladi — botni ixtiyoriy
  // Telegram ID'larga spam yuborish vositasi sifatida
  // suiiste'mol qilinishining oldini olish uchun.
  const verifiedIds = new Set();
  const CHUNK_SIZE = 30; // Firestore "in" so'rovi cheklovi

  for (let i = 0; i < targetClientIds.length; i += CHUNK_SIZE) {
    const chunk = targetClientIds.slice(i, i + CHUNK_SIZE);
    const ordersSnap = await firestore.collection("orders")
      .where("sellerId", "==", sellerId)
      .where("clientId", "in", chunk)
      .get();
    ordersSnap.forEach((doc) => verifiedIds.add(doc.data().clientId));
  }

  const safeClientIds = targetClientIds.filter((id) => verifiedIds.has(id));
  const clientResults = await Promise.all(
    safeClientIds.map((id) => sendTelegramMessage(token, id, text, { bannerImageUrl, buttonText, buttonUrl }))
  );

  // MUHIM QO'SHIMCHA: kimlarga xabar yuborilganini kuzatamiz - AI CEO
  // kunlik hisobotida "necha kishi sotib oldi" (konversiya)ni
  // hisoblash uchun ZARUR.
  const successfullyMessagedIds = safeClientIds.filter((id, i) => clientResults[i]?.ok);
  await trackCrmMessageRecipients(sellerId, successfullyMessagedIds);

  // MUHIM QO'SHIMCHA (diagnostika uchun ham foydali): HAR BIR
  // xaridor uchun, xabar HAQIQATAN yetkazilgan-yetkazilmaganini
  // (Telegram'ning o'z javobiga qarab) jurnalga yozamiz. Agar
  // yetkazilmagan bo'lsa, Telegram bergan ANIQ sababni ham
  // saqlaymiz - "mijoz botni hali ishga tushirmagan" (chat not
  // found) kabi haqiqiy sabablarni keyinroq TOPISH imkonini beradi.
  await Promise.all(
    safeClientIds.map((id, i) => logNotification({
      sellerId,
      clientId: id,
      type: "crmBroadcast",
      title: title.trim(),
      message: clientResults[i]?.ok ? message.trim() : `${message.trim()}\n\n[Yetkazilmadi: ${clientResults[i]?.description || clientResults[i]?.error || "noma'lum sabab"}]`,
      delivered: Boolean(clientResults[i]?.ok),
    }))
  );

  return {
    clientsSent: clientResults.filter((r) => r.ok).length,
    clientsTotal: clientResults.length,
  };
}

exports.sendCrmNotification = onCall(
  { secrets: [BOT_TOKEN], region: "asia-south1" },
  handleSendCrmNotification
);

exports._testables = { handleSendCrmNotification };

/**
 * Yangi buyurtma kelganda sotuvchiga HAQIQIY Telegram xabari
 * yuboriladi (agar `notifyNewOrder` sozlamasi yoqilgan bo'lsa —
 * standart holatda yoqilgan hisoblanadi).
 */
exports.onNewOrderNotifySeller = onDocumentCreated(
  { document: "orders/{orderId}", secrets: [BOT_TOKEN], region: "asia-south1" },
  async (event) => {
    const order = event.data.data();
    if (!order?.sellerId) return;

    // Agar buyurtmada promokod ishlatilgan bo'lsa, uning
    // `usedCount`ini shu yerda (Admin SDK orqali) oshiramiz.
    if (order.appliedCoupon?.code) {
      try {
        const couponRef = admin.firestore()
          .collection("sellers").doc(order.sellerId)
          .collection("coupons").doc(order.appliedCoupon.code);
        await couponRef.update({ usedCount: admin.firestore.FieldValue.increment(1) });
      } catch (err) {
        console.error("Promokod hisoblagichini yangilashda xatolik:", err);
      }
    }

    try {
      const sellerSnap = await admin.firestore().collection("sellers").doc(order.sellerId).get();
      const seller = sellerSnap.data();
      if (!seller || seller.notifyNewOrder === false) return; // standart holatda yoqilgan

      const text = `Yangi buyurtma!\n\nMijoz: ${order.customer?.fullName || "Noma'lum"}\nSumma: ${Number(order.totalAmount || 0).toLocaleString()} so'm\n\nBatafsil ma'lumot uchun "Buyurtmalar" bo'limini oching.`;
      await sendTelegramMessage(BOT_TOKEN.value(), order.sellerId, text);
    } catch (err) {
      console.error("Yangi buyurtma bildirishnomasida xatolik:", err);
    }
  }
);

/**
 * Mahsulot stogi kritik darajaga (3 tagacha) tushganda sotuvchiga
 * HAQIQIY ogohlantirish yuboriladi.
 */
exports.onLowStockNotifySeller = onDocumentUpdated(
  { document: "products/{productId}", secrets: [BOT_TOKEN], region: "asia-south1" },
  async (event) => {
    const before = event.data.before.data();
    const after = event.data.after.data();
    if (!after?.sellerId) return;

    const beforeStock = Number(before?.stock ?? 999);
    const afterStock = Number(after?.stock ?? 0);

    // Faqat stok ENDIGINA kritik chegaradan (3) o'tganda yuboriladi.
    if (afterStock > 3 || beforeStock <= 3) return;

    try {
      const sellerSnap = await admin.firestore().collection("sellers").doc(after.sellerId).get();
      const seller = sellerSnap.data();
      if (!seller || seller.notifyLowStock === false) return;

      const text = `Omborda tovar kamaymoqda!\n\n"${after.name}" — atigi ${afterStock} ta qoldi.\n\nVaqtida to'ldirib qo'ying.`;
      await sendTelegramMessage(BOT_TOKEN.value(), after.sellerId, text);
    } catch (err) {
      console.error("Kam qolgan tovar bildirishnomasida xatolik:", err);
    }
  }
);

/**
 * KUNLIK P&L HISOBOTI — har kuni soat 21:00da (Toshkent vaqti),
 * `notifyDailyReport` yoqilgan har bir sotuvchiga o'sha kunning
 * buyurtmalari/tushumi/taxminiy sof foydasi haqida xabar yuboradi.
 *
 * HALOL IZOH: "bugun BERILGAN" (createdAt) bo'yicha hisoblanadi,
 * "bugun YETKAZILGAN" emas — alohida "yetkazilgan sana" maydoni
 * saqlanmaydi. Sof foyda faqat mahsulot tannarxini hisobga oladi —
 * OPEX/marketing xarajatlari (P&L Dashboard'da qo'lda kiritiladigan)
 * bu yerga KIRITILMAGAN, xabar matnida bu ochiq aytiladi.
 */
exports.sendDailyPnLReport = onSchedule(
  { schedule: "0 21 * * *", timeZone: "Asia/Tashkent", region: "asia-south1", secrets: [BOT_TOKEN] },
  async () => {
    const firestore = admin.firestore();
    const dayStart = new Date();
    dayStart.setHours(0, 0, 0, 0);
    const dayStartTimestamp = admin.firestore.Timestamp.fromDate(dayStart);

    const sellersSnap = await firestore.collection("sellers").get();

    for (const sellerDoc of sellersSnap.docs) {
      const seller = sellerDoc.data();
      if (seller.notifyDailyReport === false) continue;
      const sellerId = sellerDoc.id;

      try {
        const ordersSnap = await firestore.collection("orders")
          .where("sellerId", "==", sellerId)
          .where("createdAt", ">=", dayStartTimestamp)
          .get();

        const todaysOrders = ordersSnap.docs.map((d) => d.data());
        if (todaysOrders.length === 0) continue; // hech narsa bo'lmasa, xabar yuborilmaydi

        const deliveredToday = todaysOrders.filter((o) => o.status === "delivered");
        const revenue = deliveredToday.reduce((sum, o) => sum + (Number(o.totalAmount) || 0), 0);

        const productsSnap = await firestore.collection("products").where("sellerId", "==", sellerId).get();
        const costPriceMap = new Map();
        productsSnap.forEach((p) => costPriceMap.set(p.id, Number(p.data().costPrice) || 0));

        let cogs = 0;
        deliveredToday.forEach((order) => {
          (order.orders || []).forEach((item) => {
            cogs += (costPriceMap.get(item.id) || 0) * (Number(item.quantity) || 0);
          });
        });

        const netProfit = revenue - cogs;

        const text = `Kunlik hisobot\n\nBugungi buyurtmalar: ${todaysOrders.length} ta\nYetkazilganlar: ${deliveredToday.length} ta\nTushum: ${revenue.toLocaleString()} so'm\nTaxminiy sof foyda: ${netProfit.toLocaleString()} so'm\n\n(Faqat mahsulot tannarxi hisobga olindi — OPEX/marketing xarajatlari kirmagan, ularni "Foyda-Zarar" bo'limida ko'ring)`;
        await sendTelegramMessage(BOT_TOKEN.value(), sellerId, text);
      } catch (err) {
        console.error(`Kunlik hisobot xatosi (sotuvchi ${sellerId}):`, err);
      }
    }
  }
);

/**
 * Sotuvchidan platforma ADMINLARIGA haqiqiy Telegram xabari
 * yuboradi — "Qo'llab-quvvatlash" (savol/muammo) va "To'lovlar va
 * Tariflar" (Pro'ga qiziqish bildirish) sahifalari shu bitta,
 * umumiy mexanizmdan foydalanadi.
 *
 * MUHIM: admin ID(lar)i kodda QATTIQ YOZILMAGAN — `admins`
 * kolleksiyasidan DINAMIK o'qiladi, shuning uchun kelajakda yangi
 * admin qo'shilsa (Firebase Console orqali), bu funksiya avtomatik
 * o'sha(lar)ga ham xabar yubora boshlaydi.
 */
exports.contactAdmin = onCall(
  { secrets: [BOT_TOKEN], region: "asia-south1" },
  async (request) => {
    if (!request.auth) {
      throw new HttpsError("unauthenticated", "Tizimga kirgan bo'lishingiz kerak.");
    }

    // SO'ROVLARNI CHEGARALASH: bir soatda 5 tadan ortiq xabar
    // yuborilishiga yo'l qo'yilmaydi — adminni spam bilan bosib
    // yuborishning oldini oladi.
    await checkRateLimit(`contactAdmin:${request.auth.uid}`, 5, 3600);

    const { subject, message, category } = request.data || {};
    if (!message?.trim()) {
      throw new HttpsError("invalid-argument", "Xabar matni kiritilishi shart.");
    }

    const firestore = admin.firestore();
    const uid = request.auth.uid;

    // Kim yuborayotganini aniqlashtirish uchun (adminga qulay bo'lishi
    // uchun) — do'kon nomi va telefonini olishga harakat qilamiz,
    // lekin topilmasa ham xabar baribir yuboriladi.
    let senderLabel = `Telegram ID: ${uid}`;
    try {
      const sellerSnap = await firestore.collection("sellers").doc(uid).get();
      if (sellerSnap.exists) {
        const seller = sellerSnap.data();
        senderLabel = `${seller.storeName || "Noma'lum do'kon"} (${seller.phone || uid})`;
      }
    } catch (err) {
      console.error("Yuboruvchi ma'lumotini olishda xatolik:", err);
    }

    const adminsSnap = await firestore.collection("admins").get();
    if (adminsSnap.empty) {
      throw new HttpsError("internal", "Hozircha faol admin topilmadi. Birozdan so'ng qayta urinib ko'ring.");
    }

    const categoryLabel = category === "pro-interest" ? "Pro tarifga qiziqish" : "Qo'llab-quvvatlash";
    const text = `${categoryLabel}\n\nKimdan: ${senderLabel}\n${subject ? `Mavzu: ${subject}\n` : ""}\nXabar:\n${message.trim()}`;

    const token = BOT_TOKEN.value();
    const results = await Promise.all(
      adminsSnap.docs.map((doc) => sendTelegramMessage(token, doc.id, text))
    );

    return { sent: results.some((r) => r.ok) };
  }
);
