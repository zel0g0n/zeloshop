const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { GoogleGenAI } = require("@google/genai");
const { admin, db, GEMINI_API_KEY } = require("./lib/admin");
const { checkRateLimit } = require("./lib/rateLimit");
const { withSentry, SENTRY_DSN } = require("./lib/sentry");
// AI CEO — 7-BOSQICH ("natija kuzatuvi va o'rganish", batafsil izoh:
// `aiCeoLearning.js`) bilan BOG'LOVCHI vosita: sotuvchi "AI CEO'dan
// so'rang" orqali "sen menga qanchalik samarali ishlayapsan?" deb
// so'rashi mumkin bo'lishi uchun.
const { buildLearningSummaryForDisplay, learningSummaryRef } = require("./aiCeoLearning");

/**
 * AI CEO — 6-BOSQICH: "TOOL-CALLING ARXITEKTURASI" (foydalanuvchi
 * tanlagan 4-bosqichli "avtonom agent" yo'l xaritasining 2-FAZASI;
 * 1-faza — v23'dagi `aiCeo.js`ning `craftActionPlan`i, qarang).
 *
 * MUHIM, ARXITEKTURAVIY FARQ (1-fazadan): v23'gacha (va v23'ning o'zida
 * ham) Gemini'ga HAR DOIM OLDINDAN, BITTA promptda tayyorlangan, QAT'IY
 * signal to'plami yuborilar edi ("mana senga raqamlar, shu asosida javob
 * ber"). Bu yerda ESA Gemini'ga HAQIQIY, CHAQIRILADIGAN VOSITALAR
 * (`tools`/`functionDeclarations`) beriladi - u O'ZI qaysi ma'lumot
 * KERAKLIGINI hal qiladi, kerakli vositani chaqiradi, natijani oladi va
 * KERAK BO'LSA yana boshqa vosita chaqiradi - bularning barchasi
 * `runToolCallingLoop` orqali, chegaralangan (`MAX_TOOL_ROUNDS`) aylanma
 * suhbat sifatida amalga oshadi. Bu - "AI o'zi qaror qabul qiladi"dan
 * "AI o'zi QAYSI MA'LUMOT KERAKLIGINI ham hal qiladi"ga o'tish - haqiqiy
 * agentlik xatti-harakatining birinchi qadami.
 *
 * BIRINCHI QO'LLANILISH JOYI: "AI CEO'dan so'rang" - sotuvchi erkin
 * matnda (masalan "bu hafta eng ko'p nima sotildi?") savol beradi,
 * Gemini esa faqat KERAKLI vositalarni chaqirib (barchasini emas),
 * HAQIQIY, joriy Firestore ma'lumotidan asoslangan javob beradi.
 *
 * XAVFSIZLIK (nega bu — "ishonch zinapoyasi"da eng past xavfli qadam):
 * bu yerdagi VOSITALARNING BARCHASI — FAQAT O'QISH (read-only).
 * Hech biri Firestore'ga YOZMAYDI, xabar YUBORMAYDI, narx/chegirma
 * O'ZGARTIRMAYDI - shuning uchun Tier-1/2/3 "ishonch zinapoyasi"
 * modeliga MUTLAQO ehtiyoj yo'q: bu funksiya hech qanday moliyaviy yoki
 * obro'ga oid xavf tug'dirmaydi, faqat sotuvchining O'Z ma'lumotini
 * o'qib, tabiiy tilda tushuntirib beradi.
 *
 * XARAJAT NAZORATI: (1) har bir vosita FAQAT sotuvchining O'Z
 * ma'lumotiga (`sellerId` bo'yicha) cheklangan va natija sifatida QISQA,
 * agregatsiya qilingan raqam qaytaradi (xom hujjatlar emas - mavjud
 * konventsiyaga mos); (2) aylanma suhbat `MAX_TOOL_ROUNDS`dan oshmaydi -
 * oxirgi turda vositalar O'CHIRILADI, Gemini albatta matn bilan javob
 * berishga majburlanadi (cheksiz "tool-loop"ning oldini olish uchun);
 * (3) savol uzunligi cheklangan (300 belgi) - haddan tashqari uzun/qimmat
 * so'rovlarning oldini olish uchun; (4) alohida, past chegarali rate
 * limit (`askAiCeo:${uid}`, soatiga 15 marta).
 */

const MODEL = "gemini-3.5-flash-lite";
const DAY_MS = 24 * 60 * 60 * 1000;
const MAX_TOOL_ROUNDS = 4;

// MUHIM: `aiCeo.js`dagi `CRM_VIP_THRESHOLD`/`CRM_CHURN_DAYS` bilan BIR
// XIL bo'lib qolishi SHART - loyihada allaqachon o'rnatilgan
// "duplikatsiya qilingan mantiq" naqshi (frontend'dagi
// `src/utils/customerSegments.js` bilan ham mos kelishi kerak).
const VIP_THRESHOLD = 500_000;
const CHURN_DAYS = 30;

// ---------------------------------------------------------------------
// VOSITA E'LONLARI (Gemini KO'RADIGAN sxema) - `parametersJsonSchema`
// oddiy JSON Schema, `LABEL:`li matn formatidan farqli, Gemini'ning
// O'ZI qat'iy validatsiya qiladi (regex bilan qo'lda ajratish shart
// emas - bu, 1-faza bilan solishtirganda, ANIQROQ va ISHONCHLIROQ).
// ---------------------------------------------------------------------
const TOOL_DECLARATIONS = [
  {
    name: "get_revenue_summary",
    description: "So'nggi N kunlik tushum, buyurtmalar soni, yetkazilganlar soni va bekor qilish darajasini qaytaradi.",
    parametersJsonSchema: {
      type: "object",
      properties: { days: { type: "integer", description: "Necha kunlik davr (masalan 1, 7, 30)" } },
      required: ["days"],
    },
  },
  {
    name: "get_top_products",
    description: "So'nggi N kun ichida ENG KO'P sotilgan mahsulotlar ro'yxatini (nomi, soni, tushumi) qaytaradi.",
    parametersJsonSchema: {
      type: "object",
      properties: {
        days: { type: "integer", description: "Necha kunlik davr" },
        limit: { type: "integer", description: "Nechta mahsulot qaytarilsin (standart 5, maksimal 10)" },
      },
      required: ["days"],
    },
  },
  {
    name: "get_customer_segments",
    description: "VIP (yuqori xarid summasiga ega) va \"uxlab qolgan\" (30+ kun xarid qilmagan) mijozlar sonini qaytaradi.",
    parametersJsonSchema: { type: "object", properties: {} },
  },
  {
    name: "get_low_stock_products",
    description: "Zaxirasi kam qolgan (tez tugab qolishi mumkin bo'lgan) mahsulotlar ro'yxatini qaytaradi.",
    parametersJsonSchema: {
      type: "object",
      properties: { limit: { type: "integer", description: "Nechta mahsulot qaytarilsin (standart 5, maksimal 10)" } },
    },
  },
  {
    name: "get_ai_ceo_learning_summary",
    description: "AI CEO'ning O'ZI yozgan avtomatik xabarlarining (qaytarish va sevimlilar eslatmalari) HAQIQIY, o'lchangan konversiya darajasini (necha foiz mijoz keyin xarid qildi) qaytaradi.",
    parametersJsonSchema: { type: "object", properties: {} },
  },
  {
    name: "get_recent_auto_discounts",
    description: "AI CEO tomonidan avtomatik (sotuvchi tasdiqisiz) yaratilgan, mijozlarni qaytarish uchun ishlatiladigan bir martalik chegirma promokodlari haqida statistika va so'nggilarini qaytaradi.",
    parametersJsonSchema: { type: "object", properties: {} },
  },
];

// ---------------------------------------------------------------------
// VOSITA BAJARUVCHILARI - har biri FAQAT `sellerId` doirasida o'qiydi,
// natija sifatida QISQA, agregatsiya qilingan obyekt qaytaradi (xom
// Firestore hujjatlari EMAS - mavjud xarajat-nazorati konventsiyasiga
// mos, faqat endi bu "oldindan" emas, Gemini SO'RAGANDA sodir bo'ladi).
// ---------------------------------------------------------------------

function clampInt(value, fallback, min, max) {
  const n = Number.isFinite(Number(value)) ? Math.round(Number(value)) : fallback;
  return Math.min(Math.max(n, min), max);
}

async function execGetRevenueSummary(sellerId, args) {
  const days = clampInt(args.days, 7, 1, 90);
  const since = Date.now() - days * DAY_MS;
  const ordersSnap = await db.collection("orders").where("sellerId", "==", sellerId)
    .where("createdAt", ">=", admin.firestore.Timestamp.fromMillis(since)).get();
  const orders = ordersSnap.docs.map((d) => d.data());
  const delivered = orders.filter((o) => o.status === "delivered");
  const revenue = delivered.reduce((sum, o) => sum + (Number(o.totalAmount) || 0), 0);
  const cancelCount = orders.filter((o) => o.status === "cancel").length;
  const cancelRatePercent = orders.length > 0 ? Math.round((cancelCount / orders.length) * 100) : 0;
  return {
    days,
    orderCount: orders.length,
    deliveredCount: delivered.length,
    revenue: Math.round(revenue),
    cancelRatePercent,
  };
}

async function execGetTopProducts(sellerId, args) {
  const days = clampInt(args.days, 7, 1, 90);
  const limit = clampInt(args.limit, 5, 1, 10);
  const since = Date.now() - days * DAY_MS;
  const ordersSnap = await db.collection("orders").where("sellerId", "==", sellerId)
    .where("createdAt", ">=", admin.firestore.Timestamp.fromMillis(since))
    .where("status", "==", "delivered").get();

  const qtyByProduct = new Map();
  const revenueByProduct = new Map();
  ordersSnap.docs.forEach((d) => {
    (d.data().orders || []).forEach((item) => {
      const qty = Number(item.quantity) || 0;
      qtyByProduct.set(item.name, (qtyByProduct.get(item.name) || 0) + qty);
      revenueByProduct.set(item.name, (revenueByProduct.get(item.name) || 0) + qty * (Number(item.price) || 0));
    });
  });

  const products = Array.from(qtyByProduct.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, limit)
    .map(([name, qty]) => ({ name, soldQty: qty, revenue: Math.round(revenueByProduct.get(name) || 0) }));

  return { days, products };
}

async function execGetCustomerSegments(sellerId) {
  const customersSnap = await db.collection("sellers").doc(sellerId).collection("customers").get();
  const nowMs = Date.now();
  let vipCount = 0;
  let churnCount = 0;
  customersSnap.docs.forEach((d) => {
    const c = d.data();
    const ltv = Number(c.ltv) || 0;
    const lastOrderAtMs = Number(c.lastOrderAtMs) || 0;
    const daysSinceLastOrder = Math.floor((nowMs - lastOrderAtMs) / DAY_MS);
    if (ltv >= VIP_THRESHOLD) vipCount += 1;
    else if (daysSinceLastOrder > CHURN_DAYS) churnCount += 1;
  });
  return { vipCount, churnCount, totalCustomers: customersSnap.size };
}

async function execGetLowStockProducts(sellerId, args) {
  const limit = clampInt(args.limit, 5, 1, 10);
  const productsSnap = await db.collection("products").where("sellerId", "==", sellerId).get();
  const lowStock = productsSnap.docs
    .map((d) => d.data())
    .filter((p) => Number(p.stock) > 0 && Number(p.stock) <= 5)
    .sort((a, b) => Number(a.stock) - Number(b.stock))
    .slice(0, limit)
    .map((p) => ({ name: p.name, stock: Number(p.stock) }));
  return { lowStock };
}

/**
 * YANGI (7-BOSQICH bilan bog'lovchi vosita): `aiCeoLearning.js`dagi
 * `buildLearningSummaryForDisplay` bilan BIR XIL, INSON O'QIYDIGAN
 * shaklni qaytaradi - Gemini shu raqamlarni O'QIB, tabiiy tilda
 * javob yozadi (raqamlarni o'zi O'YLAB TOPMAYDI).
 */
async function execGetAiCeoLearningSummary(sellerId) {
  const snap = await learningSummaryRef(sellerId).get();
  return buildLearningSummaryForDisplay(snap.exists ? snap.data() : {});
}

/**
 * YANGI (8-BOSQICH bilan bog'lovchi vosita, batafsil izoh:
 * `aiCeoAutoDiscount.js`): FAQAT O'QISH - `isAiCeoWinBackReward===true`
 * bo'lgan promokodlarni (allaqachon mavjud `coupons` kolleksiyasidan)
 * o'qib, sotuvchiga "AI CEO qancha va qanday chegirma bergan"ni
 * tabiiy tilda tushuntirish uchun. MUHIM, XARAJAT NAZORATI: faqat
 * BITTA tenglik filtri (`.where("isAiCeoWinBackReward","==",true)`)
 * ishlatiladi - Firestore'da bunday so'rov QO'SHIMCHA kompozit
 * indeksga MUHTOJ EMAS (tartiblash - `orderBy` - dasturiy JS
 * kodida, o'qilgandan KEYIN amalga oshiriladi).
 */
async function execGetRecentAutoDiscounts(sellerId) {
  const snap = await db.collection("sellers").doc(sellerId).collection("coupons")
    .where("isAiCeoWinBackReward", "==", true)
    .limit(50)
    .get();
  const all = snap.docs.map((d) => d.data());
  const recent = all
    .slice()
    .sort((a, b) => (Number(b.createdAtMs) || 0) - (Number(a.createdAtMs) || 0))
    .slice(0, 5)
    .map((c) => ({ code: c.code, discountPercent: c.discountValue, used: (Number(c.usedCount) || 0) > 0 }));
  const activeUnusedCount = all.filter((c) => c.isActive === true && (Number(c.usedCount) || 0) < (Number(c.usageLimit) || 1)).length;
  return { totalIssuedCount: all.length, activeUnusedCount, recent };
}

const TOOL_EXECUTORS = {
  get_revenue_summary: execGetRevenueSummary,
  get_top_products: execGetTopProducts,
  get_customer_segments: execGetCustomerSegments,
  get_low_stock_products: execGetLowStockProducts,
  get_ai_ceo_learning_summary: execGetAiCeoLearningSummary,
  get_recent_auto_discounts: execGetRecentAutoDiscounts,
};

/**
 * UMUMIY, QAYTA ISHLATILADIGAN aylanma tool-calling suhbat mexanizmi -
 * "AI CEO'dan so'rang"ga BOG'LIQ EMAS (kelajakdagi 3/4-fazalar HAM shu
 * funksiyani, faqat BOSHQA `toolDeclarations`/`executors` bilan qayta
 * ishlatishi mumkin).
 *
 * Ishlash tartibi: Gemini'ga prompt+vositalar yuboriladi -> agar Gemini
 * bitta yoki bir nechta vosita chaqirsa, ular SERVER TOMONIDA bajariladi
 * va natija Gemini'ga "functionResponse" sifatida qaytariladi -> Gemini
 * yana vosita chaqirishi (ko'proq ma'lumot kerak bo'lsa) yoki YAKUNIY
 * matn bilan javob berishi mumkin -> vosita chaqiruvi bo'lmasa (yoki
 * `maxRounds`ga yetilsa), suhbat tugaydi.
 *
 * @param {object} params
 * @param {string} params.prompt - boshlang'ich foydalanuvchi promti
 * @param {Array} params.toolDeclarations - Gemini'ga beriladigan vosita sxemalari
 * @param {Record<string, Function>} params.executors - vosita nomi -> `(context, args) => Promise<object>`
 * @param {*} params.executorContext - har bir bajaruvchiga uzatiladigan kontekst (masalan `sellerId`)
 * @param {number} [params.maxRounds] - xavfsizlik chegarasi (standart `MAX_TOOL_ROUNDS`)
 */
async function runToolCallingLoop({ prompt, toolDeclarations, executors, executorContext, maxRounds = MAX_TOOL_ROUNDS }) {
  const ai = new GoogleGenAI({ apiKey: GEMINI_API_KEY.value() });
  const contents = [{ role: "user", parts: [{ text: prompt }] }];
  const toolsUsed = [];

  for (let round = 0; round < maxRounds; round += 1) {
    // XARAJAT NAZORATI: oxirgi (majburiy) turda vositalar O'CHIRILADI -
    // Gemini albatta MATN bilan javob berishi kerak, aks holda cheksiz
    // "vosita so'rayveradigan" tsiklga tushib qolishi mumkin edi.
    const isLastRound = round === maxRounds - 1;
    // eslint-disable-next-line no-await-in-loop -- MUHIM: har bir tur
    // OLDINGI turning natijasiga (Gemini'ning vosita chaqiruviga)
    // bog'liq - parallel bajarish mumkin emas, bu haqiqiy AYLANMA suhbat.
    const response = await ai.models.generateContent({
      model: MODEL,
      contents,
      config: isLastRound ? {} : { tools: [{ functionDeclarations: toolDeclarations }] },
    });

    const calls = response.functionCalls || [];
    if (calls.length === 0) {
      return { text: (response.text || "").trim(), toolsUsed };
    }

    // MUHIM TUZATISH: avval bu yerda `response.functionCalls`dan (faqat
    // {id,name,args} saqlaydigan, YENGILLASHTIRILGAN qayta qurish)
    // qo'lda `{ functionCall: c }` yasalar edi - bu Gemini 3 modellari
    // (`gemini-3.5-flash-lite`) HAR BIR vosita chaqiruvi bilan birga
    // qaytaradigan `thoughtSignature`ni (Part darajasida, FunctionCall
    // ICHIDA EMAS) BUTUNLAY yo'qotar edi. Gemini 3'da bu imzo KEYINGI
    // turda ALBATTA qaytarilishi SHART - aks holda API "missing
    // thought_signature" 400-xatosini qaytaradi (vosita chaqirilgan
    // DEYARLI HAR bir savolda takrorlanadigan xato - masalan "hisobot
    // ber"). Google hujjatlari tavsiyasiga ko'ra, modelning TO'LIQ
    // `content` obyektini (asl `parts`, imzo bilan birga) o'zgarishsiz
    // tarixga qo'shish kerak.
    contents.push(response.candidates?.[0]?.content || { role: "model", parts: calls.map((c) => ({ functionCall: c })) });
    const responseParts = [];
    for (const call of calls) {
      const executor = executors[call.name];
      let output;
      try {
        // eslint-disable-next-line no-await-in-loop -- bir turdagi bir
        // nechta chaqiruv ham ketma-ket bajariladi (soddalik va aniq
        // xato-kuzatuv uchun - bu funksiyalar allaqachon arzon/tez).
        output = executor ? await executor(executorContext, call.args || {}) : { error: "noma'lum vosita" };
      } catch (err) {
        output = { error: err.message || "vosita xatosi" };
      }
      toolsUsed.push({ name: call.name, args: call.args || {} });
      responseParts.push({ functionResponse: { id: call.id, name: call.name, response: { output } } });
    }
    contents.push({ role: "user", parts: responseParts });
  }

  return { text: "", toolsUsed };
}

/**
 * SOF FUNKSIYA - "AI CEO'dan so'rang" uchun boshlang'ich prompt.
 * MUHIM: bu yerda AVVALGI fazalardagi kabi RAQAMLAR emas, balki
 * VOSITALAR TAVSIFI beriladi - Gemini o'zi qaysi vositani qachon
 * chaqirishni hal qiladi.
 */
function buildAskAiCeoPrompt(question, storeName) {
  return `Sen — kichik onlayn kosmetika do'koni uchun ishlaydigan AI CEO yordamchisisan. Sotuvchi senga savol beryapti, sen esa unga berilgan VOSITALAR (tools) orqali HAQIQIY, joriy ma'lumotni tekshirib javob berasan.

Do'kon: "${storeName || "Do'kon"}"
Sotuvchi savoli: "${question}"

QOIDALAR:
- Savolga javob berish uchun ZARUR vosita(lar)ni chaqir - faqat kerakligini, hammasini emas.
- Vositadan olingan HAQIQIY natijaga tayangan holda javob ber - hech qanday raqam yoki faktni O'ZING O'YLAB TOPMA.
- Javob QISQA (2-4 gap) va ANIQ bo'lsin.
- Agar savol berilgan vositalar doirasidan tashqarida bo'lsa (masalan umumiy, ma'lumotga bog'liq bo'lmagan savol), buni ochiq-oydin ayt va vosita chaqirma.
- Faqat O'ZBEK TILIDA javob ber.`;
}

async function handleAskAiCeo(request) {
  if (!request.auth) {
    throw new HttpsError("unauthenticated", "Bu funksiyani ishlatish uchun tizimga kirgan bo'lishingiz kerak.");
  }
  await checkRateLimit(`askAiCeo:${request.auth.uid}`, 15, 3600);

  const sellerId = request.auth.uid;
  const sellerSnap = await db.collection("sellers").doc(sellerId).get();
  if (!sellerSnap.exists || sellerSnap.data().aiCeoEnabled !== true) {
    throw new HttpsError("permission-denied", "Bu funksiya faqat AI CEO premium mijozlari uchun mavjud.");
  }

  const { question } = request.data || {};
  const trimmedQuestion = typeof question === "string" ? question.trim() : "";
  if (!trimmedQuestion || trimmedQuestion.length > 300) {
    throw new HttpsError("invalid-argument", "Savol matni noto'g'ri (1-300 belgi orasida bo'lishi kerak).");
  }

  try {
    const { text, toolsUsed } = await runToolCallingLoop({
      prompt: buildAskAiCeoPrompt(trimmedQuestion, sellerSnap.data().storeName),
      toolDeclarations: TOOL_DECLARATIONS,
      executors: TOOL_EXECUTORS,
      executorContext: sellerId,
    });
    if (!text) throw new Error("AI javob bera olmadi.");
    return { answer: text, toolsUsed: toolsUsed.map((c) => c.name) };
  } catch (err) {
    console.error(`AI CEO savol-javob xatosi (sotuvchi ${sellerId}):`, err);
    throw new HttpsError("internal", "Javob berishda xatolik yuz berdi. Birozdan so'ng qayta urinib ko'ring.");
  }
}

exports.askAiCeo = onCall({ region: "asia-south1", secrets: [SENTRY_DSN, GEMINI_API_KEY] }, withSentry(handleAskAiCeo));

exports._testables = {
  runToolCallingLoop,
  buildAskAiCeoPrompt,
  handleAskAiCeo,
  execGetRevenueSummary,
  execGetTopProducts,
  execGetCustomerSegments,
  execGetLowStockProducts,
  execGetAiCeoLearningSummary,
  execGetRecentAutoDiscounts,
  TOOL_DECLARATIONS,
  TOOL_EXECUTORS,
  clampInt,
};
