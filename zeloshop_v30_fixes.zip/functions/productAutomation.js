const { onDocumentCreated } = require("firebase-functions/v2/firestore");
const { db, BOT_TOKEN } = require("./lib/admin");
const { buildDeepLink } = require("./lib/helpers");

/**
 * AI CEO — AVTOMATIK KANAL POSTLARI (Firestore TRIGGER'lar).
 *
 * MUHIM ARXITEKTURA IZOHI: mahsulot/kupon yaratish HOZIRGI HOLATDA
 * MIJOZ TOMONIDAN, to'g'ridan-to'g'ri Firestore'ga YOZILADI (Cloud
 * Function orqali EMAS) - shuning uchun "yaratilganda avtomatik
 * kanalga post qilish"ni frontend kodiga QO'SHIB BO'LMAYDI (bot
 * tokeni - maxfiy, faqat serverda saqlanadi). Buning o'rniga -
 * Firestore TRIGGER ishlatiladi: hujjat yaratilishi bilan, bu
 * funksiya AVTOMATIK ishga tushadi, MIJOZ TOMONI BUNI UMUMAN
 * BILMAYDI HAM. Bu, ikkala mahsulot yaratish yo'lini ham (oddiy
 * "Yangi tovar" formasi VA AI CEO "Tez qo'shish" tasdiqlash oqimi)
 * BIR VAQTDA qamrab oladi - ikkalasi ham OXIR-OQIBAT bir xil
 * `products` kolleksiyasiga yozadi.
 *
 * XAVFSIZLIK VA XARAJAT NAZORATI:
 * - Faqat `aiCeoEnabled === true` sotuvchilar uchun ishlaydi - bu,
 *   foydalanuvchi so'ragan "bu, AI CEO'ning ishi" tamoyiliga mos
 *   (premium xususiyat sifatida).
 * - Faqat sotuvchi KANAL ULAGAN bo'lsa post qilinadi - aks holda,
 *   funksiya HECH NARSA qilmasdan, DARHOL chiqadi.
 * - Har bir hujjat uchun FAQAT BIR MARTA ishga tushadi (Firestore
 *   trigger tabiati shunday - qayta ishga tushish xavfi yo'q).
 *
 * MUHIM, OCHIQ QAROR (xavfsizlik/xarajat muvozanati): foydalanuvchi
 * "barcha xaridorlarga ham yuborilsin" deb so'ragan edi - LEKIN bu
 * YERDA FAQAT KANALGA post qilinadi, HAR BIR XARIDORGA ALOHIDA
 * XABAR YUBORILMAYDI. Sabab: agar sotuvchi ketma-ket bir necha
 * kupon/mahsulot qo'shsa (masalan sinov paytida), bu HAR SAFAR
 * BARCHA mijozlarga (potentsial minglab) xabar yuborilishiga olib
 * kelardi - bu, nazoratsiz xarajat va SPAM xavfi. Xaridorlarga
 * ALOHIDA broadcast yuborish - hamon CRM Hub'dagi MAVJUD, sotuvchi
 * O'ZI BOSADIGAN oqim orqali qoladi (bu YERDA o'zgartirilmagan).
 */

const MAX_HASHTAG_LENGTH = 30;

/**
 * Kategoriya nomini Telegram hashtag'ga aylantiradi (bo'sh joy va
 * maxsus belgilarni olib tashlaydi). SOF FUNKSIYA.
 */
function categoryToHashtag(category) {
  if (!category) return "";
  const cleaned = category
    .normalize("NFKD")
    .replace(/[^\p{L}\p{N}]/gu, "") // faqat harf/raqam qoldiriladi
    .slice(0, MAX_HASHTAG_LENGTH);
  return cleaned ? `#${cleaned}` : "";
}

/**
 * Yangi mahsulot uchun kanal post matnini quradi. SOF FUNKSIYA -
 * to'g'ridan-to'g'ri test qilinadi.
 *
 * MUHIM QO'SHIMCHA (foydalanuvchi so'ragan): rasm+narxdan tashqari,
 * ZAXIRA SONI ("nechta dona bor") ham qo'shiladi - agar `stock` maydoni
 * HAQIQIY son sifatida berilgan bo'lsa (0 ham HAQIQIY qiymat - shuning
 * uchun aniq `Number.isFinite` tekshiruvi, `if (product.stock)` EMAS,
 * chunki 0 "falsy" bo'lib, noto'g'ri o'tkazib yuborilardi). "Sotib
 * olish" TUGMASI matnga EMAS - alohida `postToConnectedChannel`dagi
 * `reply_markup`ga qo'shiladi (Telegram tugmalari matn ichida bo'lmaydi).
 */
function buildProductChannelPost(product) {
  const name = product?.name || "Yangi mahsulot";
  const price = Number(product?.discountPrice) > 0 && Number(product.discountPrice) < Number(product.price)
    ? Number(product.discountPrice)
    : Number(product?.price) || 0;
  const hasDiscount = Number(product?.discountPrice) > 0 && Number(product.discountPrice) < Number(product?.price);
  const hashtag = categoryToHashtag(product?.category);
  const stock = Number(product?.stock);

  const lines = [`🆕 ${name}`, ""];
  if (product?.description) {
    const shortDesc = product.description.length > 150 ? `${product.description.slice(0, 150).trim()}...` : product.description;
    lines.push(shortDesc, "");
  }
  if (hasDiscount) {
    lines.push(`💰 ${price.toLocaleString()} so'm  (avvalgi narx: ${Number(product.price).toLocaleString()} so'm)`);
  } else {
    lines.push(`💰 ${price.toLocaleString()} so'm`);
  }
  if (Number.isFinite(stock) && stock >= 0) {
    lines.push(`📦 Zaxirada: ${stock.toLocaleString()} dona`);
  }
  if (hashtag) lines.push("", hashtag);

  return lines.join("\n");
}

/**
 * Yangi kupon/aksiya uchun kanal post matnini quradi. SOF FUNKSIYA.
 */
function buildCouponChannelPost(coupon) {
  const code = coupon?.code || "";
  const discountLabel = coupon?.discountType === "fixed"
    ? `${Number(coupon.discountValue).toLocaleString()} so'm chegirma`
    : `${Number(coupon.discountValue)}% chegirma`;

  const lines = [
    "🎁 Yangi aksiya!",
    "",
    `Promokod: ${code}`,
    discountLabel,
  ];
  if (coupon?.expiresAt) {
    lines.push("", `Amal qilish muddati: ${new Date(coupon.expiresAt).toLocaleDateString("uz-UZ")}gacha`);
  }
  lines.push("", "Checkout'da promokod maydoniga kiriting!");

  return lines.join("\n");
}

/**
 * Sotuvchining ulangan kanaliga (agar bor bo'lsa) post yuboradi.
 * Xato bo'lsa, jim log yozadi - trigger funksiyasi hech qachon
 * foydalanuvchiga ko'rinadigan xato bermasligi kerak (fon jarayoni).
 *
 * `buttonUrl` (YANGI, ixtiyoriy) - berilsa, xabar ostiga "Sotib olish"
 * inline tugmasi qo'shiladi (Telegram'da matn ICHIGA havola qo'yib
 * bo'lmaydi - shuning uchun alohida `reply_markup`).
 */
async function postToConnectedChannel(sellerId, caption, imageUrl, buttonUrl) {
  const [sellerSnap, customBotSnap] = await Promise.all([
    db.collection("sellers").doc(sellerId).get(),
    db.collection("sellers").doc(sellerId).collection("private").doc("customerBot").get(),
  ]);

  if (!sellerSnap.exists || sellerSnap.data().aiCeoEnabled !== true) return;

  const customBot = customBotSnap.exists ? customBotSnap.data() : null;
  if (!customBot?.botToken || !customBot?.connectedChannelUsername) return;

  const replyMarkup = buttonUrl ? { inline_keyboard: [[{ text: "🛒 Sotib olish", url: buttonUrl }]] } : undefined;

  try {
    const endpoint = imageUrl ? "sendPhoto" : "sendMessage";
    const body = imageUrl
      ? { chat_id: customBot.connectedChannelUsername, photo: imageUrl, caption: caption.slice(0, 1024), reply_markup: replyMarkup }
      : { chat_id: customBot.connectedChannelUsername, text: caption.slice(0, 4096), reply_markup: replyMarkup };

    const res = await fetch(`https://api.telegram.org/bot${customBot.botToken}/${endpoint}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const data = await res.json();
    if (!data.ok) console.error(`Avtomatik kanal posti muvaffaqiyatsiz (sotuvchi ${sellerId}):`, data.description);
  } catch (err) {
    console.error(`Avtomatik kanal postida xatolik (sotuvchi ${sellerId}):`, err);
  }
}

exports.onProductCreated = onDocumentCreated(
  { document: "products/{productId}", region: "asia-south1", secrets: [BOT_TOKEN] },
  async (event) => {
    const product = event.data?.data();
    if (!product?.sellerId) return;
    const caption = buildProductChannelPost(product);
    // YANGI: "Sotib olish" tugmasi - do'kondagi O'SHA mahsulot
    // sahifasiga to'g'ridan-to'g'ri ochiladigan chuqur havola
    // (`/product/{id}`, xaridor tugmani bosishi bilan Mini App o'sha
    // mahsulot kartochkasida ochiladi - `src/utils/shareLink.js`dagi
    // `buildDeepLink` bilan BIR XIL format, faqat SERVER tomonida).
    const buttonUrl = buildDeepLink(product.sellerId, `/product/${event.params.productId}`);
    await postToConnectedChannel(product.sellerId, caption, product.image || null, buttonUrl);
  }
);

exports.onCouponCreated = onDocumentCreated(
  { document: "sellers/{sellerId}/coupons/{code}", region: "asia-south1", secrets: [BOT_TOKEN] },
  async (event) => {
    const coupon = event.data?.data();
    const sellerId = event.params.sellerId;
    if (!coupon) return;
    const caption = buildCouponChannelPost(coupon);
    await postToConnectedChannel(sellerId, caption, null, null);
  }
);

exports._testables = { buildProductChannelPost, buildCouponChannelPost, categoryToHashtag };
